//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <tchar.h>
//---------------------------------------------------------------------------
//USEFORM("about.cpp", Form1);
//USEFORM("SPI_setting.cpp", Form2);
USEFORM("regedit.cpp", Form3);
USEFORM("main.cpp", MainForm);
USEFORM("about.cpp", Form1);
USEFORM("SPI_setting.cpp", Form2);
//---------------------------------------------------------------------------
WINAPI _tWinMain(HINSTANCE, HINSTANCE, LPTSTR, int)
{
	try
	{
	 /*HANDLE hMutex=CreateMutex(NULL,false,"RunOnlyOneInstance");
	 if(hMutex==NULL||ERROR_ALREADY_EXISTS==::GetLastError())
	 {
	  ShowMessage("�����Ѿ�����!");
	  return false;
	 }       */
		Application->Initialize();
		Application->MainFormOnTaskBar = true;
		Application->CreateForm(__classid(TMainForm), &MainForm);
		Application->Run();
	}
	catch (Exception &exception)
	{
		Application->ShowException(&exception);
	}
	catch (...)
	{
		try
		{
			throw Exception("");
		}
		catch (Exception &exception)
		{
			Application->ShowException(&exception);
		}
	}
	return 0;
}
//---------------------------------------------------------------------------
