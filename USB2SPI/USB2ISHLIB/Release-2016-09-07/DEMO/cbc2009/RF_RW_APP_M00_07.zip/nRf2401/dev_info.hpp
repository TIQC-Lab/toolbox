#ifndef DEV_INFO_H

#include <vcl.h>
#define ST_MANUAL
#define ST_TIMER
#define ST_TRIGER

typedef enum
{
 DEV_RF2401 = 0,
 NUM_OF_DEV,
}enu_dev;

class DevInfo
{
 public:
	DevInfo(enu_dev id);
	~DevInfo();
 private:
	enu_dev devID;
	DWORD dwReadCnt;
	BYTE* pReadBuf;
	DWORD dwWriteCnt;
	BYTE* pWriteBuf;
 public:
	bool bRunning;
  //	BYTE byCEStatus;
	void* pMyData;
	DWORD reserved1;
	enu_dev GetDevId();
	DWORD GetReadCnt();
	DWORD GetWriteCnt();
	BYTE* GetReadBuf();
	BYTE* GetWriteBuf();
	void* GetData();
	void  SetData(void* pData);
	void PutReadBuf(BYTE* pStr,DWORD dwLen);
	void WriteBufUpdate(BYTE* pStr,DWORD dwLen);
	void ReadBufClear();
	void WriteBufClear();
};

#endif