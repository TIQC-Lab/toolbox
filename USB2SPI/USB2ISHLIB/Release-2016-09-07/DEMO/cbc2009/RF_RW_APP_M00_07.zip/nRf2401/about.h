//---------------------------------------------------------------------------

#ifndef aboutH
#define aboutH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <pngimage.hpp>
const BYTE VERSION[] = { "APP_RF_RW_M00.07"};
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TImage *Image1;
	TStaticText *StaticText2;
	TStaticText *StaticText3;
	TStaticText *StaticText4;
	TStaticText *StaticText7;
	TStaticText *StaticText8;
	TStaticText *StaticText10;
	TStaticText *StaticText5;
	TStaticText *StaticText6;
	TStaticText *StaticText11;
	TStaticText *StaticText12;
	TStaticText *StaticText13;
	TStaticText *StaticText14;
	TStaticText *StaticText15;
	TGroupBox *Groupbox2;
	TGroupBox *Groupbox1;
	TGroupBox *GroupBox3;
	TStaticText *StaticText16;
	TStaticText *StaticText17;
	TStaticText *StaticText18;
	TStaticText *StaticText19;
	TStaticText *StaticText20;
	TStaticText *StaticText21;
	TStaticText *StaticText1;
	TStaticText *StaticText9;
	void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
//extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
