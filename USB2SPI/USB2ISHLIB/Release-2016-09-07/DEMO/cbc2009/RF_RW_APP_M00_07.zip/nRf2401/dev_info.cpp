#include "dev_info.hpp"
#include "nRF2401.h"
//------------------------------------------------------------------------------
  DevInfo::DevInfo(enu_dev id)
  {
	devID = id;
	bRunning = false;
	dwReadCnt = 0;
	pReadBuf = NULL;
	dwWriteCnt = 0;
	pWriteBuf = NULL;
	pMyData = NULL;
	if(DEV_RF2401 == id)
	{
	  pMyData = (void*)new nRF2401Reg[NUM_OF_RF2401_REG];
	  memset(pMyData,0,sizeof(nRF2401Reg)*NUM_OF_RF2401_REG);
	  for( int i = 0 ; i < NUM_OF_RF2401_REG; i ++)
	  {
	   nRF2401Reg* pReg = (nRF2401Reg*)pMyData;
	   pReg[i].byAddr = i;
	   if(i > 0x17 )
         pReg[i].byAddr += 4;
       memcpy(pReg[i].Name,nRF2401_reg_name[i],strlen(nRF2401_reg_name[i]));
	  }
	}
  }
//------------------------------------------------------------------------------
  DevInfo::~DevInfo()
  {
	if(pReadBuf)
	  delete pReadBuf;
	if(pWriteBuf)
	  delete pWriteBuf;
	if(pMyData)
	 delete pMyData;
  }
//------------------------------------------------------------------------------
  enu_dev DevInfo::GetDevId()
  {
	return devID;
  }
//------------------------------------------------------------------------------
  DWORD DevInfo::GetReadCnt()
  {
	return dwReadCnt;
  }
//------------------------------------------------------------------------------
  DWORD DevInfo::GetWriteCnt()
  {
	return  dwWriteCnt;
  }
//------------------------------------------------------------------------------
  BYTE* DevInfo::GetReadBuf()
  {
	return pReadBuf;
  }
//------------------------------------------------------------------------------
  BYTE* DevInfo::GetWriteBuf()
  {
    return pWriteBuf;
  }

//------------------------------------------------------------------------------
  void DevInfo::PutReadBuf(BYTE* pStr,DWORD dwLen)
  {
	BYTE* pNew = new BYTE[dwReadCnt+dwLen];
	memcpy(pNew,pReadBuf,dwReadCnt);
	memcpy(&pNew[dwReadCnt],pStr,dwLen);
	dwReadCnt = dwReadCnt+dwLen;
	delete pReadBuf;
	pReadBuf = pNew;
  }
//------------------------------------------------------------------------------
  void DevInfo::WriteBufUpdate(BYTE* pStr,DWORD dwLen)
  {
	delete pWriteBuf;
	pWriteBuf = new BYTE[dwLen];
	memcpy(pWriteBuf,pStr,dwLen);
	dwWriteCnt = dwLen;
  }
//------------------------------------------------------------------------------
  void DevInfo::ReadBufClear()
  {
   delete pReadBuf;
   pReadBuf = NULL;
   dwReadCnt = 0;
  }

  //------------------------------------------------------------------------------
  void DevInfo::WriteBufClear()
  {
   delete pWriteBuf;
   pWriteBuf = NULL;
   dwWriteCnt = 0;
  }

 void* DevInfo::GetData()
 {
   return pMyData;
 }

 void  DevInfo::SetData(void* pData)
 {
   if(pMyData)
   {
	 delete pMyData;
   }
   pMyData = pData;
 }



