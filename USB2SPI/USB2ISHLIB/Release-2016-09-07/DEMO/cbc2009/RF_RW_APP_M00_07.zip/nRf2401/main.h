//---------------------------------------------------------------------------

#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <Mask.hpp>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>

#include "dev_info.hpp"
#include <Menus.hpp>
#define WM_USB_STATUS (WM_USER + 1)
#define WM_USB_TRIG   (WM_USER + 2)
#define LINE_SIZE     60
#define INVALID_DEV_NO    0xFF

#define MODE_NORMAL      0x02
#define MODE_UPGRADE     0x01
#define MODE_UNKNOWN     0x00

//const BYTE EEPIndex[] = {0,0,1,1,1,2,2,3,3,4,5,5,5,5};
AnsiString SPI_RateTab[] =
{
 "200KHz"    ,
 "400KHz"    ,
 "600KHz"    ,
 "800KHz"    ,
 "1MHz"      ,
 "2MHz"      ,
 "4MHz"      ,
 "6MHz"      ,
 "12MHz"
};
//---------------------------------------------------------------------------
/*typedef struct
{
	WORD tCYCH,tHW1,tHW0,tBreak,tBR,tCYCD_min,tCYCD_max,tDW1_min,tDW1_max,tDW0_min,tDW0_max,tTO;
}TIMING_ORDER;    */
class TMainForm : public TForm
{
__published:	// IDE-managed Components
	TSaveDialog *SaveDialog1;
	TOpenDialog *OpenDialog1;
	TPageControl *PageControl1;
	TTabSheet *RF2401;
	TGroupBox *GroupBox1;
	TLabel *Label34;
	TLabel *Label35;
	TButton *Button13;
	TButton *Button14;
	TMemo *Memo3;
	TGroupBox *GroupBox7;
	TLabel *Label37;
	TLabel *Label38;
	TButton *Button16;
	TButton *Button17;
	TMemo *Memo4;
	TCheckBox *CheckBox2;
	TStaticText *StaticText1;
	TStaticText *StaticText2;
	TButton *Button1;
	TButton *Button2;
	TGroupBox *GroupBox2;
	TListView *ListView1;
	TButton *Button3;
	TGroupBox *GroupBox3;
	TGroupBox *GroupBox4;
	TButton *Button4;
	TLabel *Label1;
	TLabel *Label2;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Label5;
	TLabel *Label6;
	TLabel *Label7;
	TLabel *Label8;
	TButton *Button5;
	TButton *Button6;
	TLabel *Label9;
	TLabel *Label10;
	TLabel *Label11;
	TComboBox *ComboBox1;
	TLabel *Label14;
	TLabel *Label15;
	TGroupBox *GroupBox5;
	TCheckBox *CheckBox1;
	TCheckBox *CheckBox3;
	TCheckBox *CheckBox4;
	TTimer *Timer1;
	TLabel *Label12;
	TLabel *Label13;
	TButton *Button7;
	TCheckBox *CheckBox5;
	TLabel *Label16;
	TEdit *Edit1;
	TRichEdit *RichEdit1;
	TButton *Button8;
	TPopupMenu *PopupMenu1;
	TMenuItem *N1;
	TMenuItem *N2;
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall UpdateSettingCtrl(void);
	void __fastcall Button13Click(TObject *Sender);
	void __fastcall startClick(TObject *Sender);
	void __fastcall ReadHexClick(TObject *Sender);
	void __fastcall WriteHexClick(TObject *Sender);
	void __fastcall RadioButton2Click(TObject *Sender);
	void __fastcall Button4Click(TObject *Sender);
	void __fastcall Memo2Change(TObject *Sender);
	void __fastcall StaticText5Click(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall ListView1DblClick(TObject *Sender);
	void __fastcall Button3Click(TObject *Sender);
	void __fastcall ListView1CustomDrawItem(TCustomListView *Sender, TListItem *Item,
          TCustomDrawState State, bool &DefaultDraw);
	void __fastcall Timer1Timer(TObject *Sender);
	void __fastcall Button17Click(TObject *Sender);
	void __fastcall Button7Click(TObject *Sender);
	void __fastcall Button6Click(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
	void __fastcall Button16Click(TObject *Sender);
	void __fastcall Button5Click(TObject *Sender);
	void __fastcall Button8Click(TObject *Sender);
	void __fastcall N1Click(TObject *Sender);
	void __fastcall N2Click(TObject *Sender);


private:	// User declarations
	//bool bOpen ;
	bool bNeedUpdated;
	BYTE bOpen;
	BYTE byMode;
	bool bCE_High;
	BYTE bySPI_RateIndex;
	DWORD dwSPIRW_Timeout;
	DWORD dwWriteIndex;
public:		// User declarations
	DevInfo* RF2401_dev;
	void __fastcall nRF240_Init(void);
	void __fastcall nRF240_GetStatus(void);
	void __fastcall nRF24_RxMode(void);
	bool __fastcall nRF24_TxInit(void);
	bool __fastcall nRF24_RxInit(void);
	void __fastcall nRF24_TxMode(void);
	void __fastcall nRF24_PowerDownMode(void);
	void __fastcall nRF24_IdleMode(void);
	bool __fastcall nRF24_RxData(void);
	bool __fastcall nRF24_TxData(void);
	bool _fastcall nRF24_ReadReg(void);

	__fastcall TMainForm(TComponent* Owner);
	void __fastcall USB_StatusChange(TMessage msg);
	void __fastcall USB_IO_Trigged(TMessage msg);
	BYTE __fastcall GetDevIndex(void);
	bool __fastcall GetDevInfo(AnsiString & ver,AnsiString & time,BYTE type);
	void _fastcall  AddMemoString(String& str, int color);
 //	bool __fastcall UpdateSector(BYTE sector_inx,void* lpBuff,BYTE* lpResult);
BEGIN_MESSAGE_MAP
MESSAGE_HANDLER(WM_USB_STATUS,  TMessage,   USB_StatusChange)
MESSAGE_HANDLER(WM_USB_TRIG,  TMessage,   USB_IO_Trigged)
END_MESSAGE_MAP(TForm)
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
