//---------------------------------------------------------------------------

#ifndef SPI_settingH
#define SPI_settingH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TForm2 : public TForm
{
__published:	// IDE-managed Components
	TGroupBox *GroupBox11;
	TLabel *Label27;
	TLabel *Label28;
	TLabel *Label29;
	TLabel *Label44;
	TLabel *Label59;
	TEdit *Edit21;
	TEdit *Edit22;
	TComboBox *ComboBox29;
	TButton *Button8;
	TButton *Button26;
	TButton *Button1;
	void __fastcall Button8Click(TObject *Sender);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall Button26Click(TObject *Sender);
private:	// User declarations
    AnsiString fileName;
public:		// User declarations
	BYTE myIndex;
	DWORD myTimeout;
	BYTE myExeCode;
	__fastcall TForm2(TComponent* Owner , BYTE index, DWORD timeout);
};
//---------------------------------------------------------------------------
//extern PACKAGE TForm2 *Form2;
//---------------------------------------------------------------------------
#endif
