//---------------------------------------------------------------------------

#ifndef regeditH
#define regeditH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "hexEdit.h"
//---------------------------------------------------------------------------
class TForm3 : public TForm
{
__published:	// IDE-managed Components
	TButton *Button1;
	TButton *Button2;
	TStaticText *StaticText1;
	TStaticText *StaticText2;
	TStaticText *StaticText3;
	TGroupBox *GroupBox1;
	TGroupBox *GroupBox2;
	TStaticText *StaticText4;
	TStaticText *StaticText5;
	TStaticText *StaticText6;
	TStaticText *StaticText7;
	TStaticText *StaticText8;
	TStaticText *StaticText9;
	TStaticText *StaticText10;
	TStaticText *StaticText11;
	TStaticText *StaticText12;
	TStaticText *StaticText13;
	THexEdit *HexEdit1;
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
	void* pMyReg ;
	BYTE myIndex ;
	__fastcall TForm3(TComponent* Owner,BYTE index,void* pReg);
};
//---------------------------------------------------------------------------
//extern PACKAGE TForm3 *Form3;
//---------------------------------------------------------------------------
#endif
