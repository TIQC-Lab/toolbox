//---------------------------------------------------------------------------

#include <vcl.h>
#include <winuser.h>
#pragma hdrstop

#include "main.h"
#include "usbio.h"
#include "about.h"
#include "SPI_setting.h"
#include "nrf2401.h"
#include "regedit.h"
extern "C"
{
 #include "extern_def.h"
}
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
const AnsiString ErrString [] =
{
 "ok",
 "����ȷ���ַ�!",
 "ȱ���ַ�!",
 "dddddddd",
 "û������!"
};
TMainForm *MainForm;
//DEV_Info stDevInfo[NUM_OF_DEV];

void CALLBACK USBIO_Status_Nofiy (BYTE	iDevInde,DWORD iStatus);
void CALLBACK USBIO_Trig_Nofiy (BYTE iDevInde,DWORD	iStatus);
void WideCharToMultiChar(UnicodeString str,char* pBuff);
int OpenTest(void);

//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
	: TForm(Owner)
{
 bOpen = INVALID_DEV_NO;//false;
 RF2401_dev = new DevInfo(DEV_RF2401);
// TRIG_dev = new DevInfo(DEV_TRIG);
}

//---------------------------------------------------------------------------




void __fastcall TMainForm::FormCreate(TObject *Sender)
{
//  InstallHook(0);
  /*��ʽ���ò���*/
  /*1>�����ɵ�DLL�ļ�����ִ���ļ�����Ŀ¼
	2>�����ɵ�LIB�ļ�������������Ŀ��
	3>��ͷ�ļ������������õ�C�ļ���*/
// bOpen = USBIO_OpenDevice();
 bySPI_RateIndex = 0;
 dwSPIRW_Timeout = 200*256*256 + 200;
 RichEdit1->DefAttributes->Color = clBlue;
 AddMemoString(UnicodeString("[INFO]:Welcome to use USB2ish device!"),clBlue);
/* if(bOpen!=INVALID_DEV_NO)
 {
   RichEdit1->SelAttributes->Color = clBlue;
   RichEdit1->Lines->Add(" ");
   AddMemoString(UnicodeString("[INFO]:Open USB2ISH success!"),clBlue);
   StaticText1->Caption = "�豸������";
   USBIO_SPIGetConfig(bOpen,&bySPI_RateIndex,&dwSPIRW_Timeout);
   USBIO_SetNotify(bOpen,USBIO_Status_Nofiy,USBIO_Trig_Nofiy);
   StaticText2->Caption = "������:" + SPI_RateTab[bySPI_RateIndex];
   if(USBIO_TrigSetConfig(bOpen,1) == false)      //��Ϊ�½����ж�
   {
	AddMemoString(UnicodeString("[ERRO]:Config Trigger fail!"),clRed);
   }
 }
 else
 {
   StaticText1->Caption = "�豸δ����";
   RichEdit1->SelAttributes->Color = clBlue;
   RichEdit1->Lines->Add(" ");
   AddMemoString(UnicodeString("[ERRO]:Open USB2ISH fail!"),clRed);
 }               */
 USBIO_SetUSBNotify(true,USBIO_Status_Nofiy);
 nRF240_Init();
 UpdateSettingCtrl();
/*       ��̬���ò���
 HINSTANCE HmyDLL;
 bool __stdcall (*myAdd)(BYTE);
//��������װ��DLL�ļ���ͬʱ������ľ��
HmyDLL=LoadLibrary("usb2uis.dll");
//���Ĳ������庯����ַ����
   FARPROC P;
//���岽����ȡ��̬���ӿ��ڵ�ĳһ�������ڴ��ַ
	 P=GetProcAddress(HmyDLL,"USBIO_OpenDevice");
//��������ǿ������ת������������ȡ�ĺ�����ַǿ��ת��Ϊ����
	   myAdd=(bool __stdcall (__cdecl *)(BYTE))P;
//���߲�����������
	  if(!bOpen)
		bOpen=myAdd(0);
	  if(bOpen)
	  {
	   this->Caption = this->Caption + AnsiString("������");
	  }
	  else
		this->Caption = this->Caption + AnsiString("�ѶϿ�");
//�ڰ˲����ͷ�DLL
//FreeLibrary(HmyDLL);
  */
 //USBIO_SetNotify(USBIO_Status_Nofiy,USBIO_Trig_Nofiy);

}
//---------------------------------------------------------------------------



void __fastcall TMainForm::FormClose(TObject *Sender, TCloseAction &Action)
{
 if(bOpen!=0xFF)
 {
  USBIO_CloseDevice(bOpen);
  AddMemoString(UnicodeString("[INFO]:Close USB2ISH success!"),clBlue);
  }
 delete RF2401_dev;
}
//---------------------------------------------------------------------------
void CALLBACK USBIO_Status_Nofiy (BYTE	iDevInde, DWORD	iStatus)
{
 PostMessage(MainForm->Handle,WM_USB_STATUS,iDevInde,iStatus);
}

//---------------------------------------------------------------------------
void CALLBACK USBIO_Trig_Nofiy (BYTE  iDevInde, DWORD	iStatus)
{
 PostMessage(MainForm->Handle,WM_USB_TRIG,iDevInde,iStatus);
}

//---------------------------------------------------------------------------

void __fastcall TMainForm::USB_StatusChange(TMessage msg)
{
  if(msg.LParam&0x80)                    //usb dev pluged
  {
  /*	if(bOpen!=INVALID_DEV_NO)
      return;
	bOpen = USBIO_OpenDevice();
	if(bOpen!=INVALID_DEV_NO)
	{

	  USBIO_SPIGetConfig(bOpen,&bySPI_RateIndex,&dwSPIRW_Timeout);
   //	  USBIO_TrigGetConfig(bOpen,&TRIG_dev->byRateIndex);
	  nRF24_ReadReg();
	  if(USBIO_TrigSetConfig(bOpen,1) == false)      //��Ϊ�½����ж�
	  {
		//ShowMessage("�����ж�ʧ��!");
		//RichEdit1->SelAttributes->Color = clRed;
		//RichEdit1->Lines->Add("[ERRO]:Config Trigger fail!");
		AddMemoString(UnicodeString("[INFO]:Config Trigger fail!"),clBlue);
	  }
		//RichEdit1->SelAttributes->Color = clBlue;
	   //	RichEdit1->Lines->Add("[INFO]:USB2ISH Plugged!");
		AddMemoString(UnicodeString("[INFO]:USB2ISH Plugged!"),clBlue);
	}
  */
  }
  else
  {
	 if(bOpen == msg.WParam)
	   {
		USBIO_CloseDevice(bOpen);
		bOpen = INVALID_DEV_NO;
		byMode = MODE_UNKNOWN;
		RF2401_dev->bRunning = false;
		GroupBox2->Enabled = !RF2401_dev->bRunning;
		GroupBox4->Enabled = !RF2401_dev->bRunning;
		GroupBox7->Enabled = !RF2401_dev->bRunning;
		Timer1->Enabled = false;
		Button4->Caption = "��ʼִ��";
		AddMemoString(UnicodeString("[INFO]:USB2ISH Unplugged!"),clBlue);
		//Button4Click(this);
		Button8->Caption = "�����豸";
		this->Caption = AnsiString("USB2ish? ");
	  }
  }

// SPI->Enabled = bOpen!=INVALID_DEV_NO;
// if(bOpen!=INVALID_DEV_NO)
 {
  UpdateSettingCtrl();
 }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::USB_IO_Trigged(TMessage msg)
{
// TRadioButton* pRadio;
 if(msg.WParam != bOpen ||msg.LParam != 0xAA)
  return;
 if(PageControl1->ActivePage == RF2401&&RF2401_dev->bRunning)
 {
  nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
  nRF240_GetStatus();
  //if(pReg[RF2401_CONFIG].byRegValue & 0x01)  //����ģʽ
  if(pReg[RF2401_STATUS].byRegValue & 0x80 )      //û�ж���״̬
  {
   //ShowMessage("[ERRO]:SPI read nRF2401 status fail");
  // RichEdit1->SelAttributes->Color = clRed;
  // RichEdit1->Lines->Add("[ERRO]:SPI read nRF2401 status fail");
   AddMemoString(UnicodeString("[ERRO]:SPI read nRF2401 status fail!"),clRed);
   Button4Click(this);
  }
  else if(pReg[RF2401_STATUS].byRegValue & 0x40)   //RX �ж�
  {
   //   RichEdit1->SelAttributes->Color = clBlue;
   //	RichEdit1->Lines->Add("[INFO]:nRF2401 RX Intterrupted!");
	AddMemoString(UnicodeString("[INFO]:nRF2401 RX Intterrupted!"),clBlue);
	nRF24_RxData();
	nRF24_RxMode();
  }
  else if(pReg[RF2401_STATUS].byRegValue & 0x20)   //TX �ж�
  {
   //	ShowMessage("TX �ж�!");
   //RichEdit1->SelAttributes->Color = clBlue;
   //RichEdit1->Lines->Add("[INFO]:nRF2401 TX Intterrupted!");
   AddMemoString(UnicodeString("[INFO]:nRF2401 TX Intterrupted!"),clBlue);
	if(nRF24_TxData())
	  nRF24_TxMode();
  }
  else if(pReg[RF2401_STATUS].byRegValue & 0x10)
  {
   //	ShowMessage("����ʧ��!");
   //	RichEdit1->SelAttributes->Color = clBlue;
   //	RichEdit1->Lines->Add("[INFO]:nRF2401 MAX_RT Intterrupted!");
	AddMemoString(UnicodeString("[INFO]:nRF2401 MAX_RT Intterrupted!"),clBlue);
	//RichEdit1->SelAttributes->Color = clRed;
	//RichEdit1->Lines->Add("[ERRO]:TX data fail");
	AddMemoString(UnicodeString("[ERRO]:nRF2401 TX data fail!"),clRed);
	Button4Click(this);
  }

 }
}

//---------------------------------------------------------------------------


void WideCharToMultiChar(UnicodeString str,char* pBuff)
{
	//��ȡ�������Ĵ�С��������ռ䣬��������С�ǰ��ֽڼ����
	//char *buffer=new char[size+1];
	int len = str.Length();
	WideCharToMultiByte(CP_ACP,0,str.c_str(),len,pBuff,len,NULL,NULL);
	pBuff[len] = 0;
	//ɾ��������������ֵ
	//return_value.append(buffer);
	//delete []buffer;
   // return buffer;
}

//---------------------------------------------------------------------------
void __fastcall TMainForm::UpdateSettingCtrl(void)
{
  AnsiString str;
  if(bOpen == INVALID_DEV_NO)
   {
	StaticText1->Caption = "�豸δ����";
	StaticText2->Caption = "SPI������:" + SPI_RateTab[bySPI_RateIndex];
	Button1->Enabled = false;
	Button2->Enabled = false;
   }
   else
   {
   if(byMode == MODE_NORMAL)
   {
      StaticText1->Caption = "�豸������";
	  StaticText2->Caption = "SPI������:" + SPI_RateTab[bySPI_RateIndex];
	  Button1->Enabled = true;
	  Button2->Enabled = true;
	}
   }
  if(PageControl1->ActivePage == RF2401)
  {
   nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
   for(int j = 0 ; j < NUM_OF_RF2401_REG; j ++)
   {
	TListItem* pItem = ListView1->Items->Item[j];
	pItem->SubItems->Clear();
	pItem->SubItems->Add(pReg[j].Name);
	if(j == 0x0A || j == 0x0B || j == 0x10)
	{
	 str.sprintf("0x%08X%02X",pReg[j].dwBakValue,pReg[j].byBakValue);
	}
	else
	{
	 str.sprintf("0x%02X",pReg[j].byBakValue);

	}
	pItem->SubItems->Add(str);
   }
   str.sprintf("%4dMHz",2400 + pReg[RF2401_RFCH].byRegValue);
   Label2->Caption = str;
   Label4->Caption = nRF2401_RF_PWR[(pReg[RF2401_SETUP].byRegValue >> 1) & 0x03];
   str.sprintf("%08X %02X",pReg[RF2401_TX_ADDR].dwRegValue,pReg[RF2401_TX_ADDR].byRegValue);
   Label8->Caption = str;
   str.sprintf("%08X %02X",pReg[RF2401_RX_ADDR_P0].dwRegValue,pReg[RF2401_RX_ADDR_P0].byRegValue);
   Label10->Caption = str;
   str.sprintf("%08X %02X",pReg[RF2401_RX_ADDR_P1].dwRegValue,pReg[RF2401_RX_ADDR_P1].byRegValue);
   Label15->Caption = str;
   str.sprintf("%02X%02X%02X%02X",pReg[RF2401_RX_ADDR_P2].byRegValue,pReg[RF2401_RX_ADDR_P3].byRegValue,
								  pReg[RF2401_RX_ADDR_P4].byRegValue,pReg[RF2401_RX_ADDR_P5].byRegValue);
   Label13->Caption = str;
   if((pReg[RF2401_SETUP].byRegValue & 0x20) == 0)
   {
	if(pReg[RF2401_SETUP].byRegValue & 0x08)
	   Label6->Caption = "2Mbps";
	else
	   Label6->Caption = "1Mbps";
   }
   else
   {
	Label6->Caption = "250Kbps";
   }
   CheckBox1->Checked = (pReg[RF2401_CONFIG].byRegValue & 0x40) ? false : true;
   CheckBox3->Checked = (pReg[RF2401_CONFIG].byRegValue & 0x20 )? false : true;
   CheckBox4->Checked = (pReg[RF2401_CONFIG].byRegValue & 0x10 )? false : true;
   if(bOpen == INVALID_DEV_NO)
   {
	Button4->Enabled = false;
	Button6->Enabled = false;
	Button7->Enabled = false;
	ComboBox1->Enabled = false;
   }
   else
   {
	Button4->Enabled = true;
	Button6->Enabled = true;
   	Button7->Enabled = true;
	ComboBox1->Enabled = true;
	/*if(pReg[RF2401_CONFIG].byRegValue & 0x02 == 0)
	{
	 ComboBox4->ItemIndex = 0;
	}
	else if(bCE_High == false)
	{
	 ComboBox4->ItemIndex = 1;
	}
	else if(pReg[RF2401_FIFO_STATUS].byRegValue & 0x40)
	{
     ComboBox4->ItemIndex = 2;
	}*/
   }
   ListView1->Refresh();
  }

}

void __fastcall TMainForm::Button13Click(TObject *Sender)
{
  if(PageControl1->ActivePage == RF2401)
  {
   RF2401_dev->ReadBufClear();
   Memo3->Clear();
   Label35->Caption = "000000";
  }
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::startClick(TObject *Sender)
{
  DWORD dwReadCnt;
  TMemo* pMemoRead;
  BYTE* pBuf;
  dwReadCnt = 0;
 if(PageControl1->ActivePage == RF2401)
  {
	dwReadCnt = RF2401_dev->GetReadCnt();
	pMemoRead = Memo3;
	pBuf = RF2401_dev->GetReadBuf();
  }
 if(!dwReadCnt)
   return;
 SaveDialog1->Filter = "bin file (*.bin)|*.bin|all file (*.*)|*.*";
 if(SaveDialog1->Execute()==ID_OK)
 {
  int hFile = FileCreate(SaveDialog1->FileName+".bin");
  FileWrite(hFile,pBuf,dwReadCnt);
  FileClose(hFile);
  //ShowMessage("ok");
  //RichEdit1->SelAttributes->Color = clBlue;
  //RichEdit1->Lines->Add("[INFO]:"+ UnicodeString(SaveDialog1->FileName) + "saved");
  AddMemoString(UnicodeString("[INFO]:"+ UnicodeString(SaveDialog1->FileName) + "saved"),clBlue);
 }
}


//---------------------------------------------------------------------------


void __fastcall TMainForm::ReadHexClick(TObject *Sender)
{
  DWORD dwReadCnt;
  TMemo* pMemoRead;
  TCheckBox* pCheckBox;
  BYTE* pBuf;
  dwReadCnt = 0;
  if(PageControl1->ActivePage == RF2401)
  {
   dwReadCnt = RF2401_dev->GetReadCnt();
   pBuf = RF2401_dev->GetReadBuf();
   pMemoRead = Memo3;
   pCheckBox = CheckBox5;
  }
  if(dwReadCnt==0)
	return;
  BYTE* pBuffDes;
  if(pCheckBox->Checked)
  {
	pBuffDes = new BYTE[(dwReadCnt/16+1)*LINE_SIZE+1];
	memset(pBuffDes,0,(dwReadCnt/16+1)*LINE_SIZE+1);
	Hex2String(pBuf,dwReadCnt,pBuffDes);
	pMemoRead->Clear();
	pMemoRead->Text = AnsiString((char*)pBuffDes);
  }
  else
  {
	pBuffDes = new BYTE[dwReadCnt+1];
	memset(pBuffDes,0,dwReadCnt+1);
	HandleNull(pBuf,dwReadCnt,pBuffDes);
	pMemoRead->Clear();
	pMemoRead->Text = AnsiString((char*)pBuffDes);
  }
  delete []pBuffDes;

}

//---------------------------------------------------------------------------


void __fastcall TMainForm::WriteHexClick(TObject *Sender)
{
  DWORD dwWriteCnt;
  TMemo* pMemoWrite;
  TCheckBox* pCheckBox;
  BYTE* pBuf;
  dwWriteCnt = 0;
  if(PageControl1->ActivePage == RF2401)
  {
   dwWriteCnt = RF2401_dev->GetWriteCnt();
   pBuf = RF2401_dev->GetWriteBuf();
   pMemoWrite = Memo4;
   pCheckBox = CheckBox2;
  }
  if(dwWriteCnt==0)
  {
    pMemoWrite->Clear();
	return;
  }
  bNeedUpdated = false;
  BYTE* pBuffDes;
  if(pCheckBox->Checked)
  {
    pMemoWrite->ReadOnly = false;
	pBuffDes = new BYTE[(dwWriteCnt/16+1)*LINE_SIZE+1];
	memset(pBuffDes,0,(dwWriteCnt/16+1)*LINE_SIZE+1);
	Hex2String(pBuf,dwWriteCnt,pBuffDes);
	pMemoWrite->Clear();
	pMemoWrite->Text = AnsiString((char*)pBuffDes);
  }
  else
  {
	if(CheckTextString(pBuf,dwWriteCnt))
	{
	  MessageBox(this->WindowHandle,"ֻ����ʽ��ʾ","���з���ʾ�ַ�",MB_OK);
	  pMemoWrite->ReadOnly = true;
	}
	pBuffDes = new BYTE[dwWriteCnt+1];
	memset(pBuffDes,0,dwWriteCnt+1);
	HandleNull(pBuf,dwWriteCnt,pBuffDes);
	pMemoWrite->Clear();
	pMemoWrite->Text = AnsiString((char*)pBuffDes);
  }
  delete []pBuffDes;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::RadioButton2Click(TObject *Sender)
{
  DWORD dwReadCnt,dwWriteCnt;
  TMemo* pMemoRead,*pMemoWrite;
  dwReadCnt = dwWriteCnt = 0;
  if(PageControl1->ActivePage == RF2401)
  {
   dwReadCnt = RF2401_dev->GetReadCnt();
   dwWriteCnt = RF2401_dev->GetWriteCnt();
   pMemoRead = Memo3;
   pMemoWrite = Memo4;
  }
 if(dwReadCnt)
 {
   BYTE* pBuffDes = new BYTE[(dwReadCnt/16+1)*LINE_SIZE+1];
   memset(pBuffDes,0,(dwReadCnt/16+1)*LINE_SIZE+1);
   BYTE* pBuffSrc = new BYTE[dwReadCnt+1];
   memset(pBuffSrc,0,dwReadCnt+1);
   WideCharToMultiChar(pMemoRead->Text.c_str(),pBuffSrc);
   Hex2String(pBuffSrc,dwReadCnt,pBuffDes);
   pMemoRead->Clear();
   pMemoRead->Text = AnsiString((char*)pBuffDes);
   delete []pBuffDes;
   delete []pBuffSrc;
 }
 if(dwWriteCnt)
 {
   BYTE* pBuffDes = new BYTE[(dwWriteCnt/16+1)*LINE_SIZE+1];
   memset(pBuffDes,0,(dwWriteCnt/16+1)*LINE_SIZE+1);
   BYTE* pBuffSrc = new BYTE[dwWriteCnt+1];
   memset(pBuffSrc,0,dwWriteCnt+1);
   WideCharToMultiChar(pMemoWrite->Text.c_str(),pBuffSrc);
   Hex2String(pBuffSrc,dwWriteCnt,pBuffDes);
   pMemoWrite->Clear();
   pMemoWrite->Text = AnsiString((char*)pBuffDes);
   delete []pBuffDes;
   delete []pBuffSrc;
 }
}
//---------------------------------------------------------------------------



void __fastcall TMainForm::Button4Click(TObject *Sender)
{
  BYTE Command;
  BYTE Txbuf[10];
  if(byMode != MODE_NORMAL)
 {
   AddMemoString(UnicodeString("[ERRO]:please enter the normal mode first!"),clRed);
   return ;
 }
  nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
  if(RF2401_dev->bRunning)
   {
	if(CheckBox1->Checked)
	{
	 if(USBIO_ExitTrig(bOpen) == false)
	 {
     // RichEdit1->SelAttributes->Color = clRed;
	 // RichEdit1->Lines->Add("[ERRO]:Exit Trigger fail!");
	  AddMemoString(UnicodeString("[ERRO]:Exit Trigger fail!"),clRed);
	  return;
	 }
	}
	else
	{
     Timer1->Enabled = false;
	}
	Button4->Caption = "��ʼִ��";
	RF2401_dev->bRunning = false;
	//USBIO_SetCE(bOpen,false);
	nRF24_IdleMode();
	//RichEdit1->SelAttributes->Color = clBlue;
	//RichEdit1->Lines->Add("[INFO]:Enter idle mode!");
   //	AddMemoString(UnicodeString("[INFO]:nRF2401 Enter idle mode!"),clBlue);
   }
  else
  {
  switch (ComboBox1->ItemIndex)
  {
   case RF2401_POWER_DOWN_MODE:             //�͹���ģʽ
   nRF24_PowerDownMode();
   UpdateSettingCtrl();
   break;
   case RF2401_IDLE_MODE:    //����ģʽһ
   nRF24_IdleMode();
   UpdateSettingCtrl();
   break;
   case RF2401_RX_MODE:   //ֻ����
   if(nRF24_RxInit())
	nRF24_RxMode();
   break;
   case RF2401_TX_MODE:   //ֻ����
   case RF2401_TX_RX_MODE:   //���ͺ����
   case RF2401_TX_RET_MODE:     //ѭ������
   if(nRF24_TxInit() && nRF24_TxData())
	  nRF24_TxMode();
   break;
   case 6:
   break;
   default:
   break;
  }
  }
 GroupBox2->Enabled = !RF2401_dev->bRunning;
 GroupBox4->Enabled = !RF2401_dev->bRunning;
 GroupBox7->Enabled = !RF2401_dev->bRunning;
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Memo2Change(TObject *Sender)
{
   DWORD dwWriteCnt;
   TMemo* pWriteMemo;
   TCheckBox* pCheckBox;
   TLabel* pLabel;
   DevInfo* pDev;
   int re;
   if(!bNeedUpdated)
   {
	 bNeedUpdated = true;
	 return;
   }
   if(PageControl1->ActivePage == RF2401)
   {
	 pWriteMemo = Memo4;
	 pCheckBox = CheckBox2;
	 pLabel = Label38;
	 pDev = RF2401_dev;
   }
  
   if(pCheckBox->Checked)
   {
	char buf[10];
	DWORD relLen;
	dwWriteCnt = pWriteMemo->GetTextLen();
	BYTE* pBuffSrc = new BYTE[dwWriteCnt+1];
	BYTE* pBuffDes = new BYTE[dwWriteCnt+1];
	memset(pBuffSrc,0,dwWriteCnt+1);
	WideCharToMultiChar(pWriteMemo->Text.c_str(),pBuffSrc);
	re = CheckHexString(pBuffSrc,&relLen);
	if(re==0)
	{
	 String2Hex(pBuffSrc,dwWriteCnt,pBuffDes);
	 pDev->WriteBufUpdate(pBuffDes,relLen);
	 sprintf(buf,"%06d",relLen);
	 pLabel->Caption = AnsiString(buf);
	}
	else if(re & 0x01)
	{
	 ShowMessage("����ȷ���ַ�!");
	}
	else if(re & 0x04)
	{
	 pDev->WriteBufClear();
	 pLabel->Caption = "0000";
    }
	delete pBuffSrc,pBuffDes;
   }
   else
   {
	char buf[10];
	dwWriteCnt = pWriteMemo->GetTextLen();
	BYTE* pBuffSrc = new BYTE[dwWriteCnt+1];
	memset(pBuffSrc,0,dwWriteCnt+1);
	WideCharToMultiChar(pWriteMemo->Text.c_str(),pBuffSrc);
	pDev->WriteBufUpdate(pBuffSrc,dwWriteCnt);
	sprintf(buf,"%06d",dwWriteCnt);
	pLabel->Caption = AnsiString(buf);
	delete pBuffSrc;
   }

}
//---------------------------------------------------------------------------

void __fastcall TMainForm::StaticText5Click(TObject *Sender)
{
 TForm1* Form = new TForm1(this);
 Form->ShowModal();
 delete Form;

}
//---------------------------------------------------------------------------
BYTE __fastcall TMainForm::GetDevIndex(void)
{
 return bOpen;
}

bool __fastcall TMainForm::GetDevInfo(AnsiString & ver,AnsiString & time,BYTE type)
{
 char temp[50];
 char ver_temp[30];
 char time_temp[30];
 memset(temp,0,50);
 memset(ver_temp,0,30);
 memset(time_temp,0,30);
 if(bOpen == INVALID_DEV_NO)
   return false;
 if(USBIO_GetVersion(bOpen,type,temp))
 {
  ExtractVer(temp,0,ver_temp);
  ver = AnsiString((char*)ver_temp);
  ExtractVer(temp,1,time_temp);
  time = AnsiString((char*)time_temp);
  return true;
 }
 else
   return false;
}

void __fastcall TMainForm::Button1Click(TObject *Sender)
{
 TForm2* pForm = new TForm2(this,bySPI_RateIndex,dwSPIRW_Timeout);
 if(pForm->ShowModal() == mrOk)
 {
  if(pForm->myExeCode == 2)  //����
  {
   if(USBIO_SPISetConfig(bOpen,pForm->myIndex,pForm->myTimeout))
   {
	bySPI_RateIndex = pForm->myIndex;
	dwSPIRW_Timeout = pForm->myTimeout;
	StaticText2->Caption = "������:" + SPI_RateTab[bySPI_RateIndex];
   //	RichEdit1->SelAttributes->Color = clRed;
	//RichEdit1->Lines->Add("[ERRO]:Config SPI success!");
	AddMemoString(UnicodeString("[INFO]:Config SPI success!!"),clBlue);
	}
	else
	  //ShowMessage("����ʧ��");
	 // RichEdit1->SelAttributes->Color = clRed;
	 // RichEdit1->Lines->Add("[ERRO]:Config SPI fail!");
	  AddMemoString(UnicodeString("[ERRO]:Config SPI fail!"),clRed);

   }
  else if(pForm->myExeCode == 1)  //��λ
  {
   if(USBIO_ResetDevice(bOpen,1))
   {
	USBIO_SPIGetConfig(bOpen,&bySPI_RateIndex,&dwSPIRW_Timeout);
	UpdateSettingCtrl();
   //	RichEdit1->SelAttributes->Color = clRed;
   //	RichEdit1->Lines->Add("[ERRO]:Reset SPI success!");
	AddMemoString(UnicodeString("[INFO]:Reset SPI success!"),clBlue);
   }
   else
	//ShowMessage("��λʧ��");
   {
   //	RichEdit1->SelAttributes->Color = clRed;
   //	RichEdit1->Lines->Add("[ERRO]:Reset SPI fail!");
	AddMemoString(UnicodeString("[ERRO]:Reset SPI fail!"),clRed);
   }
  }
 }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::nRF240_Init(void)
{
 int j;
 AnsiString str;
 nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
 for(j = 0 ; j < NUM_OF_RF2401_REG; j ++)
 {
  //TListItem* pItem = new TListItem(ListView1);
//  pItem->
  str.sprintf("0x%02X",pReg[j].byAddr);
  TListItem* pItem = ListView1->Items->Add();
  pItem->Caption = str;
  pItem->SubItems->Add(pReg[j].Name);
  if(j == 0x0A || j == 0x0B || j == 0x10)
	pItem->SubItems->Add("FFFFFFFFFF");
  else
	pItem->SubItems->Add("FF");
 }
 nRF24_ReadReg();

}

//---------------------------------------------------------------------------
bool __fastcall TMainForm::nRF24_ReadReg(void)
{
 int j,len;
 AnsiString str;
 nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
 //if(bOpen == INVALID_DEV_NO)
 if(byMode != MODE_NORMAL)
 {
   AddMemoString(UnicodeString("[ERRO]:please enter the normal mode first!"),clRed);
   return false;
 }
 if(USBIO_SetCE(bOpen,false))
   bCE_High = false;
 char Command;
 BYTE Recbuf[5];
 for(j = 0 ; j < NUM_OF_RF2401_REG; j ++)
 {
  Command = READ_REG + pReg[j].byAddr;
  if(pReg[j].byAddr == RF2401_RX_ADDR_P0 || pReg[j].byAddr == RF2401_RX_ADDR_P1 || pReg[j].byAddr == RF2401_TX_ADDR)
    len = 5;
  else
	len = 1;
  if(USBIO_SPIRead(bOpen,&Command,1,Recbuf,len))
  {
   if( pReg[j].byAddr == RF2401_RX_ADDR_P0 || pReg[j].byAddr == RF2401_RX_ADDR_P1 || pReg[j].byAddr == RF2401_TX_ADDR)
   {
	pReg[j].byRegValue = Recbuf[0];
	pReg[j].byBakValue = pReg[j].byRegValue;
	pReg[j].dwRegValue = (DWORD)( Recbuf[4] << 24 ) + ( Recbuf[3] << 16 ) + ( Recbuf[2] << 8 ) + Recbuf[1];
	pReg[j].dwBakValue = pReg[j].dwRegValue;
   }
   else
   {
	 pReg[j].byRegValue = Recbuf[0];
	 pReg[j].byBakValue = pReg[j].byRegValue;
   }
  }
  else
  {
  // ShowMessage("SPI read reg fail!");
  //RichEdit1->SelAttributes->Color = clRed;
 // RichEdit1->Lines->Add("[ERRO]:SPI read nRF2401 register fail!");
  // AddMemoString(UnicodeString("[ERRO]:SPI read nRF2401 register fail!"),clRed);
   break;
  }
 }
 //RichEdit1->SelAttributes->Color = clBlue;
 //RichEdit1->Lines->Add("[INFO]:nRF2401 read register success!");
 if(/*j == NUM_OF_RF2401_REG && pReg[RF2401_OBSERVE_TX].byRegValue == 0 ||*/ j < NUM_OF_RF2401_REG)
 {
   AddMemoString(UnicodeString("[ERRO]:SPI read nRF2401 register fail!"),clRed);
   return false;
 }
 else
 {
   AddMemoString(UnicodeString("[INFO]:nRF2401 read register success!!"),clBlue);
   return true;
 }
}
//----------------------------------------------------------------------------
void __fastcall TMainForm::ListView1DblClick(TObject *Sender)
{
 TListItem* pItem = ListView1->Selected;
 AnsiString str;
 if(pItem)
 {
  //if(pItem->Index == RF2401_OBSERVE_TX || pItem->Index == RF2401_RPD || pItem->Index == RF2401_FIFO_STATUS)
  // return;
 // ShowMessage(pItem->Caption);
  nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
  TForm3* pForm = new TForm3(this,pItem->Index,&pReg[pItem->Index]);
  if(pForm->ShowModal() == mrOk)
  {
	pItem->SubItems->Clear();
	pItem->SubItems->Add(pReg[pItem->Index].Name);
	if(pItem->Index == RF2401_RX_ADDR_P0 || pItem->Index == RF2401_RX_ADDR_P1 || pItem->Index == RF2401_TX_ADDR)
	{
	 str.sprintf("0x%08X%02X",pReg[pItem->Index].dwBakValue,pReg[pItem->Index].byBakValue);
	}
	else
	{
	 str.sprintf("0x%02X",pReg[pItem->Index].byBakValue);

	}
	pItem->SubItems->Add(str);
	ListView1->ClearSelection();
   }
   delete pForm;
 }

}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Button3Click(TObject *Sender)
{
 DWORD dwReadCnt;
 SaveDialog1->Filter = "par file (*.par)|*.par|all file (*.*)|*.*";
 nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
 if(SaveDialog1->Execute()==ID_OK)
 {
  int hFile = FileCreate(SaveDialog1->FileName+".par");
  for(int i = 0 ; i < NUM_OF_RF2401_REG ; i ++)
  {
   FileWrite(hFile,&pReg[i].byRegValue,1);
   FileWrite(hFile,&pReg[i].dwRegValue,4);
  }

  FileClose(hFile);
  //ShowMessage("ok");
 // RichEdit1->SelAttributes->Color = clBlue;
 // RichEdit1->Lines->Add("[INFO]:Outport to file success ");
  AddMemoString(UnicodeString("[INFO]:Outport to file success!"),clBlue);
  }
}
//---------------------------------------------------------------------------



void __fastcall TMainForm::ListView1CustomDrawItem(TCustomListView *Sender, TListItem *Item,
          TCustomDrawState State, bool &DefaultDraw)
{
 nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
 if(pReg[Item->Index].byRegValue == pReg[Item->Index].byBakValue &&
	pReg[Item->Index].dwRegValue == pReg[Item->Index].dwBakValue  )
 {
  Sender->Canvas->Font->Color = clBlack;
 }
 else
 {
  Sender->Canvas->Font->Color = clRed;
 }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::nRF24_PowerDownMode(void)
{
   BYTE Command;
   nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
   pReg[RF2401_CONFIG].byBakValue &= 0xFD;
   Command  = WRITE_REG + RF2401_CONFIG;
   if(USBIO_SPIWrite(bOpen,&Command,1,&pReg[RF2401_CONFIG].byBakValue,1) == false)
   {
	//ShowMessage("SPI write config ʧ��!");
	//RichEdit1->SelAttributes->Color = clRed;
	//RichEdit1->Lines->Add("[ERRO]:SPI write nRF2401 config fail!");
	AddMemoString(UnicodeString("[ERRO]:SPI write nRF2401 config fail!"),clRed);
	//RichEdit1->Lines->Add("[ERRO]:Can't enter into powerdown mode!");
	AddMemoString(UnicodeString("[ERRO]:nRF2401 fial to enter into powerdown mode!"),clRed);
	return;
   }
   pReg[RF2401_CONFIG].byRegValue = pReg[RF2401_CONFIG].byBakValue ;
   if(USBIO_SetCE(bOpen,false) == false)
   {
	//RichEdit1->SelAttributes->Color = clRed;
   //	RichEdit1->Lines->Add("[ERRO]:Set CE Pin Low fail!");
	AddMemoString(UnicodeString("[ERRO]:Set CE Pin Low fail!"),clBlue);
	//RichEdit1->Lines->Add("[ERRO]:nRF2401 fail to enter into powerdown mode!");
	AddMemoString(UnicodeString("[ERRO]:nRF2401 fail to enter into powerdown mode!"),clRed);
   }
   else
   {
    //RichEdit1->SelAttributes->Color = clBlue;
	//RichEdit1->Lines->Add("[INFO]:nRF2401 enter into powerdown mode!");
	AddMemoString(UnicodeString("[INFO]:nRF2401 enter into powerdown mode!"),clBlue);
   }
   bCE_High = false;
}

//---------------------------------------------------------------------------

void __fastcall TMainForm::nRF24_IdleMode(void)
{
   BYTE Command;
   nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
   USBIO_SetCE(bOpen,false);
   bCE_High = false;
   pReg[RF2401_CONFIG].byBakValue |= 0x02;
   Command  = WRITE_REG + RF2401_CONFIG;
   if(USBIO_SPIWrite(bOpen,&Command,1,&pReg[RF2401_CONFIG].byBakValue,1) == false)
   {
	//ShowMessage("SPI write config ʧ��!");
	//RichEdit1->SelAttributes->Color = clRed;
	//RichEdit1->Lines->Add("[ERRO]:SPI write nRF2401 config fail");
	AddMemoString(UnicodeString("[ERRO]:SPI write nRF2401 config fail!"),clRed);
	//RichEdit1->Lines->Add("[ERRO]:nRF2401 fail to enter into idle mode!");
	AddMemoString(UnicodeString("[ERRO]:nRF2401 fail to enter into idle mode!"),clRed);
	return;
   }
   pReg[RF2401_CONFIG].byRegValue = pReg[RF2401_CONFIG].byBakValue ;
   Command  = FLUSH_TX;
   if(USBIO_SPIWrite(bOpen,&Command,1,0,0) == false)
   {
	//ShowMessage("SPI write FLUSH_TX ʧ��!");
	//RichEdit1->SelAttributes->Color = clRed;
	//RichEdit1->Lines->Add("[ERRO]:SPI write nRF2401 FLUSH_TX fail");
	AddMemoString(UnicodeString("[ERRO]:SPI write nRF2401 FLUSH_TX fail!"),clRed);
	//RichEdit1->Lines->Add("[ERRO]:nRF2401 fail to enter into idle mode!");
	AddMemoString(UnicodeString("[ERRO]:nRF2401 fail to enter into idle mode!"),clRed);
	return;
   }
   Command  = FLUSH_RX;
   if(USBIO_SPIWrite(bOpen,&Command,1,0,0) == false)
   {
	//ShowMessage("SPI write FLUSH_RX ʧ��!");
   //	RichEdit1->SelAttributes->Color = clRed;
   //	RichEdit1->Lines->Add("[ERRO]:SPI write nRF2401 FLUSH_RX fail");
	AddMemoString(UnicodeString("[ERRO]:SPI write nRF2401 FLUSH_RX fail!"),clRed);
  //	RichEdit1->Lines->Add("[ERRO]:nRF2401 fail to enter into idle mode!");
	AddMemoString(UnicodeString("[ERRO]:nRF2401 fail to enter into idle mode!"),clRed);
	return;
   }
 //  RichEdit1->SelAttributes->Color = clBlue;
 // RichEdit1->Lines->Add("[INFO]:nRF2401 Enter idle mode!");
  AddMemoString(UnicodeString("[INFO]:nRF2401 Enter idle mode!"),clBlue);
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::nRF24_RxMode(void)
{
  //nRF24_IdleMode(1);

 if(CheckBox1->Checked)
 {
  if(USBIO_WaitForTrig(bOpen)==false)
  {
	//ShowMessage("�����ж�ʧ��!");
   //	RichEdit1->SelAttributes->Color = clRed;
	//RichEdit1->Lines->Add("[ERRO]:Open Trigger fail");
	AddMemoString(UnicodeString("[ERRO]:Open Trigger fail!"),clRed);
   //	RichEdit1->Lines->Add("[ERRO]:nRF2401 fail to enter into RX mode!");
	AddMemoString(UnicodeString("[ERRO]:nRF2401 fail to enter into RX mode!"),clRed);
	return;
   }
 }
 else
 {
  Timer1->Enabled = true;
 }
 RF2401_dev->bRunning = true;
 Button4->Caption = "ִֹͣ��";
 USBIO_SetCE(bOpen,true);
 bCE_High = true;
// RichEdit1->SelAttributes->Color = clBlue;
// RichEdit1->Lines->Add("[INFO]:nRF2401 enter into RX mode!");
 AddMemoString(UnicodeString("[INFO]:nRF2401 enter into RX mode!"),clBlue);
}

//---------------------------------------------------------------------------
bool __fastcall TMainForm::nRF24_TxInit(void)
{
  BYTE Command;
  BYTE tx_pld_w;
  nRF240_GetStatus();
  dwWriteIndex = 0;
  //nRF24_IdleMode();
  Command = FLUSH_TX;
  BYTE byWrite;
  if(RF2401_dev->GetWriteCnt() == 0)
 {
   ShowMessage("û�з�������!");
   return false;
 }

 if(StrToInt(Edit1->Text) == 0 || StrToInt(Edit1->Text) > 32 )
 {
   ShowMessage("TX_PAYLOAD_WIDTH ������1~32֮��!");
   return false;
 }
 nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
 byWrite = pReg[RF2401_CONFIG].byRegValue & 0xFE;
 Command  = WRITE_REG + RF2401_CONFIG;
 if(USBIO_SPIWrite(bOpen,&Command,1,&byWrite,1) == false)
 {
	AddMemoString(UnicodeString("[ERRO]:SPI write nRF2401 config fail!"),clRed);
	return false;
 }
 pReg[RF2401_CONFIG].byRegValue = byWrite;
 pReg[RF2401_CONFIG].byBakValue = byWrite;
 AddMemoString(UnicodeString("[INFO]:nRF2401 TX init success!"),clBlue);
 return true;
}

//---------------------------------------------------------------------------
bool __fastcall TMainForm::nRF24_RxInit(void)
{
  BYTE Command;
  BYTE byWrite;
  nRF240_GetStatus();
  dwWriteIndex = 0;
  //nRF24_IdleMode(1);
 /* Command = FLUSH_RX;
  if(USBIO_SPIWrite(bOpen,&Command,1,0,0) == false)         //дFIFO
 {
	ShowMessage("SPI write FLUSH_TX ʧ��!");
	return false;
 }
	  */
 nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
 byWrite = pReg[RF2401_CONFIG].byRegValue | 0x3;
 Command  = WRITE_REG + RF2401_CONFIG;
 if(USBIO_SPIWrite(bOpen,&Command,1,&byWrite,1) == false)
 {
	//ShowMessage("SPI write config ʧ��!");
   //	RichEdit1->SelAttributes->Color = clRed;
   //	RichEdit1->Lines->Add("[ERRO]:SPI write nRF2401 config fail");
	AddMemoString(UnicodeString("[ERRO]:SPI write nRF2401 config fail!"),clRed);
	return false;
 }
 pReg[RF2401_CONFIG].byRegValue = byWrite;
 pReg[RF2401_CONFIG].byBakValue = byWrite;
 //RichEdit1->SelAttributes->Color = clBlue;
//RichEdit1->Lines->Add("[INFO]:nRF2401 RX init success!");
 AddMemoString(UnicodeString("[INFO]:nRF2401 RX init success!"),clBlue);
 return true;
}

//---------------------------------------------------------------------------
void __fastcall TMainForm::nRF24_TxMode(void)
{
 if(CheckBox3->Checked)
 {
   if(USBIO_WaitForTrig(bOpen)==false)
	{
	AddMemoString(UnicodeString("[ERRO]:Open Trigger fail!"),clRed);
	return;
	}
 }
 else
 {
  Timer1->Enabled = true;
 }
 RF2401_dev->bRunning = true;
 Button4->Caption = "ִֹͣ��";
 USBIO_SetCE(bOpen,true);  //���뷢��ģʽ
 bCE_High = true;
// Sleep(1);
// USBIO_SetCE(bOpen,false);  //���뷢��ģʽ
// bCE_High = false;
// Sleep(1);

 //RichEdit1->SelAttributes->Color = clBlue;
 //RichEdit1->Lines->Add("[INFO]:nRF2401 Enter TX mode!");
 AddMemoString(UnicodeString("[INFO]:nRF2401 Enter TX mode!"),clBlue);
}

//---------------------------------------------------------------------------
bool __fastcall TMainForm::nRF24_RxData(void)
{
 BYTE Command;
 BYTE Rxbuf[100];
 BYTE byRead,byWrite;
 BYTE byPLoadlen;
 BYTE i;
 AnsiString str;
 nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
// Command = RD_RX_PLOAD;
 BYTE byPipe = pReg[RF2401_STATUS].byRegValue / 2 & 0x07;
 if(pReg[RF2401_FEATURE].byRegValue & 0x04)
 {
   Command = R_RX_PL_WID;
   if(USBIO_SPIRead(bOpen,&Command,1,Rxbuf,1) == false)
   {
	AddMemoString(UnicodeString("[ERRO]:SPI read nRF2401 R_RX_PL_WID fail!"),clRed);
	return true;
   }
   if(Rxbuf[0] > 0x20)
   {
	AddMemoString(UnicodeString("[ERRO]:SPI read nRF2401 RX_FIFO data length more than 32!"),clRed);
	return true;
   }
   byPLoadlen = Rxbuf[0];
 }
 else
 {

  byPLoadlen   =  pReg[RF2401_RX_PW_P0 + byPipe].byRegValue & 0x3F;
 }
 Command = RD_RX_PLOAD;
 if(USBIO_SPIRead(bOpen,&Command,1,Rxbuf,byPLoadlen) == false)       //��FIFO
 {
   //ShowMessage("SPI data ��ʧ��!");
  // RichEdit1->SelAttributes->Color = clRed;
   //RichEdit1->Lines->Add("[ERRO]:SPI read nRF2401 RD_RX_PLOAD fail");
   AddMemoString(UnicodeString("[ERRO]:SPI read nRF2401 RD_RX_PLOAD fail!"),clRed);
   return true;
 }
 RF2401_dev->PutReadBuf(Rxbuf,byPLoadlen);
 str.sprintf("%06d",RF2401_dev->GetReadCnt());
 Label35->Caption = AnsiString(str);
 if(!CheckBox5->Checked)
 {
   BYTE* pBuff = new BYTE[RF2401_dev->GetReadCnt()+1];
   memset(pBuff,0,RF2401_dev->GetReadCnt()+1);
   HandleNull(RF2401_dev->GetReadBuf(),RF2401_dev->GetReadCnt(),pBuff);
   Memo3->Clear();
   Memo3->Text = AnsiString((char*)pBuff);
   delete pBuff;
  }
 else
 {
  BYTE* pBuff = new BYTE[(RF2401_dev->GetReadCnt()/16+1)*LINE_SIZE+1];
  memset(pBuff,0,(RF2401_dev->GetReadCnt()/16+1)*LINE_SIZE+1);
  Hex2String(RF2401_dev->GetReadBuf(),RF2401_dev->GetReadCnt(),pBuff);
  Memo3->Clear();
  Memo3->Text = AnsiString((char*)pBuff);
  delete pBuff;
 }
 //RichEdit1->SelAttributes->Color = clBlue;
 str.sprintf("[INFO]:nRF2401 Rec %d bytes!",byPLoadlen);
// RichEdit1->Lines->Add(str);
 AddMemoString(UnicodeString(str),clBlue);
 return true;
}

//---------------------------------------------------------------------------
bool __fastcall TMainForm::nRF24_TxData(void)
{
 BYTE Command;
 AnsiString str;
 BYTE* pBuf;
 BYTE byRead,byWrite;
 BYTE byWidth;
 DWORD i;
 nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
 DWORD DataLen = RF2401_dev->GetWriteCnt();
 USBIO_SetCE(bOpen,false);  //�������ģʽ1
 bCE_High = false;
 byWidth = StrToInt(Edit1->Text);
 if(dwWriteIndex >= DataLen)
 {
  //ShowMessage("���ͳɹ�!");
 // RichEdit1->SelAttributes->Color = clBlue;
  str.sprintf("[INFO]:nRF2401 Tx %d bytes completed!",dwWriteIndex);
//  RichEdit1->Lines->Add(str);
  AddMemoString(UnicodeString(str),clBlue);
  if(CheckBox3->Checked)
  {
   if(USBIO_ExitTrig(bOpen) == false)
   {
	//RichEdit1->SelAttributes->Color = clRed;
	//RichEdit1->Lines->Add("[ERRO]:Exit Trigger fail");
	AddMemoString(UnicodeString("[ERRO]:Exit Trigger fail!"),clRed);
	return true;
   }
  }
  if(ComboBox1->ItemIndex == RF2401_TX_RX_MODE)
  {
   if(nRF24_RxInit())
   {
	nRF24_RxMode();
   }
   else
   {
	Button4->Caption = "��ʼִ��";
	RF2401_dev->bRunning = false;
	GroupBox2->Enabled = !RF2401_dev->bRunning;
	GroupBox4->Enabled = !RF2401_dev->bRunning;
    GroupBox7->Enabled = !RF2401_dev->bRunning;
	}
   return false;
  }
  else if(ComboBox1->ItemIndex == RF2401_TX_RET_MODE)
  {
	dwWriteIndex = 0;
  }
  else if(ComboBox1->ItemIndex == RF2401_TX_MODE)
  {
   Button4->Caption = "��ʼִ��";
   RF2401_dev->bRunning = false;
   GroupBox2->Enabled = !RF2401_dev->bRunning;
   GroupBox4->Enabled = !RF2401_dev->bRunning;
   GroupBox7->Enabled = !RF2401_dev->bRunning;
 // ComboBox1->ItemIndex = 1;
   return false;
  }
 }
 Command = WR_TX_PLOAD;
 pBuf    = RF2401_dev->GetWriteBuf();
 DataLen = DataLen - dwWriteIndex;
 if(DataLen > byWidth)
   DataLen = byWidth;
// for(i = 0 ; i + dwWriteIndex < DataLen && i < 32 ; i ++)
 {
  if(USBIO_SPIWrite(bOpen,&Command,1,&pBuf[dwWriteIndex],DataLen) == false)
  {
   //	ShowMessage("SPI write tx data ʧ��!");
  // RichEdit1->SelAttributes->Color = clRed;
   //	RichEdit1->Lines->Add("[ERRO]:SPI write  nRF2401 WR_TX_PLOAD fail");
	AddMemoString(UnicodeString("[ERRO]:SPI write  nRF2401 WR_TX_PLOAD fail!"),clRed);
	return true;
  }
  else
   {
	RichEdit1->SelAttributes->Color = clBlue;
	str.sprintf("[INFO]:nRF2401 write %d bytes to FIFO!",DataLen);
	AddMemoString(UnicodeString(str),clBlue);
	//RichEdit1->Lines->Add(str);
   }
 }
dwWriteIndex += DataLen;
//USBIO_SetCE(bOpen,true);  //���뷢��ģʽ
return true;
}


//----------------------------------------------------------------------------
void __fastcall TMainForm::Timer1Timer(TObject *Sender)
{
 nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
 Timer1->Enabled = false;
 nRF240_GetStatus();
 if(pReg[RF2401_STATUS].byRegValue & 0x80 )      //û�ж���״̬
 {
   //ShowMessage("SPI status ��ʧ��!");
  // RichEdit1->SelAttributes->Color = clRed;
  // RichEdit1->Lines->Add("[ERRO]:SPI read  nRF2401 status fail");
   AddMemoString(UnicodeString("[ERRO]:SPI read  nRF2401 status fail!"),clRed);
   Button4Click(Sender);
   return;
 }
 if(pReg[RF2401_STATUS].byRegValue & 0x10)   //�ظ����ʹ�����ϱ�־
 {
   AddMemoString(UnicodeString("[INFO]:nRF2401 status MAX_RT is SET!"),clBlue);
   AddMemoString(UnicodeString("[ERRO]:nRF2401 TX data fail!"),clRed);
   Button4Click(Sender);
   return;
 }
 else if(pReg[RF2401_STATUS].byRegValue & 0x40)   //�յ����ݱ�־
 {
  AddMemoString(UnicodeString("[INFO]:nRF2401 status RX_DR is SET!"),clBlue);
  if(ComboBox1->ItemIndex == 2 && nRF24_RxData())
	nRF24_RxMode();
 }
 else if(pReg[RF2401_STATUS].byRegValue & 0x20)  //������ϱ�־
 {
   AddMemoString(UnicodeString("[INFO]:nRF2401 status TX_DS is SET!"),clBlue);
   //if(ComboBox1->ItemIndex == 3 && nRF24_TxData())
   if(nRF24_TxData())
     nRF24_TxMode();
 }
 else
 {
  Timer1->Enabled = true;
//  USBIO_SetCE(bOpen,true);
//  bCE_High = true;
 }
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::Button17Click(TObject *Sender)
{
 if(PageControl1->ActivePage == RF2401)
  {
   RF2401_dev->WriteBufClear();
   Memo4->Clear();
   Label38->Caption = "000000";
  }
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Button7Click(TObject *Sender)
{
 if(nRF24_ReadReg())
   {
	UpdateSettingCtrl();
	AddMemoString(UnicodeString("[INFO]:Fresh nRF2401 Register success!"),clBlue);
   }
 else
 {
  AddMemoString(UnicodeString("[INFO]:Fresh nRF2401 Register fail!"),clRed);
 }
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::nRF240_GetStatus(void)
{
 BYTE byRead;
 BYTE Command;
 nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
 USBIO_SetCE(bOpen,false);
 bCE_High = false;
 byRead = 0;
 Command  = READ_REG + RF2401_STATUS;
 if(USBIO_SPIRead(bOpen,&Command,1,&byRead,1) == false)     //��״̬
 {
  pReg[RF2401_STATUS].byRegValue = 0x80;
  pReg[RF2401_STATUS].byBakValue = 0x80;
  return;
 }
 pReg[RF2401_STATUS].byRegValue = byRead;
 pReg[RF2401_STATUS].byBakValue = byRead;

 if(byRead & 0x70)
 {
  Command  = WRITE_REG + RF2401_STATUS;
  //byRead = byRead & 0x1F;
  if(USBIO_SPIWrite(bOpen,&Command,1,&byRead,1) == false)     //��״̬
  {
   //	ShowMessage("SPI status дʧ��!");
  // RichEdit1->SelAttributes->Color = clRed;
  // RichEdit1->Lines->Add("[ERRO]:SPI write  nRF2401 status fail");
   AddMemoString(UnicodeString("[ERRO]:SPI write  nRF2401 status fail!"),clRed);
  }
  Command  = READ_REG + RF2401_STATUS;
  //byRead = byRead & 0x1F;
  if(USBIO_SPIRead(bOpen,&Command,1,&byRead,1) == false)     //��״̬
  {
   // ShowMessage("SPI status дʧ��!");
   //RichEdit1->SelAttributes->Color = clRed;
   //RichEdit1->Lines->Add("[ERRO]:SPI read  nRF2401 status fail");
   AddMemoString(UnicodeString("[ERRO]:SPI read  nRF2401 status fail!"),clRed);
  }
  if(byRead & 0x70)
  {
   //ShowMessage("����ж�ʧ��!");
  // RichEdit1->SelAttributes->Color = clRed;
  // RichEdit1->Lines->Add("[ERRO]:SPI clear  nRF2401 status flag fail");
   AddMemoString(UnicodeString("[ERRO]:SPI clear  nRF2401 status flag fail!"),clRed);
  }
 }
// USBIO_SetCE(bOpen,true);
}




void __fastcall TMainForm::Button6Click(TObject *Sender)
{
 //if(bOpen == INVALID_DEV_NO)
 //  return;
 if(byMode != MODE_NORMAL)
 {
   AddMemoString(UnicodeString("[ERRO]:please enter the normal mode first!"),clRed);
   return ;
 }
  BYTE len;
 BYTE Command;
 BYTE Txbuf[5],Rxbuf[5];
 nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
 if(USBIO_SetCE(bOpen,false))   //CE low
   bCE_High = false;
 bool bUpdated = false;
 for(int i = 0 ; i < NUM_OF_RF2401_REG; i++ )
 {
   if(pReg[i].byRegValue == pReg[i].byBakValue &&
	  pReg[i].dwRegValue == pReg[i].dwBakValue )
   {
    continue;
   }
   bUpdated = true;
 //  if( pReg[1].byAddr == RF2401_OBSERVE_TX || i == RF2401_RPD || i == RF2401_FIFO_STATUS)
  //  continue;
   Command = WRITE_REG + pReg[i].byAddr ;
   if( pReg[i].byAddr == RF2401_RX_ADDR_P0 || pReg[i].byAddr == RF2401_RX_ADDR_P1 || pReg[i].byAddr == RF2401_TX_ADDR)
   {
	len = 5 ;
	Txbuf[0] = pReg[i].byBakValue;
	Txbuf[1] = pReg[i].dwBakValue;
	Txbuf[2] = pReg[i].dwBakValue >> 8;
	Txbuf[3] = pReg[i].dwBakValue >> 16;
	Txbuf[4] = pReg[i].dwBakValue >> 24;
   }
   else
   {
	len = 1;
	Txbuf[0] = pReg[i].byBakValue;
   }
   if(USBIO_SPIWrite(bOpen,&Command,1,Txbuf,len) == false)
   {
	AddMemoString(UnicodeString("[ERRO]:SPI write  nRF2401 Register fail!"),clRed);
	return;
   }
   else
   {
   //	Command = READ_REG + pReg[RF2401_OBSERVE_TX].byAddr ;
  //	if(USBIO_SPIRead(bOpen,&Command,1,Rxbuf,1) && Rxbuf[0])
	{
	 pReg[i].byRegValue = pReg[i].byBakValue ;
	 pReg[i].dwRegValue = pReg[i].dwBakValue ;
	}
 /*	else
	{
	 AddMemoString(UnicodeString("[ERRO]:SPI write  nRF2401 Register fail!"),clRed);
	 return;
	} */
   }
 }
 if(bUpdated == false)
 {
	 AddMemoString(UnicodeString("[ERRO]:Update nRF2401 Register fail!"),clRed);
	 return;
 }

 UpdateSettingCtrl();
 AddMemoString(UnicodeString("[INFO]:Update  nRF2401 Register success!"),clBlue);
}
//---------------------------------------------------------------------------


void __fastcall TMainForm::Button2Click(TObject *Sender)
{
  if(bOpen == 0xFF)
  {
   AddMemoString(UnicodeString("[ERRO]:Please connect to device first!"),clRed);
   return;
  }
  TForm1* pForm = new TForm1(this);
  pForm->ShowModal();
  delete pForm;
}
//---------------------------------------------------------------------------
void _fastcall  TMainForm::AddMemoString(String& str, int color)
{
 AnsiString s;
 SYSTEMTIME systime;
 GetLocalTime(&systime);
 //s.sprintf("L%06d",RichEdit1->Lines->Count);
 s.sprintf("L%06d-%02d/%02d %02d:%02d:%02d",RichEdit1->Lines->Count,systime.wMonth,systime.wDay,systime.wHour,systime.wMinute,systime.wSecond);
 RichEdit1->Perform(WM_VSCROLL,SB_BOTTOM,0);
 RichEdit1->SelAttributes->Color = color;
 RichEdit1->Lines->Add(UnicodeString(s) + str);

}
//----------------------------------------------------------------------------


void __fastcall TMainForm::Button16Click(TObject *Sender)
{
  TMemo* pMemoWrite;
  DevInfo* pDev;
  TCheckBox* pCheckBox;
  DWORD dwWriteCnt;
  TLabel* pLabel;
  if(PageControl1->ActivePage == RF2401)
  {
	pDev = RF2401_dev;
	pMemoWrite = Memo4;
	pLabel = Label38;
	pCheckBox = CheckBox2;
  }
 OpenDialog1->Filter = "bin file (*.bin)|*.bin|all file (*.*)|*.*";
 if(OpenDialog1->Execute()==ID_OK)
 {
	char buff[10];
	pMemoWrite->Clear();
	int hFile = FileOpen(OpenDialog1->FileName,fmOpenRead);
	dwWriteCnt   =   FileSeek(hFile,0,2);   //ȡ�ļ�����
	FileSeek(hFile,0,0);
	char* pBuffer   =   new   char[dwWriteCnt+1];   //��pszBUffer�ĳ��Ⱥ��ļ��ĳ���һ��
	FileRead(hFile,   pBuffer,   dwWriteCnt);   //���ļ�
	FileClose(hFile);
	sprintf(buff,"%06d",dwWriteCnt);
	pDev->WriteBufUpdate(pBuffer,dwWriteCnt);
	pLabel->Caption = AnsiString(buff);
	bNeedUpdated = false;
	if(pCheckBox->Checked)
	{
	 BYTE* pBuffDes = new BYTE[(dwWriteCnt/16+1)*LINE_SIZE+1];
	 memset(pBuffDes,0,(dwWriteCnt/16+1)*LINE_SIZE+1);
	 Hex2String(pBuffer,dwWriteCnt,pBuffDes);
	 pMemoWrite->Clear();
	 pMemoWrite->Text = AnsiString((char*)pBuffDes);
	 delete []pBuffDes;
	}
	else
	{
	 if(CheckTextString(pDev->GetWriteBuf(),dwWriteCnt))
	 {
	  MessageBox(this->WindowHandle,"ֻ����ʽ��ʾ","���з���ʾ�ַ�",MB_OK);
	  pMemoWrite->ReadOnly = true;
	 }
	 HandleNull(pDev->GetWriteBuf(),dwWriteCnt,pBuffer);
	 pBuffer[dwWriteCnt] = 0;
	 pMemoWrite->Text = AnsiString(pBuffer);

	}
	delete pBuffer;
	AddMemoString(UnicodeString("[INFO]:Load " + OpenDialog1->FileName + " success!"),clBlue);
 }

}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Button5Click(TObject *Sender)
{
 OpenDialog1->Filter = "bin file (*.par)|*.par|all file (*.*)|*.*";
 if(OpenDialog1->Execute()==ID_OK)
 {
	int hFile = FileOpen(OpenDialog1->FileName,fmOpenRead);
	DWORD dwWriteCnt   =   FileSeek(hFile,0,2);   //ȡ�ļ�����
	if(dwWriteCnt != NUM_OF_RF2401_REG * 5)
	{
	 AddMemoString(UnicodeString("[ERRO]: invalid file format!"),clBlue);
	 FileClose(hFile);
	 return;
	}
	FileSeek(hFile,0,0);
	nRF2401Reg* pReg = (nRF2401Reg*)RF2401_dev->GetData();
	for(int i = 0 ; i < NUM_OF_RF2401_REG ; i ++)
	{
	 FileRead(hFile,&pReg[i].byBakValue,1);
	 //pReg[i].byBakValue = pReg[i].byRegValue;
	 FileRead(hFile,&pReg[i].dwBakValue,4);
	// pReg[i].dwBakValue = pReg[i].dwRegValue;
	}
	FileClose(hFile);
	UpdateSettingCtrl();
	AddMemoString(UnicodeString("[INFO]:Load " + OpenDialog1->FileName + " success!"),clBlue);
 }
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::Button8Click(TObject *Sender)
{
 AnsiString str;
 char serial[100] = {0};
 if(bOpen == INVALID_DEV_NO)
 {
   bOpen = USBIO_OpenDevice();
   if(bOpen == INVALID_DEV_NO)
   {
	 AddMemoString(UnicodeString("[ERRO]:Open USB2ISH fail!"),clRed);
	 return;
   }
   AddMemoString(UnicodeString("[INFO]:Open USB2ISH successl!"),clBlue);
   Button8->Caption = "�Ͽ��豸";
   USBIO_GetSerialNo(bOpen,serial);
   str.sprintf("USB2ish%d",bOpen);
   this->Caption = str + AnsiString("<") + AnsiString(serial) + AnsiString(">");
   USBIO_SetTrigNotify(bOpen,USBIO_Trig_Nofiy);
   byMode = MODE_UNKNOWN;
   if(USBIO_GetWorkMode(bOpen,&byMode) == false)
   {
	AddMemoString(UnicodeString("[ERRO]:Can't get current work mode!"),clRed);
   }
   if(byMode == MODE_NORMAL)
   {
	USBIO_SPIGetConfig(bOpen,&bySPI_RateIndex,&dwSPIRW_Timeout);
	StaticText2->Caption = "������:" + SPI_RateTab[bySPI_RateIndex];
	if(USBIO_TrigSetConfig(bOpen,1) == false)      //��Ϊ�½����ж�
	{
	 AddMemoString(UnicodeString("[ERRO]:Config Trigger fail!"),clRed);
	}
   else
	AddMemoString(UnicodeString("[INFO]:Config Trigger successl!"),clBlue);
   nRF24_ReadReg();
	}
 }
 else
 {
   Button8->Caption = "�����豸";
   this->Caption = AnsiString("USB2ish?");
   if(byMode == MODE_NORMAL)
	USBIO_ExitTrig(bOpen);
   USBIO_CloseDevice(bOpen);
   bOpen = INVALID_DEV_NO;
   byMode = MODE_UNKNOWN;
   AddMemoString(UnicodeString("[INFO]:Close USB2ISH success!!"),clBlue);
 }
  //nRF240_Init();

  UpdateSettingCtrl();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::N1Click(TObject *Sender)
{
 RichEdit1->Clear();
}
//---------------------------------------------------------------------------

void __fastcall TMainForm::N2Click(TObject *Sender)
{
  SaveDialog1->Filter = "txt file (*.txt)|*.txt|all file (*.*)|*.*";
 if(SaveDialog1->Execute()==ID_OK)
 {
  int hFile = FileCreate(SaveDialog1->FileName);
  FileWrite(hFile,RichEdit1->Text.t_str(),strlen(RichEdit1->Text.t_str()));
  FileClose(hFile);
 // RichEdit1->TE
  //Lines->SaveToFile(SaveDialog1->FileName+".txt");
  AddMemoString(UnicodeString("[INFO]:"+ SaveDialog1->FileName + " saved"),clBlue);
 }
}
//---------------------------------------------------------------------------

