//#ifndef EXTERN_DEF
//#define EXTERN_DEF

#include <string.h>
#include <stdio.h>

extern const unsigned char HexCode[16];
extern unsigned int String2Hex(unsigned char* pString,unsigned int uiStrLen,unsigned char* pHex);
extern void Hex2String(unsigned char* pHex,unsigned int uiHexLen,unsigned char* pString);
extern int CheckHexString(char* pString,unsigned long* pLen);
extern unsigned long String2Long(unsigned char* pSrc,unsigned long len);
extern void HandleNull(unsigned char* pSrc,unsigned long ulLen,unsigned char* pDes);
extern int CheckTextString(char* pString,unsigned long Len);
extern void ExtractVer(unsigned char* pBuff, unsigned char type,char* pVerTime);
unsigned char HexString2Byte(unsigned char* pBuff);
unsigned long  HexString2ULong(unsigned char* pBuff);
//#endif