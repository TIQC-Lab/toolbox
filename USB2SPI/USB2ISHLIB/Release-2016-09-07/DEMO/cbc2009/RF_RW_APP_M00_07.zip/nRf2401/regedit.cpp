//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "regedit.h"
#include "nRf2401.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "hexEdit"
#pragma resource "*.dfm"
//TForm3 *Form3;
const AnsiString ErrString[5] =
 {
 "ok",
 "����ȷ���ַ�!",
 "ȱ���ַ�!",
 "dddddddd",
 "û������!"
 };
extern "C"
{
 #include "extern_def.h"

}
//---------------------------------------------------------------------------
__fastcall TForm3::TForm3(TComponent* Owner,BYTE index,void* pReg)
	: TForm(Owner)
{
 pMyReg = pReg;
 myIndex = index;
}
//---------------------------------------------------------------------------
void __fastcall TForm3::FormCreate(TObject *Sender)
{
 //int i;
 AnsiString str;
 //for( i = 0 ; i < NUM_OF_RF2401_REG; i ++)
 {
  str.sprintf("0x%02X", ((nRF2401Reg*)pMyReg)->byAddr);
  StaticText5->Caption = str;
  StaticText4->Caption = ((nRF2401Reg*)pMyReg)->Name;

  if(myIndex == RF2401_RX_ADDR_P0 || myIndex == RF2401_RX_ADDR_P1 || myIndex == RF2401_TX_ADDR)
  {
   str.sprintf("%08X%02X",((nRF2401Reg*)pMyReg)->dwBakValue,((nRF2401Reg*)pMyReg)->byBakValue);
  }
  else
	str.sprintf("%02X",((nRF2401Reg*)pMyReg)->byBakValue);
  HexEdit1->Text = str;
  //ComboBox1->AddItem()
  StaticText6->Caption = AnsiString(nRF2401_Hint[myIndex][0]);
  StaticText7->Caption = AnsiString(nRF2401_Hint[myIndex][1]);
  StaticText8->Caption = AnsiString(nRF2401_Hint[myIndex][2]);
  StaticText9->Caption = AnsiString(nRF2401_Hint[myIndex][3]);
  StaticText10->Caption = AnsiString(nRF2401_Hint[myIndex][4]);
  StaticText11->Caption = AnsiString(nRF2401_Hint[myIndex][5]);
  StaticText12->Caption = AnsiString(nRF2401_Hint[myIndex][6]);
  StaticText13->Caption = AnsiString(nRF2401_Hint[myIndex][7]);
  //StaticText6->Caption = AnsiString(nRF2401_Hint[myIndex][0]);
 }
}
//---------------------------------------------------------------------------

void __fastcall TForm3::Button1Click(TObject *Sender)
{
 char* pBuff;
 BYTE err_code;
 DWORD AddrLen;
 UnicodeString str = HexEdit1->Text;
// WideCharToMultiChar(Edit3->Text.c_str(),Buff);
 pBuff = str.t_str();
 if(myIndex == RF2401_RX_ADDR_P0 || myIndex == RF2401_RX_ADDR_P1 || myIndex == RF2401_TX_ADDR)
 {

  err_code = CheckHexString(pBuff,&AddrLen);
  if(err_code)
  {
   ShowMessage(ErrString[err_code]);
   return;
  }
  if(AddrLen != 5)
  {
   ShowMessage("���볤�Ȳ���!");
   return;
  }
  ((nRF2401Reg*)pMyReg)->byBakValue = HexString2Byte(&pBuff[8]);
  ((nRF2401Reg*)pMyReg)->dwBakValue = HexString2ULong(pBuff);
 }
 else
 {
  err_code = CheckHexString(pBuff,&AddrLen);
  if(err_code)
  {
   ShowMessage(ErrString[err_code]);
   return;
  }
  if(AddrLen != 1)
  {
   ShowMessage("���볤�Ȳ���!");
   return;
  }
  ((nRF2401Reg*)pMyReg)->byBakValue = HexString2Byte(pBuff);
 }
 ModalResult = mrOk;
}
//---------------------------------------------------------------------------

void __fastcall TForm3::Button2Click(TObject *Sender)
{
 ModalResult = mrCancel;
}
//---------------------------------------------------------------------------

