//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "about.h"
#include "main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
//TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
 AnsiString ver,time;
 StaticText14->Caption = AnsiString((char*)VERSION);
 StaticText15->Caption = AnsiString((char*)__DATE__) + AnsiString(" ") + AnsiString((char*)__TIME__) ;
 if(MainForm->GetDevInfo(ver,time,0))
 {
 StaticText21->Caption = ver;
 StaticText20->Caption = time ;
 }
 if(MainForm->GetDevInfo(ver,time,1))
 {
  StaticText19->Caption = ver;
  StaticText18->Caption = time;
 }
 if(MainForm->GetDevInfo(ver,time,2))
 {
  StaticText17->Caption = ver;
  StaticText16->Caption = time ;
 }



 //Button1->Enabled = (MainForm->GetDevIndex() != INVALID_DEV_NO);

}
//---------------------------------------------------------------------------










