
#include <stdio.h>
#include <string.h>

#define false 0
#define true  1
const unsigned char HexCode[]={"0123456789ABCDEF"};


unsigned int String2Hex(unsigned char* pString,unsigned int uiStrLen,unsigned char* pHex);
void Hex2String(unsigned char* pHex,unsigned int uiHexLen,unsigned char* pString);
void HandleNull(unsigned char* pSrc,unsigned long ulLen,unsigned char* pDes);
int CheckHexString(char* pString,unsigned long* pLen);
int CheckTextString(char* pString,unsigned long Len);
unsigned long String2Long(unsigned char* pSrc,unsigned long len);
void ExtractVer(unsigned char* pBuff, unsigned char type,char* pVerTime);
unsigned char HexString2Byte(unsigned char* pBuff);
unsigned long HexString2ULong(unsigned char* pBuff);

/*hex code string to hex code*/
unsigned int String2Hex(unsigned char* pString,unsigned int uiStrLen,unsigned char* pHex)
{
 unsigned char code = 0;
 unsigned int i = 0;
 unsigned int j = 0;

 if(pString == NULL)
	return 0;
 for(i=0;i<uiStrLen;i++)
 {
  if(pString[i] <= '9' && pString[i] >= '0')
	code = code * 16 + (pString[i] - '0');
  else if(pString[i] <= 'F' && pString[i] >= 'A')
	code = code * 16 + (pString[i] - 'A' + 10);
  else if(pString[i] <= 'f' && pString[i] >= 'a')
   code = code * 16 + (pString[i] - 'a' + 10);
  else
   {
	if(j%2)
	  {
	   j--;
	   code = 0;
	  }
	continue;
   }
 j++;
 if(j%2==0)
 {
  pHex[j/2-1] = code;
  code = 0;
 }
 }
 return j/2;
}

/*string to hex code string*/
void Hex2String(unsigned char* pHex,unsigned int uiHexLen,unsigned char* pString)
{
   unsigned int i ,j,k,code;
   i = j = k = 0;
   while(i < uiHexLen)
   {
	if(k ==0)
	{
	// memset(&pString[j],' ',3);
	// j = j + 3;
	}
	code = pHex[i];
	pString[j++] = HexCode[code/16];
	pString[j++] = HexCode[code%16];
	pString[j++] = ' ';
	k++;
	i++;
	if(k == 8)
	{
   //	 memset(&pString[j],' ',1);
   //	 j = j + 1;
	}
	if(k == 16)
	{
	  pString[j++] = '\r';
	  pString[j++] = '\n';
	  k = 0;
	}
   }
}

/* return 0   --hex string*/
/* return 0x01   --hex string not hecode*/
/* return 0x02   --not include space*/
/* return 0x04   --null string*/
int CheckHexString(char* pString,unsigned long* pLen)
{
	int mlen,i,err_code;
	char c;
	unsigned int len = 0;
	char re = 0;
	if(!pString)
		return 0x04;
	mlen =strlen(pString);
	if(mlen==0)
	{
	  return  0x04;
	}
	for(i=0;i<mlen;i++)
	{
		c=pString[i];
		if(c == ' '||c == '\r'||c == '\n')
		{
		  if(len%2)
			//return 2;
			re |= 0x02;
		  else
            continue;
		}
		if ( c >= '0' && c <= '9' ||
		     c >= 'A' && c <= 'F' ||
			 c >= 'a' && c <= 'f' )
		{
		 len++;
		 continue;
		}
		else
		 //return 1;
		 re |= 0x01;

	}
		if(len%2)
          re |= 0x02;
		*pLen = len/2;
		return re;
}

unsigned long String2Long(unsigned char* pSrc,unsigned long len)
{
 unsigned long re = 0;
 int i;
 for(i = 0; i< len;i++)
 {
   re = re*256 + pSrc[i];
 }
 return re;
}

void HandleNull(unsigned char* pSrc,unsigned long ulLen,unsigned char* pDes)
{
 unsigned long i;
 for(i = 0; i<ulLen; i++)
 {
  //if(pSrc[i]>=0x20&&pSrc[i]<0x7F||pSrc[i]==0x0A||pSrc[i]==0x0D)
  if(pSrc[i]>0&&pSrc[i]<0x7F)
   pDes[i] = pSrc[i];
 //if(pSrc[i] == 0)
  else
  	pDes[i] = '?';
 // else

 }
}
/* judge if non-display char exists or not*/
int CheckTextString(char* pString,unsigned long Len)
{
 int i;
 for( i = 0; i < Len; i++)
 {
  //if(pString[i]>=0x20&&pString[i]<0x7F||pString[i]==0x0A||pString[i]==0x0D)
  if(pString[i]>0&&pString[i]<0x7F)
   continue;
  return 1;
 }
  return 0;
}

void ExtractVer(unsigned char* pBuff, unsigned char type,char* pVerTime)
{
 int i,j;
 char ver[30];
 char time[30];
 memset(ver,0,30);
 memset(time,0,30);
 for(i = 0 ; pBuff[i]!= ';' ; i ++)
 {
  ver[i] = pBuff[i];

 }
 i ++;
 j = 0;
 while(pBuff[i] && j < 30)
 {
  time[j] = pBuff[i];
  i ++;
  j ++;
 }
// time[j] = 0;
 if(type == 0)
   memcpy(pVerTime,ver,30);
 else
   memcpy(pVerTime,time,30);
}

unsigned char HexString2Byte(unsigned char* pBuff)
{
 unsigned char re = 0;
 if( pBuff[1] >= '0' && pBuff[1] <= '9' )
 {
  re = pBuff[1] - '0';
 }
 else if( pBuff[1] >= 'a' && pBuff[1] <= 'f' )
 {
  re = pBuff[1] - 'a' + 10;
 }
 else
 {
  re = pBuff[1] - 'A' + 10;
 }

 if( pBuff[0] >= '0' && pBuff[0] <= '9' )
 {
  re += ( pBuff[0] - '0' ) * 16;
 }
 else if( pBuff[0] >= 'a' && pBuff[0] <= 'f' )
 {
  re += ( pBuff[0] - 'a' + 10 ) * 16;
 }
 else
 {
  re += ( pBuff[0] - 'A' + 10 ) * 16;
 }
 return re;
}

unsigned long HexString2ULong(unsigned char* pBuff)
{
 int i ;
 unsigned long re = 0;

 for( i = 0 ; i < 8 ; i ++ )
 {
   if( pBuff[i] >= '0' && pBuff[i] <= '9' )
   {
	re += ( ( pBuff[i] - '0' ) << ( 7 - i )*4 );
   }
   else if( pBuff[i] >= 'a' && pBuff[i] <= 'f' )
   {
	re += ( ( pBuff[i] - 'a' + 10 ) << ( 7 - i )*4 );
   }
   else
   {
	re += ( ( pBuff[i] - 'A' + 10 ) << ( 7 - i )*4 );
   }
 }
 return re;
}

