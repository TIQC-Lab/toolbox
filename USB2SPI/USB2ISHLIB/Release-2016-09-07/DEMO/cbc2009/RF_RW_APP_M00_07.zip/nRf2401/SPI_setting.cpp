
#include <vcl.h>
#pragma hdrstop

#include "SPI_setting.h"
#include "extern_def.h"
#include "usbio.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner, BYTE index, DWORD timeout)
	: TForm(Owner)
{
 myIndex = index;
 myTimeout = timeout;
}
//---------------------------------------------------------------------------




void __fastcall TForm2::Button8Click(TObject *Sender)
{
 char Buff[100];
// WideCharToMultiChar(Edit21->Text,Buff);
 myTimeout = Edit21->Text.ToInt()<<16;
// WideCharToMultiChar(Edit22->Text,Buff);
 myTimeout = myTimeout + (Edit22->Text.ToInt());
 myIndex = ComboBox29->ItemIndex;
// if(USBIO_SPISetConfig(bOpen,myIndex,myTimeout))
 {
   ModalResult = mrOk;
  }
 // else
 //  ShowMessage("����ʧ��");
  myExeCode = 2;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::FormCreate(TObject *Sender)
{
 AnsiString str;
 ComboBox29->ItemIndex = myIndex;
 str.sprintf("%d",myTimeout>>16);
 Edit21->Text = str;
 str.sprintf("%d",myTimeout&0xFFFF);
 Edit22->Text = str;

}
//---------------------------------------------------------------------------

void __fastcall TForm2::Button1Click(TObject *Sender)
{
  ModalResult = mrCancel;
  myExeCode = 0;
}
//---------------------------------------------------------------------------

void __fastcall TForm2::Button26Click(TObject *Sender)
{
  myExeCode = 1;
//  USBIO_ResetDevice(bOpen,DEV_SPI);
//  USBIO_SPIGetConfig(bOpen,&myIndex,&myTimeout);
  ModalResult = mrOk;
}
//---------------------------------------------------------------------------

