#ifndef nRF2401_h
#define nRF2401_h
#define READ_REG     0x00       // Define read command to register
#define WRITE_REG    0x20       // Define write command to register
#define RD_RX_PLOAD  0x61       // Define RX payload register address
#define WR_TX_PLOAD  0xA0       // Define TX payload register address
#define FLUSH_TX     0xE1       // Define flush TX register command
#define FLUSH_RX     0xE2       // Define flush RX register command
#define REUSE_TX_PL  0xE3       // Define reuse TX payload register command
#define R_RX_PL_WID  0x60       //Read RX payload width for the top
#define W_ACK_PAYLOAD 0xA8      //Write Payload to be transmitted together with ACK packet on PIPE PPP.
#define W_TX_PAYLOAD_NOACK  0xB0
#define NOP 0xFF                // Define No Operation, might be used to read status register

typedef enum
{
 RF2401_POWER_DOWN_MODE = 0,
 RF2401_IDLE_MODE,
 RF2401_RX_MODE,
 RF2401_TX_MODE,
 RF2401_TX_RX_MODE,
 RF2401_TX_RET_MODE,
 NUM_OF_RF2401_MODE
}enu_nRf2401_Mode;

typedef enum
{
 RF2401_CONFIG = 0,
 RF2401_ENAA,
 RF2401_ENRXADDR,
 RF2401_SETUPAW,
 RF2401_SETUPRETR,  //0x04
 RF2401_RFCH,
 RF2401_SETUP,
 RF2401_STATUS,
 RF2401_OBSERVE_TX,
 RF2401_RPD,           //0x09
 RF2401_RX_ADDR_P0,
 RF2401_RX_ADDR_P1,
 RF2401_RX_ADDR_P2,
 RF2401_RX_ADDR_P3,
 RF2401_RX_ADDR_P4,    //0x0E
 RF2401_RX_ADDR_P5,
 RF2401_TX_ADDR,
 RF2401_RX_PW_P0,
 RF2401_RX_PW_P1,
 RF2401_RX_PW_P2,      //0x13
 RF2401_RX_PW_P3,
 RF2401_RX_PW_P4,
 RF2401_RX_PW_P5,
 RF2401_FIFO_STATUS,  //0x17
 RF2401_DYNPD,
 RF2401_FEATURE,
 NUM_OF_RF2401_REG,
}enu_nRf2401_Reg ;

const char* nRF2401_RF_PWR [] =
{
 "-18dBm",
 "-12dBm",
 "-6dBm",
 "0dBm",
};

const char* nRF2401_reg_name[NUM_OF_RF2401_REG] =
{
 "CONFIG",
 "ENAA",
 "ENRXADDR",
 "SETUPAW",
 "SETUPRETR",  //0x04
 "RFCH",
 "RF_SETUP",
 "STATUS",
 "OBSERVE_TX",
 "RPD",           //0x09
 "RX_ADDR_P0",
 "RX_ADDR_P1",
 "RX_ADDR_P2",
 "RX_ADDR_P3",
 "RX_ADDR_P4",    //0x0E
 "RX_ADDR_P5",
 "TX_ADDR",
 "RX_PW_P0",
 "RX_PW_P1",
 "RX_PW_P2",      //0x13
 "RX_PW_P3",
 "RX_PW_P4",
 "RX_PW_P5",
 "FIFO_STATUS",  //0x17
 "DYNPD",
 "FEATURE"
};

typedef struct
{
 BYTE  byAddr;
 BYTE  byRegValue;
 BYTE  byBakValue;
 DWORD dwRegValue;
 DWORD dwBakValue;
 char Name[255];
}nRF2401Reg;


 const char nRF2401_Hint[NUM_OF_RF2401_REG][8][100] =
 {
  {                                      //CONFIG
   "B7: Reserved  Only '0' allowed",
   "B6: Mask interrupt caused by RX_DR",
   "B5: Mask interrupt caused by TX_DS",
   "B4: Mask interrupt caused by MAX_RT",
   "B3: Enable CRC",
   "B2: CRC encoding scheme",
   "B1: 1: POWER UP, 0:POWER DOWN",
   "B0: WRX/TX control,1: PRX, 0: PTX"
  },
  {                                      //ENAA
   "B7~6: Reserved Only '00' allowed",
   "B5:   Enable auto acknowledgement data pipe 5",
   "B4:   Enable auto acknowledgement data pipe 4",
   "B3:   Enable auto acknowledgement data pipe 3",
   "B2:   Enable auto acknowledgement data pipe 2",
   "B1:   Enable auto acknowledgement data pipe 1",
   "B0:   Enable auto acknowledgement data pipe 0",
   ""
  },
  {                                      //ENRXADDR
   "B7~6: Reserved Only '00' allowed",
   "B5:   Enable data pipe 5",
   "B4:   Enable data pipe 4",
   "B3:   Enable data pipe 3",
   "B2:   Enable data pipe 2",
   "B1:   Enable data pipe 1",
   "B0:   Enable data pipe 0",
   "",
  },
  {                                      //SETUPAW
   "B7~2: Reserved Only '000000' allowed",
   "B1~0: RX/TX Address field width",
   "           '00' - Illegal",
   "           '01' - 3 bytes",
   "           '10' - 4 bytes",
   "           '11' �C 5 bytes",   
  },
  {                                      //SETUPRETR
   "B7~4: Auto Retransmit Delay",
   "           '0000' �C Wait 250��S",
   "           '0001' �C Wait 500��S",
   "           '1111' �C Wait 4000uS",
   "B3~0: Auto Retransmit Count",
   "           '0000' �CReTransmit disabled",
   "           '0001' �CUp to 1 ReTransmit on fail of AA",
   "           '1111' �CUp to 15 ReTransmit on fail of AA"
  },
  {                                      //RFCH
   "B7:   Reserved  Only '0' allowed",
   "B6~0: Sets the frequency channel",
   "",
   "",
   "",
   "",
   "",
   ""
  },
  {                                      //RF_SETUP
   "B7:   Enables continuous carrier transmit",
   "B6:   Reserved  Only '0' allowed",
   "B5:   Set RF Data Rate to 250kbps",
   "B4:   Force PLL lock signal",
   "B3:   Select between the high speed data rates",
   "B2~1: Set RF output power in TX mode",
   "             00- -18db,01- -12db,10- -6db,11- 0db",
   "B0:   don't care"
  },
  {                                      //STATUS
   "B7:   Reserved  Only '0' allowed",
   "B6:   Data Ready RX FIFO interrupt",
   "B5:   Data Sent TX FIFO interrupt",
   "B4:   Maximum number of TX retransmits interrupt",
   "B3~1: valid data pipe number for RX_FIFO",
   "             000-101: Data Pipe Number",
   "             111: RX FIFO Empty",
   "B0:   TX Full flag"
  },
  {                                      //OBSERVE_TX
   "B7~4: Count lost packets",
   "             Read only",
   "",
   "",
   "B3~0: Count retransmitted packets",
   "             Read only",
   " ",
   " "
  },
  {                                      //RPD
   "B7~1: Reserved , Read only",
   "B0:   Received Power Detector.",
   " ",
   " ",
   " ",
   " ",
   " ",
   " "
  },
  {                                      //RX_ADDR_P0
   "B39~0: Receive address data pipe 0",
   "       5 Bytes maximum length",
   "       LSByte is written first",
   "       Write the number of bytes",
   "       defined by SETUP_AW",
   " ",
   " ",
   " "
  },
  {                                      //RX_ADDR_P1
   "B39~0: Receive address data pipe 1",
   "       5 Bytes maximum length",
   "       LSByte is written first",
   "       Write the number of bytes",
   "       defined by SETUP_AW",
   " ",
   " ",
   " "
  },
  {                                      //RX_ADDR_P2
   "B7~0: Receive address data pipe 2",
   "      Only LSB",
   "      MSBytes are equal to ",
   "      RX_ADDR_P1[39:8]",
   " ",
   " ",
   " ",
   " "
  },
  {                                      //RX_ADDR_P3
   "B7~0: Receive address data pipe 3",
   "      Only LSB",
   "      MSBytes are equal to ",
   "      RX_ADDR_P1[39:8]",
   " ",
   " ",
   " ",
   " "
  },
  {                                      //RX_ADDR_P4
   "B7~0: Receive address data pipe 4",
   "      Only LSB",
   "      MSBytes are equal to ",
   "      RX_ADDR_P1[39:8]",
   " ",
   " ",
   " ",
   " "
 },
  {                                      //RX_ADDR_P5
   "B7~0: Receive address data pipe 5",
   "      Only LSB",
   "      MSBytes are equal to ",
   "      RX_ADDR_P1[39:8]",
   " ",
   " ",
   " ",
   " "

  },
  {                                      //TX_ADDR
   "B39~0: Transmit address",
   "       Used for a PTX device only.",
   " ",
   " ",
   " ",
   " ",
   " ",
   " "
  },
  {                                      //RX_PW_P0
   "B7~6: Reserved  Only '00' allowed",
   "B5~0: Number of bytes in RX payload in pipe 0",
   "            0- Pipe not used",
   "            000001- 1BYTE",
   "            100000- 32BYTEs",
   " ",
   " ",
   " "
  },
  {                                      //RX_PW_P1
   "B7~6: Reserved  Only '00' allowed",
   "B5~0: Number of bytes in RX payload in pipe 1",
   "            0- Pipe not used",
   "            000001- 1BYTE",
   "            100000- 32BYTEs",
   " ",
   " ",
   " "
  },
  {                                      //RX_PW_P2
   "B7~6: Reserved  Only '00' allowed",
   "B5~0: Number of bytes in RX payload in pipe 2",
   "            0- Pipe not used",
   "            000001- 1BYTE",
   "            100000- 32BYTEs",
   " ",
   " ",
   " "
  },
  {                                      //RX_PW_P3
   "B7~6: Reserved  Only '00' allowed",
   "B5~0: Number of bytes in RX payload in pipe 3",
   "            0- Pipe not used",
   "            000001- 1BYTE",
   "            100000- 32BYTEs",
   " ",
   " ",
   " "
  },
  {                                      //RX_PW_P4
   "B7~6: Reserved  Only '00' allowed",
   "B5~0: Number of bytes in RX payload in pipe 4",
   "            0- Pipe not used",
   "            000001- 1BYTE",
   "            100000- 32BYTEs",
   " ",
   " ",
   " "
  },
  {                                      //RX_PW_P5
   "B7~6: Reserved  Only '00' allowed",
   "B5~0: Number of bytes in RX payload in pipe 5",
   "            0- Pipe not used",
   "            000001- 1BYTE",
   "            100000- 32BYTEs",
   " ",
   " ",
   " "
  },
  {                                      //FIFO_STATUS
   "B7: Reserved  Only '0' allowed",
   "B6: Used for a PTX device",
   "B5: TX FIFO full flag",
   "B4: TX FIFO empty flag",
   "B3~2: Only '00' allowed",
   "B1: RX FIFO full flag",
   "B0: RX FIFO empty flag",
   " "
  },
  {                                      //DYNPD
   "B7~6: Reserved  Only '00' allowed",
   "B5:   Enable dynamic PLD length data pipe5",
   "B4:   Enable dynamic PLD length data pipe4",
   "B3:   Enable dynamic PLD length data pipe3",
   "B2:   Enable dynamic PLD length data pipe2",
   "B1:   Enable dynamic PLD length data pipe1",
   "B0:   Enable dynamic PLD length data pipe0",
   " "
  },
  {                                      //FEATURE
   "B7~3: Reserved  Only '00000' allowed",
   "B2:   Enables Dynamic PLD Length",
   "B1:   Enables Payload with ACK",
   "B0:   Enables the W_TX_PAYLOAD_NOACK command",
   " ",
   " ",
   " ",
   " "
  }
 };
#endif
