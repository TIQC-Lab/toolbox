﻿Public Class Form1
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Close()
    End Sub
    Public Sub SetData(ByVal str1 As String, ByVal str2 As String, ByVal str3 As String)
        Label5.Text = str1
        Label6.Text = str2
        Label7.Text = str3
    End Sub
End Class