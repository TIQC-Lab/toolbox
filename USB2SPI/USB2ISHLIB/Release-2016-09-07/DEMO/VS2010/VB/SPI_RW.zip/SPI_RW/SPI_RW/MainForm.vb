﻿Imports System.Threading

'Imports System
'Imports System.Runtime.InteropServices




Public Class MainForm
    Public INFINITE = &HFFFFFFFFUI
    Public EXT_IO_TRIG = &HAA      'external IO trigger 
    Public SPI_READ_TRIG = &HB0    'SPI  read trigger only use at SPI as slaver
    Public SPI_WRITE_TRIG = &HB1   'SPI  write trigger only use at SPI as slaver
    
    Dim byDeviceId As Byte
    Dim serialNo As String
    Dim spiCfg As Byte
    Dim timeoutRW As Long
    Dim workMode As Byte
    Dim readCnt, WriteCnt As UInteger
    ' Dim runThread As Thread
    '  Private Sub readTrig()
    'Dim msg As UInteger
    '     While True
    '        If (USBIO_ReadTrig(byDeviceId, msg, INFINITE)) Then
    '            handleTrig(msg)
    '       End If
    '    End While
    ' End Sub
    Private Sub handleTrig(ByVal msg As UInteger)
        Dim length As Byte
        Dim flag As Byte
        length = (msg / &H80) And &HFF
        flag = msg / &HFF
        Select Case flag
            Case SPI_WRITE_TRIG
                receData(length)
            Case EXT_IO_TRIG
                IOTrigged()
            Case Else
        End Select
    End Sub
    Private Sub receData(ByVal length As Byte)
        Dim readBuff() As Byte
        Dim lpPara(2) As Byte
        Dim str As String
        ReDim readBuff(length)
        str = ""
        If (USBIO_SPIRead(byDeviceId, lpPara, 0, readBuff, length)) Then
            Val2Str(str, readBuff, length, TextBox3.Text.Length Mod 50)
            TextBox3.Text = TextBox3.Text + str
            readCnt = readCnt + length
            InitControl()
        End If
    End Sub
    Private Sub IOTrigged()

    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        Close()
    End Sub

    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        byDeviceId = 255
        serialNo = "??????????"
        spiCfg = 4
        timeoutRW = &HC800C8
        readCnt = 0
        WriteCnt = 0
        InitControl()
        USBIO_SetUSBNotify(False, AddressOf USB_Event)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If (byDeviceId = 255) Then
            byDeviceId = USBIO_OpenDevice()
            If (byDeviceId = 255) Then
                MsgBox("No found usb2ish device!")
            Else

                USBIO_GetSerialNo(byDeviceId, serialNo)

                USBIO_SPIGetConfig(byDeviceId, spiCfg, timeoutRW)
                USBIO_GetWorkMode(byDeviceId, workMode)
                USBIO_SetTrigNotify(byDeviceId, AddressOf Trig_Event)
                'runThread = New Thread(AddressOf readTrig)
                ' runThread.Start()

            End If
        Else
            CloseDevice()
        End If
        InitControl()
    End Sub

    Public Sub InitControl()
        Dim tmpstr As String
        ComboBox1.SelectedIndex = spiCfg And &HF
        ComboBox2.SelectedIndex = (spiCfg And &H30) / 16
        If (spiCfg And &H80) Then
            CheckBox1.Checked = True
        Else
            CheckBox1.Checked = False
        End If

        tmpstr = Format("%d", timeoutRW And &HFFFF)
        TextBox1.Text = tmpstr
        tmpstr = Format("%d", Int(timeoutRW / &H10000))
        TextBox2.Text = tmpstr
        Label11.Text = readCnt.ToString("00000000")
        Label12.Text = WriteCnt.ToString("00000000")
        If (byDeviceId = 255) Then
            Button1.Text = "Connntect"
            sFormTitle = "SPI_RW::" + "???"
            Me.Text = sFormTitle
        Else
            Button1.Text = "Disconntect"
            sFormTitle = "SPI_RW::" + serialNo
            Me.Text = sFormTitle
        End If
    End Sub
    Private Function IsHex(ByVal str As String) As Boolean
        Dim length As Short
        Dim i As Short
        length = str.Length()
        If (length = 0) Then
            Return True
        End If
        If (length Mod 2 Or length > 256) Then
            Return False
        End If
        For i = 0 To length - 1
            If ((str(i) >= "0") And (str(i) <= "9")) Then
                Continue For
            ElseIf ((str(i) >= "a") And (str(i) <= "f")) Then
                Continue For
            ElseIf ((str(i) >= "A") And (str(i) <= "F")) Then
                Continue For
            Else
                Return False
            End If
        Next i
        Return True
    End Function
    Private Function IsDigit(ByVal str As String) As Boolean
        Dim length As Short
        Dim i As Short
        length = str.Length()
        If (length = 0) Then
            Return False
        End If
        For i = 0 To length - 1
            If ((str(i) >= "0") And (str(i) <= "9")) Then
                Continue For
            Else
                Return False
            End If
        Next i
        Return True
    End Function
    Private Function BcdToChar(ByVal iBcd As Byte) As Char
        Dim hexVar As String = "0123456789ABCDEF"
        Return hexVar(iBcd)
    End Function
    Private Function CharToBcd(ByVal ch As Char) As Byte
        Dim mBCD As Byte
        If ch >= "0" And ch <= "9" Then
            mBCD = AscW(ch) - AscW("0")
        ElseIf ch >= "a" And ch <= "f" Then
            mBCD = AscW(ch) - AscW("f") + 10
        ElseIf ch >= "A" And ch <= "F" Then
            mBCD = AscW(ch) - AscW("A") + 10
        End If
        Return (mBCD)
    End Function
    Private Sub Str2Val(ByRef bytes() As Byte, ByVal str As String)
        Dim length As UInteger
        Dim j, i As UInteger
        Dim chH, chL As Char
        length = str.Length()
        j = 0
        i = 0
        While (j < length)
            chH = str(j)
            If (chH = Chr(32) Or chH = Chr(13) Or chH = Chr(10)) Then
                j = j + 1
            Else
                j = j + 1
                chL = str(j)
                bytes(i) = (CharToBcd(chH) * 16 + CharToBcd(chL))
                j = j + 1
                i = i + 1
            End If

        End While

    End Sub
    Private Sub Val2Str(ByRef str As String, ByVal bytes() As Byte, ByVal len As UInteger, ByVal start As Byte)
        Dim i As UInteger
        Dim j As Byte
        j = start
        For i = 0 To len - 1
            str = str.Insert(str.Length, Chr(32))
            str = str.Insert(str.Length, bytes(i).ToString("X2"))
            j = j + 3
            If (j >= 48) Then
                str = str.Insert(str.Length, Chr(13))
                str = str.Insert(str.Length, Chr(10))
                j = 0
            End If
        Next

    End Sub
    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        Dim tmp As Byte
        Dim tmptime As UInteger
        tmp = 0
        If (workMode = 1) Then    'upgrade mode
            MsgBox("Please check jumpper and make sure it in normal mode")
            Return
        End If
        If CheckBox1.Checked Then
            tmp = &H80
        End If
        tmp = tmp + ComboBox1.SelectedIndex
        tmp = tmp + ComboBox2.SelectedIndex * 16
        tmptime = Convert.ToInt32(TextBox1.Text)
        tmptime = tmptime + Convert.ToInt32(TextBox2.Text) * 256 * 256
        If (USBIO_SPISetConfig(byDeviceId, tmp, tmptime)) Then
            spiCfg = tmp
            timeoutRW = tmptime
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim length As UInteger
        Dim command(256) As Byte
        Dim readBuff(1024) As Byte
        Dim str As String
        If (byDeviceId = 255) Then    'upgrade mode
            MsgBox("Please connect the device")
            Return
        End If
        If (workMode = 1) Then    'upgrade mode
            MsgBox("Please check jumpper and make sure it in normal mode")
            Return
        End If
        If (spiCfg And &H80) Then    'upgrade mode
            MsgBox("SPI work as slaver")
            Return
        End If
        If (IsHex(TextBox4.Text) = False) Then
            MsgBox("Please input corrent hex string for command ")
            Return
        End If
        If (IsDigit(TextBox5.Text) = False) Then
            MsgBox("Please input correct digit string for length")
            Return
        End If
        length = Convert.ToInt32(TextBox5.Text)
        If (length >= 65534) Then
            MsgBox("Read length must less than 65535")
            Return
        End If
        Str2Val(command, TextBox4.Text)
        ReDim readBuff(length)
        str = ""
        If (CheckBox2.Checked) Then
            If (USBIO_SPITest(byDeviceId, command, readBuff, TextBox4.Text.Length / 2)) Then
                Val2Str(str, readBuff, TextBox4.Text.Length / 2, TextBox3.Text.Length Mod 50)
                TextBox3.Text = TextBox3.Text + str
                readCnt = readCnt + TextBox4.Text.Length / 2
                InitControl()

            End If
            Return
        End If

        If (USBIO_SPIRead(byDeviceId, command, TextBox4.Text.Length / 2, readBuff, length)) Then
            Val2Str(str, readBuff, length, TextBox3.Text.Length Mod 50)
            TextBox3.Text = TextBox3.Text + str
            readCnt = readCnt + length
            InitControl()

        End If
    End Sub


    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        TextBox3.Clear()
        readCnt = 0
        InitControl()


    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        TextBox8.Clear()
        WriteCnt = 0
        InitControl()

    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim sourcename As String
        Dim f As System.IO.FileStream
        Dim readBuff(1024) As Byte
        If readCnt = 0 Then
            MsgBox("No data for save")
            Return
        End If
        If (SaveFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            sourcename = SaveFileDialog1.FileName
            f = IO.File.Open(sourcename, IO.FileMode.Create, IO.FileAccess.Write)
            ReDim readBuff(readCnt)
            Str2Val(readBuff, TextBox4.Text)
            f.Write(readBuff, 0, readCnt)
            f.Close()
        End If
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim sourcename As String
        Dim f As System.IO.FileStream
        Dim length As UInteger
        Dim WriteBuff(1024) As Byte
        Dim str As String
        If (OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            sourcename = OpenFileDialog1.FileName
            f = IO.File.Open(sourcename, IO.FileMode.Open, IO.FileAccess.Read)
            length = f.Length
            ReDim WriteBuff(length)
            str = ""
            Val2Str(str, WriteBuff, length, 0)
            f.Read(WriteBuff, 0, length)
            TextBox8.Text = str
            WriteCnt = length
            InitControl()
            f.Close()
        End If
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        Dim command(256) As Byte
        Dim WriteBuff(1024) As Byte
        If (byDeviceId = 255) Then    'disconnected
            MsgBox("Please connect the device")
            Return
        End If
        If (workMode = 1) Then    'upgrade mode
            MsgBox("Please check jumpper and make sure it in normal mode")
            Return
        End If
        If (spiCfg And &H80) Then    'slaver mode
            MsgBox("SPI work as slaver")
            Return
        End If
        If (IsHex(TextBox7.Text) = False) Then
            MsgBox("Please input corrent hex string for command ")
            Return
        End If
        If (TextBox7.Text.Length = 0 And WriteCnt = 0) Then
            MsgBox("Please input write data ")
            Return
        End If
        If (WriteCnt >= 65534) Then
            MsgBox("Write length must less than 65535")
            Return
        End If
        Str2Val(command, TextBox7.Text)
        ReDim WriteBuff(WriteCnt)
        Str2Val(WriteBuff, TextBox8.Text)
        If (USBIO_SPIWrite(byDeviceId, command, TextBox7.Text.Length / 2, WriteBuff, WriteCnt)) Then
            'MsgBox("Write length must less than 65535")
        End If
    End Sub

    Private Sub MainForm_FormClosed(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles MyBase.FormClosed
        CloseDevice()
    End Sub
    Private Sub CloseDevice()
        If (byDeviceId <> 255) Then
            If (spiCfg And &H80) Then  'at slave mode ,first exit
                spiCfg = spiCfg And &H7F
                USBIO_SPISetConfig(byDeviceId, spiCfg, timeoutRW)
            End If
            'runThread.Abort()
            USBIO_CloseDevice(byDeviceId)
            byDeviceId = 255
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim dllVersion, sysVersion, MCUVersion As String
        If (byDeviceId = 255) Then
            MsgBox("Please connect the device")
            Return
        End If
        dllVersion = "aaa                                                                   "
        sysVersion = "bbb                                                                   "
        MCUVersion = "ccc                                                                   "
        USBIO_GetVersion(byDeviceId, 0, dllVersion)
        USBIO_GetVersion(byDeviceId, 1, sysVersion)
        USBIO_GetVersion(byDeviceId, 2, MCUVersion)
        Form1.SetData(dllVersion, sysVersion, MCUVersion)

        Form1.ShowDialog()

    End Sub
    Protected Overrides Sub WndProc(ByRef m As System.Windows.Forms.Message)
        If m.Msg = WM_USB_STATUS Then
            If (m.WParam = byDeviceId And m.LParam <> &H80) Then
                USBIO_CloseDevice(byDeviceId)
                byDeviceId = 255
                InitControl()
            End If
        End If
        If m.Msg = WM_TRIG_STATUS Then
            If (m.WParam = byDeviceId) Then
                handleTrig(m.LParam)
            End If
        End If
        MyBase.WndProc(m)
    End Sub
    Public Function USB_Removed(ByVal byIndex As Byte, ByVal dwUSBStatus As UInteger) As Boolean
        If (byIndex = byDeviceId And dwUSBStatus <> &H80) Then
            USBIO_CloseDevice(byDeviceId)
            byDeviceId = 255
            InitControl()
        End If
        Return True
    End Function

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged

    End Sub
End Class
