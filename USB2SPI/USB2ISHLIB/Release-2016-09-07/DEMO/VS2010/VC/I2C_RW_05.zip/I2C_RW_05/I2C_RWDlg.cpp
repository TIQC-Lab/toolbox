// SPI_RWDlg.cpp : implementation file
//

#include "stdafx.h"
#include "I2C_RW.h"
#include "I2C_RWDlg.h"
#include "AboutDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "usbio.h"


HWND mainhwnd;
bool  USBIO_Status_Nofiy (BYTE iDevIndex, DWORD dwStatus); 

bool  USBIO_Status_Nofiy (BYTE iDevIndex, DWORD dwStatus)
{
 PostMessage(mainhwnd,WM_USB_STATUS,iDevIndex,dwStatus);
 return true;
}



/////////////////////////////////////////////////////////////////////////////
// CI2C_RWDlg dialog

CI2C_RWDlg::CI2C_RWDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CI2C_RWDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CI2C_RWDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CI2C_RWDlg::~CI2C_RWDlg()
{
  if(byDevIndex != 0xFF)
  {
    
   USBIO_CloseDevice(byDevIndex);
  }
  delete I2C_dev;
}

void CI2C_RWDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CI2C_RWDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CI2C_RWDlg, CDialog)
	//{{AFX_MSG_MAP(CI2C_RWDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(ID_QUIT, OnQuit)
	ON_BN_CLICKED(ID_CONNECT, OnConnect)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON6, OnButton6)
	ON_BN_CLICKED(IDC_BUTTON10, OnButton10)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	ON_BN_CLICKED(IDC_BUTTON7, OnButton7)
	ON_BN_CLICKED(IDC_BUTTON9, OnButton9)
	ON_BN_CLICKED(IDC_BUTTON8, OnButton8)
	ON_MESSAGE(WM_USB_STATUS, USB_StatusChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CI2C_RWDlg message handlers

BOOL CI2C_RWDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	mainhwnd=GetSafeHwnd(); 
    //#ifdef FM_TIRGER_FUNCTION
	USBIO_SetUSBNotify(true,USBIO_Status_Nofiy);
   // #else
//	USBIO_SetNotify(USBIO_Status_Nofiy,NULL);   //ע�����֪ͨ  
  //  #endif
	dwWriteIndex = 0;
	byDevIndex = 0xFF;
	I2C_dev = new DevInfo(DEV_I2C);
    I2C_dev->byRateIndex = 0;
    I2C_dev->byDevAddr = 0xA0;
    I2C_dev->dwTimeout = 0x00C8000C8;
    EnumDevice();
    UpdateController();
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CI2C_RWDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CI2C_RWDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CI2C_RWDlg::UpdateController()
{
 char temp[20];
 ((CComboBox*)GetDlgItem(IDC_COMBO1))->SetCurSel(I2C_dev->byRateIndex);

 sprintf(temp,"%d",I2C_dev->dwTimeout & 0xFFFF);
 ((CEdit*)GetDlgItem(IDC_EDIT1))->SetWindowText(temp);
 sprintf(temp,"%d",I2C_dev->dwTimeout >> 16);
 ((CEdit*)GetDlgItem(IDC_EDIT2))->SetWindowText(temp);
  sprintf(temp,"%02x",I2C_dev->byDevAddr);
 ((CEdit*)GetDlgItem(IDC_EDIT7))->SetWindowText(temp);
 ((CEdit*)GetDlgItem(IDC_EDIT1))->EnableWindow(byDevIndex != 0xFF);
 ((CEdit*)GetDlgItem(IDC_EDIT2))->EnableWindow(byDevIndex != 0xFF);
 ((CEdit*)GetDlgItem(IDC_EDIT7))->EnableWindow(byDevIndex != 0xFF);

 ((CButton*)GetDlgItem(IDC_BUTTON10))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_BUTTON4))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_BUTTON5))->EnableWindow(byDevIndex != 0xFF);

 ((CButton*)GetDlgItem(IDC_BUTTON1))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_BUTTON2))->EnableWindow(byDevIndex != 0xFF);

}

void CI2C_RWDlg::OnQuit() 
{
 OnOK();	
}

void CI2C_RWDlg::OnConnect() 
{
  CListBox* pList = ((CListBox*)GetDlgItem(IDC_LIST5));
  if(byDevIndex != 0xFF)
	{
	    USBIO_CloseDevice(byDevIndex);        
	    byDevIndex = 0xFF;        
        GetDlgItem(ID_CONNECT)->SetWindowText("����");
		SetWindowText("I2C��д��ʾ����::�豸δ����");
	}
	else
	{
	 int selectItem = pList->GetCurSel();
	 char serialNo[50];
	 if( selectItem == LB_ERR )
	 {
	   MessageBox("��ѡ��һ���豸���к�!");
	   return ;
	}
     pList->GetText(selectItem, serialNo);
     byDevIndex = USBIO_OpenDeviceByNumber(serialNo);
	 if(byDevIndex == 0xFF)
	 {
  		MessageBox("���豸ʧ��!");
		return ;
	 }
	else
	{
	  GetDlgItem(ID_CONNECT)->SetWindowText("�Ͽ�");
	  SetWindowText(CString("I2C��д��ʾ����::<")+CString(serialNo)+CString(">"));
      USBIO_I2cGetConfig(byDevIndex,&I2C_dev->byDevAddr,&I2C_dev->byRateIndex,&I2C_dev->dwTimeout);
 	}
	}	
	UpdateController();
}

void CI2C_RWDlg::EnumDevice()
{
  int i;
  char SerialNo[20];
  BYTE MaxDevNum = USBIO_GetMaxNumofDev();
  while(((CListBox*)GetDlgItem(IDC_LIST5))->GetCount())
  {
   ((CListBox*)GetDlgItem(IDC_LIST5))->DeleteString( 0 );
  }

  for( i = 0 ; i < MaxDevNum; i++)
  {
	if(USBIO_GetSerialNo(i,SerialNo))
	{
	 ((CListBox*)GetDlgItem(IDC_LIST5))->AddString(SerialNo);
	}
  }
}

LRESULT CI2C_RWDlg::USB_StatusChange(WPARAM wParam, LPARAM lParam)
{
  if(lParam&0x80)                    //usb dev plugged
  {

  }
  else
  {
	 if(byDevIndex == (BYTE)wParam)
	   {
		SetWindowText("SPI��д��ʾ����::�豸δ����");	   
		byDevIndex = 0xFF;
		GetDlgItem(ID_CONNECT)->SetWindowText("����");
		UpdateController();
	   }

  }
  EnumDevice();
  return 0;
}


void CI2C_RWDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
  DWORD dwTimeout;
  CString str;
  BYTE byRate;
  BYTE byAddr;
  BYTE byValue;
  char Buff[100];
 ((CEdit*)GetDlgItem(IDC_EDIT7))->GetWindowText(str);
 if(IsHexString(str) == false || str.GetLength() != 2)
 {
  MessageBox("��ַ��������ȷ!");
  return;
 }
  StrToVal(&byAddr,str);
 
  byRate = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel();
  CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT1);
  pEdit->GetWindowText(str);
  strcpy(Buff,str.GetBuffer(str.GetLength()));
  dwTimeout = atoi(Buff);

  pEdit = (CEdit*)GetDlgItem(IDC_EDIT2);
  pEdit->GetWindowText(str);
  strcpy(Buff,str.GetBuffer(str.GetLength()));
  dwTimeout = dwTimeout + (atoi(Buff)<<16);
 
 if(USBIO_I2cSetConfig(byDevIndex,byAddr,byRate,dwTimeout))
 {
   I2C_dev->byRateIndex = byRate;
   I2C_dev->dwTimeout = dwTimeout;
   MessageBox("����ok");
 }
 UpdateController();
}

void CI2C_RWDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
  USBIO_ResetDevice(byDevIndex,DEV_I2C);
  USBIO_I2cGetConfig(byDevIndex,&I2C_dev->byDevAddr,&I2C_dev->byRateIndex,&I2C_dev->dwTimeout);
  UpdateController();	
}

void CI2C_RWDlg::OnButton6() 
{
// TODO: Add your control notification handler code here
 
 CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT3);
 pEdit->SetWindowText("");
 
 I2C_dev->ReadBufClear();
 char Buff[20];
 sprintf(Buff,"%08d",I2C_dev->GetReadCnt());
 ((CStatic*)GetDlgItem(IDC_STATIC_READ))->SetWindowText(Buff);


}

void CI2C_RWDlg::OnButton10() 
{
	// TODO: Add your control notification handler code here
 AboutDlg Dlg(this,byDevIndex);
 Dlg.DoModal();	
}



void CI2C_RWDlg::OnButton4() 
{
	// TODO: Add your control notification handler code here
 CString str;
 BYTE comLen;
 ((CEdit*)GetDlgItem(IDC_EDIT4))->GetWindowText(str);
 if(IsHexString(str) == false)
 {
  MessageBox("�����������ȷ!");
  return;
 }
 BYTE Temp[128];
 comLen = str.GetLength()/2;
 if(comLen)
   StrToVal(Temp,str);
 char Buff[100]={0};
 ((CEdit*)GetDlgItem(IDC_EDIT5))->GetWindowText(str);
 strcpy(Buff,str.GetBuffer(str.GetLength()));
 DWORD dwReadLen = atoi(Buff);
 if(dwReadLen > 65534)
 {
	 MessageBox("���볤�Ȳ��ܴ���65534!");
	 return;
 }
 BYTE* pTmpBuff = new BYTE[dwReadLen];
 if(USBIO_I2cRead(byDevIndex,I2C_dev->byDevAddr,Temp,comLen,pTmpBuff,dwReadLen)==0)
 {
	delete []pTmpBuff;
	MessageBox("��ʧ��!");
	return;
 }
 I2C_dev->PutReadBuf(pTmpBuff,dwReadLen);  
 sprintf(Buff,"%08d",I2C_dev->GetReadCnt());
 ((CStatic*)GetDlgItem(IDC_STATIC_READ))->SetWindowText(Buff);
 ApplendText(IDC_EDIT3,pTmpBuff,dwReadLen);
 delete []pTmpBuff;
}

void CI2C_RWDlg::OnButton5() 
{
	// TODO: Add your control notification handler code here
 CString str;
 BYTE comLen;
 ((CEdit*)GetDlgItem(IDC_EDIT9))->GetWindowText(str);
 if(IsHexString(str) == false)
 {
  MessageBox("�����������ȷ!");
  return;
 }	
 BYTE Temp[128];
 comLen = str.GetLength()/2;
 if(comLen)
   StrToVal(Temp,str);
  if(I2C_dev->GetWriteCnt() > 65534)
  {
	 MessageBox("д�볤�Ȳ��ܴ���65534!");
	 return;
  }

 if(USBIO_I2cWrite(byDevIndex,I2C_dev->byDevAddr,Temp,comLen,I2C_dev->GetWriteBuf(),I2C_dev->GetWriteCnt())==0)
 {
	MessageBox("дʧ��!");
	return;
 }

}

bool CI2C_RWDlg::IsHexString(CString str)
{
 int len = str.GetLength();
 if(len == 0)
	return true;
 if(len % 2 || len > 256)
	return false;
 
 for(int i = 0 ; i < len ; i ++)
 {
	 if(str[i] >= '0' &&  str[i] <= '9')
		 continue;
	 else if(str[i] >= 'a' &&  str[i] <= 'f')
		 continue;
	 else if(str[i] >= 'A' &&  str[i] <= 'F')
		 continue;
	 else
		 return false;
 }
 return true;
}

void CI2C_RWDlg::StrToVal(BYTE *pByte, CString &str)
{
	int i,j;
    int len = str.GetLength()/2;
	
	for(i=0,j=0;j<len;i++,j++)
	{
		pByte[j] = (BYTE)((CharToBcd(str[i])<<4) + CharToBcd(str[i+1]));
		i++;
	}
}

void CI2C_RWDlg::VarToStr(CString &str,BYTE *pByte, int len,BYTE start)
{
 CString tempStr;
 str.Empty();
 for(int i = 0 ,j = start; i < len ; i++)
 {
   str += " ";
   //str += CString(BcdToChar(pByte[i] >> 4));
   //str += CString(BcdToChar(pByte[i] & 0x0F));
   tempStr.Format(_T("%02X"),pByte[i]);
   str += tempStr;
   j += 3;
   if( j == 48)
   {
	   str += L"\r\n";
	   j = 0;
   }
 }
}


BYTE CI2C_RWDlg::BcdToChar(BYTE iBcd)
{
	BYTE hexVar[] = {"0123456789ABCDEF"};
    return hexVar[iBcd];
}

BYTE CI2C_RWDlg::CharToBcd(BYTE iChar)
{
	UCHAR	mBCD;
	if ( iChar >= '0' && iChar <= '9' ) mBCD = iChar -'0';
	else if ( iChar >= 'A' && iChar <= 'F' ) mBCD = iChar - 'A' + 0x0a;
	else if ( iChar >= 'a' && iChar <= 'f' ) mBCD = iChar - 'a' + 0x0a;
	else mBCD = 0x00;
	return( mBCD );
}


void CI2C_RWDlg::ApplendText(int id, BYTE *pByte, int len)
{
  CEdit* pEdit = (CEdit*)GetDlgItem(id);
  CString str;
  DWORD textLen = pEdit->GetWindowTextLength();
  BYTE start = textLen % 50;
  VarToStr(str,pByte,len,start);
  pEdit->SetFocus();
  pEdit->SetSel(textLen,textLen,true);
  pEdit->ReplaceSel(str);
}

void CI2C_RWDlg::OnButton7() 
{
	// TODO: Add your control notification handler code here
		// TODO: Add your control notification handler code here
   CString FileName;
   if(I2C_dev->GetReadCnt() == 0)
   {
	   MessageBox("��������Ϊ��!");
	   return;
   }
   CFileDialog* p = new CFileDialog(false,"*.bin",NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		   "Data Files(*.bin)|*.bin;|All Files(*.*)|*.*||",this);
   if(p->DoModal() == IDOK)
   {
	    FileName = p->GetPathName();
		if(p->GetFileExt().IsEmpty())
		{
			FileName = FileName + CString(".bin");
		}

	    CFile file(FileName,CFile::modeCreate|CFile::modeWrite);

		file.Write(I2C_dev->GetReadBuf() ,I2C_dev->GetReadCnt() );//д�ļ���־
		file.Close();
   }
   delete p;	
}

void CI2C_RWDlg::OnButton9() 
{
	// TODO: Add your control notification handler code here
   CString FileName;
   CFileDialog* p=new CFileDialog(true,"*.bin",NULL,OFN_HIDEREADONLY | OFN_FILEMUSTEXIST,
		   "Data Files(*.bin)|*.bin;|All Files(*.*)|*.*||",this);
   if(p->DoModal() == IDOK)
   {
	    FileName=p->GetPathName();
	/*	if(p->GetFileExt().IsEmpty())
		{
			FileName = FileName + CString(".bin");
		}*/
	    CFile file(FileName,CFile::modeRead);
        DWORD fileLen = file.GetLength();
		if(fileLen == 0)
		{
			delete p;
			MessageBox("�յ��ļ�!");
			return;
		}
		
		OnButton8();
		BYTE* pBuf = new BYTE[fileLen + 1];
		file.Read(pBuf,fileLen);//д�ļ���־
		I2C_dev->WriteBufUpdate(pBuf,fileLen);
		file.Close();
		delete pBuf;
		ApplendText(IDC_EDIT6,I2C_dev->GetWriteBuf(),I2C_dev->GetWriteCnt());
		char Buff[20];
		sprintf(Buff,"%08d",fileLen);
        ((CStatic*)GetDlgItem(IDC_STATIC_WRITE))->SetWindowText(Buff);	
   }
   delete p;		
}

void CI2C_RWDlg::OnButton8() 
{
	// TODO: Add your control notification handler code here
 dwWriteIndex = 0;
 CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT6);
 pEdit->SetWindowText("");
 
 I2C_dev->WriteBufClear();
 char Buff[20];
 sprintf(Buff,"%08d",0);
 ((CStatic*)GetDlgItem(IDC_STATIC_WRITE))->SetWindowText(Buff);	
}

void CI2C_RWDlg::USB_SendData(WORD dataLen)
{
 BYTE* pBuf = I2C_dev->GetWriteBuf();
 WORD leftLen;
 DWORD dwTotalLen = I2C_dev->GetWriteCnt();
 BYTE* pTmpBuff = new BYTE[SPI_RW_SIZE];
 memset(pTmpBuff,0xFF,SPI_RW_SIZE);
 dwWriteIndex = dwWriteIndex + dataLen;
 if(dwTotalLen > dwWriteIndex)
 {
   if(dwTotalLen > dwWriteIndex + SPI_RW_SIZE)
   {
	memcpy(pTmpBuff,&pBuf[dwWriteIndex],SPI_RW_SIZE);   
   }
   else
   {
	 memcpy(pTmpBuff,&pBuf[dwWriteIndex],dwTotalLen - dwWriteIndex);
   }   

 }

 if(USBIO_SPIWrite(byDevIndex,NULL,0,pTmpBuff,SPI_RW_SIZE)==0)
 {
	MessageBox("��������ʧ��!");
 }
 delete []pTmpBuff;
}

void CI2C_RWDlg::USB_ReciData(WORD dataLen)
{
 BYTE* pTmpBuff = new BYTE[dataLen];
 BYTE temp[128] = "\r\n";
 char Buff[10];
 CString str;
 if(USBIO_SPIRead(byDevIndex,NULL,0,pTmpBuff,dataLen)==0)
 {
	delete []pTmpBuff;
	MessageBox("��������ʧ��!");
	return;
 }
 I2C_dev->PutReadBuf(pTmpBuff,dataLen);  
 sprintf(Buff,"%08d",I2C_dev->GetReadCnt());
 ((CStatic*)GetDlgItem(IDC_STATIC_READ))->SetWindowText(Buff);
//pplendText(IDC_EDIT3,pTmpBuff,dataLen);
  CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT3);
  DWORD textLen = pEdit->GetWindowTextLength();
  VarToStr(str,pTmpBuff,dataLen,0);
  pEdit->SetFocus();
  pEdit->SetSel(textLen,textLen,true);
  pEdit->ReplaceSel("\r\n" + str);
  delete []pTmpBuff;
}




