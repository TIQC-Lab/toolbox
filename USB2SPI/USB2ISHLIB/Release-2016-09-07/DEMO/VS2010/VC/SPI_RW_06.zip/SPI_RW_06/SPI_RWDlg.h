// SPI_RWDlg.h : header file
//

#if !defined(AFX_SPI_RWDLG_H__3D2E516F_0584_4E0B_8C1D_0862F301B989__INCLUDED_)
#define AFX_SPI_RWDLG_H__3D2E516F_0584_4E0B_8C1D_0862F301B989__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "dev_info.h"
/////////////////////////////////////////////////////////////////////////////
// CSPI_RWDlg dialog

class CSPI_RWDlg : public CDialog
{
// Construction
public:
	void USB_ReciData(WORD dataLen);
	void USB_SendData(WORD dataLen);
	void ApplendText(int id,BYTE* pByte,int len);
	BYTE CharToBcd(BYTE iChar);
	BYTE BcdToChar(BYTE iBcd);
	void StrToVal(BYTE* pByte,CString& str);
	void VarToStr(CString &str,BYTE *pByte, int len,BYTE start);
	bool IsHexString(CString str);
	void UpdateController();
	void USB_IO_Trigged();
	void EnumPortsWdm(void);
	BYTE byDevIndex;
	DWORD dwWriteIndex;  //only use in the slave mode
	DevInfo* SPI_dev;
	DevInfo* TRIG_dev;
    DevInfo* GPIO_dev;
	CSPI_RWDlg(CWnd* pParent = NULL);	// standard constructor
    ~CSPI_RWDlg();
// Dialog Data
	//{{AFX_DATA(CSPI_RWDlg)
	enum { IDD = IDD_SPI_RW_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSPI_RWDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSPI_RWDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnQuit();
	afx_msg void OnConnect();
    afx_msg LRESULT USB_StatusChange(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT USB_Interupter(WPARAM wParam, LPARAM lParam);
	afx_msg void OnButton1();
	afx_msg void OnButton2();
	afx_msg void OnButton6();
	afx_msg void OnButton10();
	afx_msg void OnSelchangeCombo3();
	afx_msg void OnCheck2();
	afx_msg void OnButton3();
	afx_msg void OnButton4();
	afx_msg void OnButton5();
	afx_msg void OnButton7();
	afx_msg void OnButton9();
	afx_msg void OnButton8();
	afx_msg void OnConnect2();
	afx_msg void OnConnect3();
	afx_msg void OnConnect4();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPI_RWDLG_H__3D2E516F_0584_4E0B_8C1D_0862F301B989__INCLUDED_)
