// SPI_RW.h : main header file for the SPI_RW application
//

#if !defined(AFX_SPI_RW_H__1D1977EA_3A6D_48F1_A9F9_FCCFE3F12F21__INCLUDED_)
#define AFX_SPI_RW_H__1D1977EA_3A6D_48F1_A9F9_FCCFE3F12F21__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "SPI_RW.h"
#define WM_USB_STATUS   (WM_USER + 1)
#define WM_USB_TRIG     (WM_USER + 2)
/////////////////////////////////////////////////////////////////////////////
// CSPI_RWApp:
// See SPI_RW.cpp for the implementation of this class
//

class CSPI_RWApp : public CWinApp
{
public:
	CSPI_RWApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSPI_RWApp)
	public:
	virtual BOOL InitInstance();
		virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSPI_RWApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL m_bATLInited;
private:
	BOOL InitATL();
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPI_RW_H__1D1977EA_3A6D_48F1_A9F9_FCCFE3F12F21__INCLUDED_)
