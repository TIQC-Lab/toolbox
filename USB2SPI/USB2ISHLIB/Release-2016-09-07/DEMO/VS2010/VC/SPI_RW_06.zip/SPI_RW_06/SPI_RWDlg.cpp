// SPI_RWDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SPI_RW.h"
#include "SPI_RWDlg.h"
#include "AboutDlg.h"
#include <objbase.h>
#include <initguid.h>
#include <Setupapi.h>
#pragma comment(lib, "setupapi.lib")


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "usbio.h"


HWND mainhwnd;

bool USBIO_Status_Nofiy (BYTE iDevIndex,	DWORD iStatus); 
bool USBIO_Trig_Nofiy (BYTE iDevIndex,     DWORD	iStatus); 

bool USBIO_Status_Nofiy (BYTE iDevIndex,DWORD	iStatus)
{
 PostMessage(mainhwnd,WM_USB_STATUS,iDevIndex,iStatus);
 return true;
}

//---------------------------------------------------------------------------
bool USBIO_Trig_Nofiy (BYTE iDevIndex, DWORD	iStatus)
{
 PostMessage(mainhwnd,WM_USB_TRIG,iDevIndex,iStatus);
 return true;
}

/////////////////////////////////////////////////////////////////////////////
// CSPI_RWDlg dialog

CSPI_RWDlg::CSPI_RWDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSPI_RWDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSPI_RWDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CSPI_RWDlg::~CSPI_RWDlg()
{
  if(byDevIndex != 0xFF)
  {
   if(SPI_dev->bRunning)
    USBIO_ExitTrig(byDevIndex);   
   USBIO_CloseDevice(byDevIndex);
  }
  delete SPI_dev;
  delete TRIG_dev;

}

void CSPI_RWDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSPI_RWDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSPI_RWDlg, CDialog)
	//{{AFX_MSG_MAP(CSPI_RWDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(ID_QUIT, OnQuit)
	ON_BN_CLICKED(ID_CONNECT, OnConnect)
	ON_MESSAGE(WM_USB_STATUS, USB_StatusChange)
	ON_MESSAGE(WM_USB_TRIG, USB_Interupter)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON6, OnButton6)
	ON_BN_CLICKED(IDC_BUTTON10, OnButton10)
	ON_CBN_SELCHANGE(IDC_COMBO3, OnSelchangeCombo3)
	ON_BN_CLICKED(IDC_CHECK2, OnCheck2)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	ON_BN_CLICKED(IDC_BUTTON7, OnButton7)
	ON_BN_CLICKED(IDC_BUTTON9, OnButton9)
	ON_BN_CLICKED(IDC_BUTTON8, OnButton8)
	ON_BN_CLICKED(ID_CONNECT2, OnConnect2)
	ON_BN_CLICKED(ID_CONNECT3, OnConnect3)
	ON_BN_CLICKED(ID_CONNECT4, OnConnect4)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSPI_RWDlg message handlers

BOOL CSPI_RWDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	mainhwnd=GetSafeHwnd(); 
	dwWriteIndex = 0;
	byDevIndex = 0xFF;
	SPI_dev = new DevInfo(DEV_SPI);
    SPI_dev->byRateIndex = 0x04;
    SPI_dev->dwTimeout = 0x00C800C8;
    TRIG_dev = new DevInfo(DEV_TRIG);
    TRIG_dev->byRateIndex = 0;
	GPIO_dev = new DevInfo(DEV_GPIO);
	GPIO_dev->byDevAddr = 0xFF;   //Ĭ��GPIO����Ϊ����
	GPIO_dev->byRateIndex = 0;    //Ĭ��GPIOֵ��Ϊ�͵�ƽ��ֻҪû�������ϣ��Ͳ�����Ӱ��
    USBIO_SetUSBNotify(false,USBIO_Status_Nofiy);
    UpdateController();
	EnumPortsWdm();
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSPI_RWDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSPI_RWDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSPI_RWDlg::UpdateController()
{
 char temp[20];
 ((CComboBox*)GetDlgItem(IDC_COMBO1))->SetCurSel(SPI_dev->byRateIndex & 0x0F);
 ((CComboBox*)GetDlgItem(IDC_COMBO2))->SetCurSel((SPI_dev->byRateIndex & 0x7F) >> 4);
 ((CButton*)GetDlgItem(IDC_CHECK3))->SetCheck(SPI_dev->byRateIndex >> 7);

 sprintf(temp,"%d",SPI_dev->dwTimeout & 0xFFFF);
 ((CEdit*)GetDlgItem(IDC_EDIT1))->SetWindowText(temp);
 sprintf(temp,"%d",SPI_dev->dwTimeout >> 16);
 ((CEdit*)GetDlgItem(IDC_EDIT2))->SetWindowText(temp);

  ((CComboBox*)GetDlgItem(IDC_COMBO3))->SetCurSel(TRIG_dev->byRateIndex);

  sprintf(temp,"%02X",GPIO_dev->byDevAddr);
  ((CEdit*)GetDlgItem(IDC_EDIT7))->SetWindowText(temp);
  sprintf(temp,"%02X",GPIO_dev->byRateIndex);
  ((CEdit*)GetDlgItem(IDC_EDIT8))->SetWindowText(temp);

 ((CComboBox*)GetDlgItem(IDC_COMBO1))->EnableWindow(byDevIndex != 0xFF);
 ((CComboBox*)GetDlgItem(IDC_COMBO2))->EnableWindow(byDevIndex != 0xFF);


 ((CEdit*)GetDlgItem(IDC_EDIT1))->EnableWindow(byDevIndex != 0xFF);
 ((CEdit*)GetDlgItem(IDC_EDIT2))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_BUTTON10))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_BUTTON4))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_BUTTON5))->EnableWindow(byDevIndex != 0xFF);

 ((CButton*)GetDlgItem(IDC_BUTTON1))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_BUTTON2))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_BUTTON3))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_CHECK1))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_CHECK2))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(IDC_CHECK3))->EnableWindow(byDevIndex != 0xFF);
 ((CComboBox*)GetDlgItem(IDC_COMBO3))->EnableWindow(byDevIndex != 0xFF);

 ((CEdit*)GetDlgItem(IDC_EDIT7))->EnableWindow(byDevIndex != 0xFF);
 ((CEdit*)GetDlgItem(IDC_EDIT8))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(ID_CONNECT2))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(ID_CONNECT3))->EnableWindow(byDevIndex != 0xFF);
 ((CButton*)GetDlgItem(ID_CONNECT4))->EnableWindow(byDevIndex != 0xFF);

 if(byDevIndex != 0xFF)  //SPI is slaver at connected 
 {
 ((CButton*)GetDlgItem(IDC_BUTTON4))->EnableWindow((SPI_dev->byRateIndex & 0x80) == 0);
 ((CButton*)GetDlgItem(IDC_BUTTON5))->EnableWindow((SPI_dev->byRateIndex & 0x80) == 0);
 ((CEdit*)GetDlgItem(IDC_EDIT4))->EnableWindow((SPI_dev->byRateIndex & 0x80) == 0);
 ((CEdit*)GetDlgItem(IDC_EDIT5))->EnableWindow((SPI_dev->byRateIndex & 0x80) == 0);
 ((CEdit*)GetDlgItem(IDC_EDIT9))->EnableWindow((SPI_dev->byRateIndex & 0x80) == 0);
 }

}

void CSPI_RWDlg::OnQuit() 
{
 OnOK();	
}

void CSPI_RWDlg::OnConnect() 
{
  char serial[15] = {0};
  if(byDevIndex != 0xFF)
	{
	  if(SPI_dev->bRunning)
	  {
       if(USBIO_ExitTrig(byDevIndex))
	   {
	     TRIG_dev->bRunning = false;
	     SPI_dev->bRunning = false;
         ((CButton*)GetDlgItem(IDC_BUTTON3))->SetWindowText("��ʼ����");
	   }
	   else
	   {
			MessageBox("�˳�����ʧ��!");
			return;
	   }
	  }
	   if(USBIO_CloseDevice(byDevIndex) == false)
        {
			MessageBox("�ر��豸ʧ��!");
			return;
		}
	    byDevIndex = 0xFF;        
        GetDlgItem(ID_CONNECT)->SetWindowText("����");
		SetWindowText("SPI��д��ʾ����<---->�豸δ����");
	}
	else
	{
     byDevIndex = USBIO_OpenDevice();
	 if(byDevIndex == 0xFF)
	 {
  		MessageBox("���豸ʧ��!");
		return ;
	 }
	else
	{
      GetDlgItem(ID_CONNECT)->SetWindowText("�Ͽ�");
	  USBIO_GetSerialNo(byDevIndex,serial);
	  SetWindowText(serial);

	   USBIO_SetTrigNotify(byDevIndex,USBIO_Trig_Nofiy);   //ע�����֪ͨ  


//	  USBIO_I2cGetConfig(byIndex,&I2C_dev->byDevAddr,&I2C_dev->byRateIndex,&I2C_dev->dwTimeout);
      USBIO_SPIGetConfig(byDevIndex,&SPI_dev->byRateIndex,&SPI_dev->dwTimeout);
	  USBIO_GetGPIOConfig(byDevIndex,&SPI_dev->byDevAddr);
      USBIO_GPIORead(byDevIndex,&(GPIO_dev->byRateIndex));
	  USBIO_TrigGetConfig(byDevIndex,&TRIG_dev->byRateIndex);

 	}
	}	
	UpdateController();
}

LRESULT CSPI_RWDlg::USB_StatusChange(WPARAM wParam, LPARAM lParam)
{
  if(lParam&0x80)                    //usb dev plugged
  {
/*	if(byDevIndex != 0xFF)
    {
		return 0;
	}
	OnConnect();*/
  }
  else
  {
	 if(byDevIndex == wParam)
	   {
        TRIG_dev->bRunning = false;
	    SPI_dev->bRunning = false;
        ((CButton*)GetDlgItem(IDC_BUTTON3))->SetWindowText("��ʼ����");
	  	SetWindowText("SPI��д��ʾ����<---->�豸δ����");	   
		USBIO_CloseDevice(byDevIndex);
		byDevIndex = 0xFF;
		GetDlgItem(ID_CONNECT)->SetWindowText("����");
		UpdateController();
	   }
  }
  return 0;
}

LRESULT CSPI_RWDlg::USB_Interupter(WPARAM wParam, LPARAM lParam)
{
 BYTE Flag = lParam & 0xFF;
 if(wParam != byDevIndex)
   return 0;
 WORD Length = ((lParam & 0xFF00) >> 8);
 switch (Flag)
 {
	case EXT_IO_TRIG:
		USB_IO_Trigged();
	break;
	case SPI_READ_TRIG:
		USB_SendData(Length);
	break;
	case SPI_WRITE_TRIG:
		USB_ReciData(Length);
	break;
	case SPI_INIT_WRITE_TRIG:
	break;
	case SPI_INIT_READ_TRIG:
		dwWriteIndex = 0;
        USB_SendData(0);
	break;
	default:
	break;
 }
 return 0;
}

void CSPI_RWDlg::USB_IO_Trigged()
{

 if(SPI_dev->bRunning)
 {
  if(((CButton*)GetDlgItem(IDC_CHECK1))->GetCheck() == 1)
	OnButton4();
  else
    OnButton5();
  if(USBIO_WaitForTrig(byDevIndex)==false)
  {
   MessageBox("��������ʧ��!");
   TRIG_dev->bRunning = false;
   SPI_dev->bRunning = false;
   ((CButton*)GetDlgItem(IDC_BUTTON3))->SetWindowText("��ʼ����");
   ((CButton*)GetDlgItem(IDC_BUTTON1))->EnableWindow(true);
   ((CButton*)GetDlgItem(IDC_BUTTON2))->EnableWindow(true);
   ((CButton*)GetDlgItem(IDC_BUTTON4))->EnableWindow(true);
   ((CButton*)GetDlgItem(IDC_BUTTON5))->EnableWindow(true);
//   ((CButton*)GetDlgItem(IDC_CHECK2))->EnableWindow(true);
   ((CComboBox*)GetDlgItem(IDC_COMBO3))->EnableWindow(true);
  }
 }

// return 0;
}

void CSPI_RWDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
  DWORD dwTimeout;
  CString str;
  BYTE byRate;
  char Buff[100];

  byRate = ((CComboBox*)GetDlgItem(IDC_COMBO1))->GetCurSel() + (((CComboBox*)GetDlgItem(IDC_COMBO2))->GetCurSel() << 4);
  CButton *pBox = (CButton*)GetDlgItem(IDC_CHECK3);
  if(pBox->GetCheck() == 1)
	byRate = byRate + 0x80;
  CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT1);
  pEdit->GetWindowText(str);
  strcpy(Buff,str.GetBuffer(str.GetLength()));
  dwTimeout = atoi(Buff);

  pEdit = (CEdit*)GetDlgItem(IDC_EDIT2);
  pEdit->GetWindowText(str);
  strcpy(Buff,str.GetBuffer(str.GetLength()));
  dwTimeout = dwTimeout + (atoi(Buff)<<16);
 
 if(USBIO_SPISetConfig(byDevIndex,byRate,dwTimeout))
 {
   SPI_dev->byRateIndex = byRate;
   SPI_dev->dwTimeout = dwTimeout;
   MessageBox("����ok");
 }
 UpdateController();
}

void CSPI_RWDlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
  USBIO_ResetDevice(byDevIndex,DEV_SPI);
  if(USBIO_SPIGetConfig(byDevIndex,&SPI_dev->byRateIndex,&SPI_dev->dwTimeout))
	UpdateController();
	
}

void CSPI_RWDlg::OnButton6() 
{
// TODO: Add your control notification handler code here
 
 CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT3);
 pEdit->SetWindowText("");
 
 SPI_dev->ReadBufClear();
 char Buff[20];
 sprintf(Buff,"%08d",SPI_dev->GetReadCnt());
 ((CStatic*)GetDlgItem(IDC_STATIC_READ))->SetWindowText(Buff);


}

void CSPI_RWDlg::OnButton10() 
{
	// TODO: Add your control notification handler code here
 AboutDlg Dlg(this,byDevIndex);
 Dlg.DoModal();
	
}

void CSPI_RWDlg::OnSelchangeCombo3() 
{

 CComboBox *pbox = (CComboBox*)GetDlgItem(IDC_COMBO3);
 if(USBIO_TrigSetConfig(byDevIndex,pbox->GetCurSel()))
 {
  TRIG_dev->byRateIndex = pbox->GetCurSel();

 }
 else
 {
  MessageBox("���ô���ģʽʧ��!");
 }

}

void CSPI_RWDlg::OnCheck2() 
{
	// TODO: Add your control notification handler code here
  CButton *pbox = (CButton*)GetDlgItem(IDC_CHECK2);

	USBIO_SetCE(byDevIndex,pbox->GetCheck() == 1);

}

void CSPI_RWDlg::OnButton3() 
{
	// TODO: Add your control notification handler code here

 if(SPI_dev->bRunning)
 {
  if(USBIO_ExitTrig(byDevIndex))
  {
	 TRIG_dev->bRunning = false;
	 SPI_dev->bRunning = false;
	 ((CButton*)GetDlgItem(IDC_BUTTON3))->SetWindowText("��ʼ����");
     ((CButton*)GetDlgItem(IDC_BUTTON1))->EnableWindow(true);
     ((CButton*)GetDlgItem(IDC_BUTTON2))->EnableWindow(true);
     ((CButton*)GetDlgItem(IDC_BUTTON4))->EnableWindow(true);
     ((CButton*)GetDlgItem(IDC_BUTTON5))->EnableWindow(true);
//     ((CButton*)GetDlgItem(IDC_CHECK2))->EnableWindow(true);
     ((CComboBox*)GetDlgItem(IDC_COMBO3))->EnableWindow(true);
  }

  else
	 {
	   MessageBox("�˳�����ʧ��!");
	   return;
	 }
 } 
 else
 {
  if(!USBIO_WaitForTrig(byDevIndex))
   {
	 MessageBox("��������ʧ��!");
	 return;
	}
  TRIG_dev->bRunning = true;
  SPI_dev->bRunning = true;
  ((CButton*)GetDlgItem(IDC_BUTTON1))->EnableWindow(false);
  ((CButton*)GetDlgItem(IDC_BUTTON2))->EnableWindow(false);
  ((CButton*)GetDlgItem(IDC_BUTTON4))->EnableWindow(false);
  ((CButton*)GetDlgItem(IDC_BUTTON5))->EnableWindow(false);
//  ((CButton*)GetDlgItem(IDC_CHECK2))->EnableWindow(false);
  ((CComboBox*)GetDlgItem(IDC_COMBO3))->EnableWindow(false);

  ((CButton*)GetDlgItem(IDC_BUTTON3))->SetWindowText("ֹͣ����");
 }	
	
}

void CSPI_RWDlg::OnButton4() 
{
	// TODO: Add your control notification handler code here
 CString str;
 BYTE* pTmpBuff;
 BYTE comLen;
 ((CEdit*)GetDlgItem(IDC_EDIT4))->GetWindowText(str);
 if(IsHexString(str) == false)
 {
  MessageBox("�����������ȷ!");
  return;
 }
 BYTE Temp[128];
 comLen = str.GetLength()/2;
 if(comLen)
   StrToVal(Temp,str);
 char Buff[100]={0};
 ((CEdit*)GetDlgItem(IDC_EDIT5))->GetWindowText(str);
 strcpy(Buff,str.GetBuffer(str.GetLength()));
 DWORD dwReadLen = atoi(Buff);
 if(dwReadLen > 65534)
 {
	 MessageBox("���볤�Ȳ��ܴ���65534!");
	 return;
 }
 CButton *pBox = (CButton*)GetDlgItem(IDC_CHECK4);
 if(pBox->GetCheck() == 1)
 {
  pTmpBuff = new BYTE[comLen];
  if(USBIO_SPITest(byDevIndex,Temp,pTmpBuff,comLen)==0)
  {
	delete []pTmpBuff;
	MessageBox("Testʧ��!");
  }    	
  SPI_dev->PutReadBuf(pTmpBuff,comLen);  
  sprintf(Buff,"%08d",SPI_dev->GetReadCnt());
  ((CStatic*)GetDlgItem(IDC_STATIC_READ))->SetWindowText(Buff);
  ApplendText(IDC_EDIT3,pTmpBuff,comLen);
  delete []pTmpBuff;
  return;
 }
 pTmpBuff = new BYTE[dwReadLen];
 if(USBIO_SPIRead(byDevIndex,Temp,comLen,pTmpBuff,dwReadLen)==0)
 {
	delete []pTmpBuff;
	MessageBox("��ʧ��!");
	return;
 }
 SPI_dev->PutReadBuf(pTmpBuff,dwReadLen);  
 sprintf(Buff,"%08d",SPI_dev->GetReadCnt());
 ((CStatic*)GetDlgItem(IDC_STATIC_READ))->SetWindowText(Buff);
 ApplendText(IDC_EDIT3,pTmpBuff,dwReadLen);
 delete []pTmpBuff;
}

void CSPI_RWDlg::OnButton5() 
{
	// TODO: Add your control notification handler code here
 CString str;
 BYTE comLen;
 ((CEdit*)GetDlgItem(IDC_EDIT9))->GetWindowText(str);
 if(IsHexString(str) == false)
 {
  MessageBox("�����������ȷ!");
  return;
 }	
 BYTE Temp[128];
 comLen = str.GetLength()/2;
 if(comLen)
   StrToVal(Temp,str);
  if(SPI_dev->GetWriteCnt() > 65534)
  {
	 MessageBox("д�볤�Ȳ��ܴ���65534!");
	 return;
  }

 if(USBIO_SPIWrite(byDevIndex,Temp,comLen,SPI_dev->GetWriteBuf(),SPI_dev->GetWriteCnt())==0)
 {
	MessageBox("дʧ��!");
	return;
 }

}

bool CSPI_RWDlg::IsHexString(CString str)
{
 int len = str.GetLength();
 if(len == 0)
	return true;
 if(len % 2 || len > 256)
	return false;
 
 for(int i = 0 ; i < len ; i ++)
 {
	 if(str[i] >= '0' &&  str[i] <= '9')
		 continue;
	 else if(str[i] >= 'a' &&  str[i] <= 'f')
		 continue;
	 else if(str[i] >= 'A' &&  str[i] <= 'F')
		 continue;
	 else
		 return false;
 }
 return true;
}

void CSPI_RWDlg::StrToVal(BYTE *pByte, CString &str)
{
	int i,j;
    int len = str.GetLength()/2;
	
	for(i=0,j=0;j<len;i++,j++)
	{
		pByte[j] = (BYTE)((CharToBcd(str[i])<<4) + CharToBcd(str[i+1]));
		i++;
	}
}

void CSPI_RWDlg::VarToStr(CString &str,BYTE *pByte, int len,BYTE start)
{
 str.Empty();
 CString tempStr;
 for(int i = 0 ,j = start; i < len ; i++)
 {
   str += " ";
   //str += CString(BcdToChar(pByte[i] >> 4));
   //str += CString(BcdToChar(pByte[i] & 0x0F));
   tempStr.Format(_T("%02X"),pByte[i]);
   str = str + tempStr; 
   j += 3;
   if( j == 48)
   {
	   str += L"\r\n";
	   j = 0;
   }
 }
}


BYTE CSPI_RWDlg::BcdToChar(BYTE iBcd)
{
	BYTE hexVar[] = {"0123456789ABCDEF"};
    return hexVar[iBcd];
}

BYTE CSPI_RWDlg::CharToBcd(BYTE iChar)
{
	UCHAR	mBCD;
	if ( iChar >= '0' && iChar <= '9' ) mBCD = iChar -'0';
	else if ( iChar >= 'A' && iChar <= 'F' ) mBCD = iChar - 'A' + 0x0a;
	else if ( iChar >= 'a' && iChar <= 'f' ) mBCD = iChar - 'a' + 0x0a;
	else mBCD = 0x00;
	return( mBCD );
}


void CSPI_RWDlg::ApplendText(int id, BYTE *pByte, int len)
{
  CEdit* pEdit = (CEdit*)GetDlgItem(id);
  CString str;
  DWORD textLen = pEdit->GetWindowTextLength();
  BYTE start = textLen % 50;
  VarToStr(str,pByte,len,start);
  pEdit->SetFocus();
  pEdit->SetSel(textLen,textLen,true);
  pEdit->ReplaceSel(str);
}

void CSPI_RWDlg::OnButton7() 
{
	// TODO: Add your control notification handler code here
		// TODO: Add your control notification handler code here
   CString FileName;
   if(SPI_dev->GetReadCnt() == 0)
   {
	   MessageBox("��������Ϊ��!");
	   return;
   }
   CFileDialog* p = new CFileDialog(false,"*.bin",NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		   "Data Files(*.bin)|*.bin;|All Files(*.*)|*.*||",this);
   if(p->DoModal() == IDOK)
   {
	    FileName = p->GetPathName();
		if(p->GetFileExt().IsEmpty())
		{
			FileName = FileName + CString(".bin");
		}

	    CFile file(FileName,CFile::modeCreate|CFile::modeWrite);

		file.Write(SPI_dev->GetReadBuf() ,SPI_dev->GetReadCnt() );//д�ļ���־
		file.Close();
   }
   delete p;	
}

void CSPI_RWDlg::OnButton9() 
{
	// TODO: Add your control notification handler code here
   CString FileName;
   CFileDialog* p=new CFileDialog(true,"*.bin",NULL,OFN_HIDEREADONLY | OFN_FILEMUSTEXIST,
		   "Data Files(*.bin)|*.bin;|All Files(*.*)|*.*||",this);
   if(p->DoModal() == IDOK)
   {
	    FileName=p->GetPathName();
		if(p->GetFileExt().IsEmpty())
		{
			FileName = FileName + CString(".bin");
		}
	    CFile file(FileName,CFile::modeRead);
        DWORD fileLen = file.GetLength();
		if(fileLen == 0)
		{
			delete p;
			MessageBox("�յ��ļ�!");
			return;
		}
		
		OnButton8();
		BYTE* pBuf = new BYTE[fileLen + 1];
		file.Read(pBuf,fileLen);//д�ļ���־
		SPI_dev->WriteBufUpdate(pBuf,fileLen);
		file.Close();
		delete pBuf;
		ApplendText(IDC_EDIT6,SPI_dev->GetWriteBuf(),SPI_dev->GetWriteCnt());
		char Buff[20];
		sprintf(Buff,"%08d",fileLen);
        ((CStatic*)GetDlgItem(IDC_STATIC_WRITE))->SetWindowText(Buff);	
   }
   delete p;		
}

void CSPI_RWDlg::OnButton8() 
{
	// TODO: Add your control notification handler code here
 dwWriteIndex = 0;
 CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT6);
 pEdit->SetWindowText("");
 
 SPI_dev->WriteBufClear();
 char Buff[20];
 sprintf(Buff,"%08d",0);
 ((CStatic*)GetDlgItem(IDC_STATIC_WRITE))->SetWindowText(Buff);	
}

void CSPI_RWDlg::USB_SendData(WORD dataLen)
{
 BYTE* pBuf = SPI_dev->GetWriteBuf();
 WORD leftLen;
 DWORD dwTotalLen = SPI_dev->GetWriteCnt();
 BYTE* pTmpBuff = new BYTE[SPI_RW_SIZE];
 memset(pTmpBuff,0xFF,SPI_RW_SIZE);
 dwWriteIndex = dwWriteIndex + dataLen;
 if(dwTotalLen > dwWriteIndex)
 {
   if(dwTotalLen > dwWriteIndex + SPI_RW_SIZE)
   {
	memcpy(pTmpBuff,&pBuf[dwWriteIndex],SPI_RW_SIZE);   
   }
   else
   {
	 memcpy(pTmpBuff,&pBuf[dwWriteIndex],dwTotalLen - dwWriteIndex);
   }   

 }

 if(USBIO_SPIWrite(byDevIndex,NULL,0,pTmpBuff,SPI_RW_SIZE)==0)
 {
	MessageBox("��������ʧ��!");
 }
 delete []pTmpBuff;
}

void CSPI_RWDlg::USB_ReciData(WORD dataLen)
{
 BYTE* pTmpBuff = new BYTE[dataLen];
 BYTE temp[128] = "\r\n";
 char Buff[10];
 CString str;
 if(USBIO_SPIRead(byDevIndex,NULL,0,pTmpBuff,dataLen)==0)
 {
	delete []pTmpBuff;
	MessageBox("��������ʧ��!");
	return;
 }
 SPI_dev->PutReadBuf(pTmpBuff,dataLen);  
 sprintf(Buff,"%08d",SPI_dev->GetReadCnt());
 ((CStatic*)GetDlgItem(IDC_STATIC_READ))->SetWindowText(Buff);
//pplendText(IDC_EDIT3,pTmpBuff,dataLen);
  CEdit* pEdit = (CEdit*)GetDlgItem(IDC_EDIT3);
  DWORD textLen = pEdit->GetWindowTextLength();
  VarToStr(str,pTmpBuff,dataLen,0);
  pEdit->SetFocus();
  pEdit->SetSel(textLen,textLen,true);
  pEdit->ReplaceSel("\r\n" + str);
  delete []pTmpBuff;
}

//#ifndef GUID_CLASS_COMPORT
//DEFINE_GUID(GUID_CLASS_COMPORT, 0x86e0d1e0L, 0x8089, 0x11d0, 0x9c, 0xe4, 0x08, 0x00, 0x3e, 0x30, 0x1f, 0x73);
  DEFINE_GUID(GUID_DEVINTERFACE_SERENUM_BUS_ENUMERATOR, 0x4D36E978L, 0xE325, 0x11CE, 0xBF, 0xC1, 0x08, 0x00, 0x2B, 0xE1, 0x03, 0x18);
  DEFINE_GUID(GUID_DEVINTERFACE_USB2INTERFACE,0xA5DCBF10, 0x6530, 0x11D2, 0x90, 0x1F, 0x00, 0xC0, 0x4F, 0xB9, 0x51, 0xED);
  //4D36E978-E325-11CE-BFC1-08002BE10318
//#endif
void CSPI_RWDlg::EnumPortsWdm(void)
{
 DWORD      bufferSize;
 HDEVINFO   hDeviceInfo;
 SP_DEVICE_INTERFACE_DATA            interfaceData;
 PSP_DEVICE_INTERFACE_DETAIL_DATA    deviceDetail;
 GUID guid = GUID_DEVINTERFACE_USB2INTERFACE;// GUID_DEVINTERFACE_SERENUM_BUS_ENUMERATOR;
 hDeviceInfo = SetupDiGetClassDevs(
                    //(LPGUID)&GUID_DEVINTERFACE_USB2INTERFACE,
                    &guid,
                    NULL,
                    NULL,
                    DIGCF_PRESENT | DIGCF_DEVICEINTERFACE
                    );
 
  if (hDeviceInfo == INVALID_HANDLE_VALUE)
    {
      MessageBox( "can't find usb device!!!");
      return ;
    }
    // Setup the interface data struct
    interfaceData.cbSize = sizeof(interfaceData);
    int ii,jj;
	jj = 0;
    for (ii = 0;SetupDiEnumDeviceInterfaces(
            hDeviceInfo,
            NULL,
           // (LPGUID)&GUID_DEVINTERFACE_USB2INTERFACE,
            &guid,
            ii,
            &interfaceData);
         ++ii)
    {
        // Found our device instance
      //  LogPrintf( "%s\n","Found our device instance");
        if (!SetupDiGetDeviceInterfaceDetail(
                hDeviceInfo,
                &interfaceData,
                NULL,
                0,
                &bufferSize,
                NULL))
        {
            if (GetLastError() != ERROR_INSUFFICIENT_BUFFER)
            {
                MessageBox("Error: couldn't get interface detail");

                continue;
            }
        }

        // Allocate a big enough buffer to get detail data
        deviceDetail = (PSP_DEVICE_INTERFACE_DETAIL_DATA)malloc(bufferSize);
        if (deviceDetail == NULL)
        {
            MessageBox("Error: Buffer allocation failed");
            continue;
        }

        // Setup the device interface struct
        deviceDetail->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);

        // Try again to get the device interface detail info
        if (!SetupDiGetDeviceInterfaceDetail(
                hDeviceInfo,
                &interfaceData,
                deviceDetail,
                bufferSize,
                NULL,
                NULL))
        {
            MessageBox("Error: SetupDiGetDeviceInterfaceDetail failed ");
            free(deviceDetail);
            continue;
        }
    
        free(deviceDetail);
    }
    SetupDiDestroyDeviceInfoList(hDeviceInfo);

}

void CSPI_RWDlg::OnConnect2() 
{
	// TODO: Add your control notification handler code here
	// TODO: Add your control notification handler code here
  CString str;
  BYTE byAddr;
  BYTE byValue;
  char Buff[100];
 ((CEdit*)GetDlgItem(IDC_EDIT7))->GetWindowText(str);
 if(IsHexString(str) == false || str.GetLength() != 2)
 {
  MessageBox("������hex��ʽ�ҳ���Ϊ2!");
  return;
 }
  StrToVal(&byAddr,str); 

 if(USBIO_SetGPIOConfig(byDevIndex,byAddr))
 {   
   GPIO_dev->byDevAddr = byAddr;
   USBIO_GPIORead(byDevIndex,&(GPIO_dev->byRateIndex));
   MessageBox("����ok");
 }
 UpdateController();	
}

void CSPI_RWDlg::OnConnect3() 
{
	// TODO: Add your control notification handler code here
 BYTE byAddr;
 if(USBIO_GPIORead(byDevIndex,&byAddr))
 {
	 GPIO_dev->byRateIndex = byAddr;
	 UpdateController();	
 }
 
}

void CSPI_RWDlg::OnConnect4() 
{
	// TODO: Add your control notification handler code here
  CString str;
  BYTE byValue;
  char Buff[100];
 ((CEdit*)GetDlgItem(IDC_EDIT8))->GetWindowText(str);
 if(IsHexString(str) == false || str.GetLength() != 2)
 {
  MessageBox("������hex��ʽ�ҳ���Ϊ2!");
  return;
 }
  StrToVal(&byValue,str); 	
  if(USBIO_GPIOWrite(byDevIndex,byValue,GPIO_dev->byDevAddr))
  {
   USBIO_GPIORead(byDevIndex,&GPIO_dev->byRateIndex);
   UpdateController();
  }
}
