/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGroupBox *groupBox_1;
    QLabel *label;
    QComboBox *comboBox_1;
    QLabel *label_2;
    QLabel *label_3;
    QTextEdit *textEdit_1;
    QLabel *label_4;
    QTextEdit *textEdit_2;
    QLabel *label_5;
    QLabel *label_6;
    QPushButton *pushButton_5;
    QPushButton *pushButton_9;
    QTextEdit *textEdit_3;
    QPushButton *pushButton_6;
    QGroupBox *groupBox_5;
    QLabel *label_11;
    QTextEdit *textEdit_6;
    QLabel *label_12;
    QTextEdit *textEdit_7;
    QLabel *label_13;
    QLabel *label_14;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QPushButton *pushButton_13;
    QTextEdit *textEdit_10;
    QGroupBox *groupBox_6;
    QLabel *label_15;
    QTextEdit *textEdit_8;
    QLabel *label_17;
    QLabel *label_18;
    QPushButton *pushButton_14;
    QPushButton *pushButton_15;
    QPushButton *pushButton_16;
    QTextEdit *textEdit_11;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QPushButton *pushButton_4;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(816, 596);
        MainWindow->setMouseTracking(false);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        groupBox_1 = new QGroupBox(centralWidget);
        groupBox_1->setObjectName(QStringLiteral("groupBox_1"));
        groupBox_1->setGeometry(QRect(20, 10, 281, 111));
        groupBox_1->setFlat(false);
        groupBox_1->setCheckable(false);
        label = new QLabel(groupBox_1);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 53, 31, 16));
        comboBox_1 = new QComboBox(groupBox_1);
        comboBox_1->setObjectName(QStringLiteral("comboBox_1"));
        comboBox_1->setGeometry(QRect(57, 53, 51, 23));
        label_2 = new QLabel(groupBox_1);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(10, 26, 41, 16));
        label_3 = new QLabel(groupBox_1);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(136, 30, 81, 16));
        textEdit_1 = new QTextEdit(groupBox_1);
        textEdit_1->setObjectName(QStringLiteral("textEdit_1"));
        textEdit_1->setGeometry(QRect(217, 27, 41, 21));
        textEdit_1->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_1->setAcceptRichText(false);
        label_4 = new QLabel(groupBox_1);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(136, 53, 81, 16));
        textEdit_2 = new QTextEdit(groupBox_1);
        textEdit_2->setObjectName(QStringLiteral("textEdit_2"));
        textEdit_2->setGeometry(QRect(217, 51, 41, 21));
        textEdit_2->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        label_5 = new QLabel(groupBox_1);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(260, 32, 21, 16));
        label_6 = new QLabel(groupBox_1);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(260, 52, 21, 16));
        pushButton_5 = new QPushButton(groupBox_1);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(136, 80, 51, 21));
        pushButton_9 = new QPushButton(groupBox_1);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setGeometry(QRect(210, 80, 51, 21));
        textEdit_3 = new QTextEdit(groupBox_1);
        textEdit_3->setObjectName(QStringLiteral("textEdit_3"));
        textEdit_3->setGeometry(QRect(57, 26, 31, 21));
        textEdit_3->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_3->setAcceptRichText(false);
        pushButton_6 = new QPushButton(groupBox_1);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(58, 80, 51, 21));
        groupBox_5 = new QGroupBox(centralWidget);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        groupBox_5->setGeometry(QRect(10, 130, 801, 211));
        label_11 = new QLabel(groupBox_5);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(10, 30, 61, 16));
        textEdit_6 = new QTextEdit(groupBox_5);
        textEdit_6->setObjectName(QStringLiteral("textEdit_6"));
        textEdit_6->setGeometry(QRect(68, 30, 61, 21));
        textEdit_6->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        label_12 = new QLabel(groupBox_5);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(10, 55, 61, 16));
        textEdit_7 = new QTextEdit(groupBox_5);
        textEdit_7->setObjectName(QStringLiteral("textEdit_7"));
        textEdit_7->setGeometry(QRect(68, 56, 61, 21));
        textEdit_7->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        label_13 = new QLabel(groupBox_5);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(10, 90, 51, 16));
        label_14 = new QLabel(groupBox_5);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(70, 90, 51, 16));
        pushButton_11 = new QPushButton(groupBox_5);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setGeometry(QRect(10, 119, 61, 27));
        pushButton_12 = new QPushButton(groupBox_5);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        pushButton_12->setGeometry(QRect(10, 149, 61, 27));
        pushButton_13 = new QPushButton(groupBox_5);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));
        pushButton_13->setGeometry(QRect(10, 179, 61, 27));
        textEdit_10 = new QTextEdit(groupBox_5);
        textEdit_10->setObjectName(QStringLiteral("textEdit_10"));
        textEdit_10->setGeometry(QRect(138, 30, 660, 171));
        QFont font;
        font.setFamily(QStringLiteral("Courier 10 Pitch"));
        textEdit_10->setFont(font);
        textEdit_10->setReadOnly(true);
        groupBox_6 = new QGroupBox(centralWidget);
        groupBox_6->setObjectName(QStringLiteral("groupBox_6"));
        groupBox_6->setGeometry(QRect(10, 350, 801, 201));
        label_15 = new QLabel(groupBox_6);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(10, 30, 61, 16));
        textEdit_8 = new QTextEdit(groupBox_6);
        textEdit_8->setObjectName(QStringLiteral("textEdit_8"));
        textEdit_8->setGeometry(QRect(70, 30, 61, 21));
        textEdit_8->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        label_17 = new QLabel(groupBox_6);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(11, 61, 61, 16));
        label_18 = new QLabel(groupBox_6);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(73, 62, 61, 16));
        pushButton_14 = new QPushButton(groupBox_6);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));
        pushButton_14->setGeometry(QRect(10, 100, 61, 27));
        pushButton_15 = new QPushButton(groupBox_6);
        pushButton_15->setObjectName(QStringLiteral("pushButton_15"));
        pushButton_15->setGeometry(QRect(10, 130, 61, 27));
        pushButton_16 = new QPushButton(groupBox_6);
        pushButton_16->setObjectName(QStringLiteral("pushButton_16"));
        pushButton_16->setGeometry(QRect(10, 160, 61, 27));
        textEdit_11 = new QTextEdit(groupBox_6);
        textEdit_11->setObjectName(QStringLiteral("textEdit_11"));
        textEdit_11->setGeometry(QRect(138, 30, 660, 171));
        textEdit_11->setFont(font);
        textEdit_11->setReadOnly(true);
        pushButton_16->raise();
        label_15->raise();
        textEdit_8->raise();
        label_17->raise();
        label_18->raise();
        pushButton_14->raise();
        pushButton_15->raise();
        textEdit_11->raise();
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(720, 30, 61, 27));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(720, 62, 61, 27));
        pushButton_4 = new QPushButton(centralWidget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(721, 94, 61, 27));
        MainWindow->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        comboBox_1->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "USB2SPI", 0));
        groupBox_1->setTitle(QApplication::translate("MainWindow", "I2C configuration", 0));
        label->setText(QApplication::translate("MainWindow", "Fre:", 0));
        comboBox_1->clear();
        comboBox_1->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "100K", 0)
         << QApplication::translate("MainWindow", "200K", 0)
         << QApplication::translate("MainWindow", "300K", 0)
         << QApplication::translate("MainWindow", "400K", 0)
         << QApplication::translate("MainWindow", "800K", 0)
        );
        label_2->setText(QApplication::translate("MainWindow", "Address:", 0));
        label_3->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Read Timeout:</p></body></html>", 0));
        textEdit_1->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">200</p></body></html>", 0));
        label_4->setText(QApplication::translate("MainWindow", "Write Timeout:", 0));
        textEdit_2->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">200</p></body></html>", 0));
        label_5->setText(QApplication::translate("MainWindow", "MS", 0));
        label_6->setText(QApplication::translate("MainWindow", "MS", 0));
        pushButton_5->setText(QApplication::translate("MainWindow", "Set", 0));
        pushButton_9->setText(QApplication::translate("MainWindow", "Reset", 0));
        textEdit_3->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">A0</p></body></html>", 0));
        pushButton_6->setText(QApplication::translate("MainWindow", "Address", 0));
        groupBox_5->setTitle(QApplication::translate("MainWindow", "Read", 0));
        label_11->setText(QApplication::translate("MainWindow", "Command:", 0));
        textEdit_6->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">00</p></body></html>", 0));
        label_12->setText(QApplication::translate("MainWindow", "Length:", 0));
        textEdit_7->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">256</p></body></html>", 0));
        label_13->setText(QApplication::translate("MainWindow", "Counter:", 0));
        label_14->setText(QApplication::translate("MainWindow", "00000000", 0));
        pushButton_11->setText(QApplication::translate("MainWindow", "Execute", 0));
        pushButton_12->setText(QApplication::translate("MainWindow", "Clear", 0));
        pushButton_13->setText(QApplication::translate("MainWindow", "Save", 0));
        groupBox_6->setTitle(QApplication::translate("MainWindow", "Write", 0));
        label_15->setText(QApplication::translate("MainWindow", "Command:", 0));
        textEdit_8->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">00</p></body></html>", 0));
        label_17->setText(QApplication::translate("MainWindow", "Counter:", 0));
        label_18->setText(QApplication::translate("MainWindow", "00000000", 0));
        pushButton_14->setText(QApplication::translate("MainWindow", "Execute", 0));
        pushButton_15->setText(QApplication::translate("MainWindow", "Clear", 0));
        pushButton_16->setText(QApplication::translate("MainWindow", "Load", 0));
        pushButton_2->setText(QApplication::translate("MainWindow", "Open", 0));
        pushButton->setText(QApplication::translate("MainWindow", "Exit", 0));
        pushButton_4->setText(QApplication::translate("MainWindow", "About", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
