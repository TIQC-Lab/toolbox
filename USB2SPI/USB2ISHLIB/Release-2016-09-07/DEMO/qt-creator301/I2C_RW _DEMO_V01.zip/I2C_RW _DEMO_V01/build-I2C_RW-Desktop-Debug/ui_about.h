/********************************************************************************
** Form generated from reading UI file 'about.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ABOUT_H
#define UI_ABOUT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_About
{
public:
    QPushButton *pushButton;
    QLabel *label_13;
    QLabel *label_14;
    QLabel *label_15;
    QLabel *label_16;
    QLabel *label_17;
    QLabel *label_18;
    QLabel *label_19;
    QLabel *label_20;
    QLabel *label_21;
    QLabel *label_22;
    QLabel *label_23;
    QLabel *label_24;
    QLabel *label_25;
    QLabel *label_26;

    void setupUi(QDialog *About)
    {
        if (About->objectName().isEmpty())
            About->setObjectName(QStringLiteral("About"));
        About->resize(400, 194);
        pushButton = new QPushButton(About);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(160, 150, 80, 22));
        label_13 = new QLabel(About);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(34, 36, 61, 16));
        label_14 = new QLabel(About);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(34, 66, 61, 16));
        label_15 = new QLabel(About);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(140, 10, 61, 16));
        label_16 = new QLabel(About);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(290, 10, 61, 16));
        label_17 = new QLabel(About);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(110, 36, 111, 16));
        label_18 = new QLabel(About);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(260, 36, 121, 16));
        label_19 = new QLabel(About);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setGeometry(QRect(110, 66, 111, 16));
        label_20 = new QLabel(About);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setGeometry(QRect(260, 66, 121, 16));
        label_21 = new QLabel(About);
        label_21->setObjectName(QStringLiteral("label_21"));
        label_21->setGeometry(QRect(35, 95, 61, 16));
        label_22 = new QLabel(About);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setGeometry(QRect(110, 96, 111, 16));
        label_23 = new QLabel(About);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setGeometry(QRect(36, 125, 61, 16));
        label_24 = new QLabel(About);
        label_24->setObjectName(QStringLiteral("label_24"));
        label_24->setGeometry(QRect(110, 125, 111, 16));
        label_25 = new QLabel(About);
        label_25->setObjectName(QStringLiteral("label_25"));
        label_25->setGeometry(QRect(260, 126, 121, 16));
        label_26 = new QLabel(About);
        label_26->setObjectName(QStringLiteral("label_26"));
        label_26->setGeometry(QRect(260, 100, 121, 16));

        retranslateUi(About);

        QMetaObject::connectSlotsByName(About);
    } // setupUi

    void retranslateUi(QDialog *About)
    {
        About->setWindowTitle(QApplication::translate("About", "About", 0));
        pushButton->setText(QApplication::translate("About", "OK", 0));
        label_13->setText(QApplication::translate("About", "APP:", 0));
        label_14->setText(QApplication::translate("About", "LIBUIS:", 0));
        label_15->setText(QApplication::translate("About", "Version", 0));
        label_16->setText(QApplication::translate("About", "Build Time", 0));
        label_17->setText(QApplication::translate("About", "APP:", 0));
        label_18->setText(QApplication::translate("About", "APP:", 0));
        label_19->setText(QApplication::translate("About", "APP:", 0));
        label_20->setText(QApplication::translate("About", "APP:", 0));
        label_21->setText(QApplication::translate("About", "LIBUSB:", 0));
        label_22->setText(QApplication::translate("About", "APP:", 0));
        label_23->setText(QApplication::translate("About", "Firmware:", 0));
        label_24->setText(QApplication::translate("About", "APP:", 0));
        label_25->setText(QApplication::translate("About", "APP:", 0));
        label_26->setText(QApplication::translate("About", "APP:", 0));
    } // retranslateUi

};

namespace Ui {
    class About: public Ui_About {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ABOUT_H
