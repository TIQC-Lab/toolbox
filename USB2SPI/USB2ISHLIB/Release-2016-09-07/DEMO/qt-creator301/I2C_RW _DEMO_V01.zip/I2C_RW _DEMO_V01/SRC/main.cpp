#include "mainwindow.h"
#include <QApplication>
MainWindow *pMainwindow;
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    pMainwindow = &w;
    w.show();

    return a.exec();
}
