#ifndef QMYEVENT_H
#define QMYEVENT_H

#include <QEvent>
#include "common.h"
class QMyEvent : public QEvent
{
public:
   QMyEvent(Type type);
   BYTE byIndex;
   DWORD dwStatus;
   void SetStatus(BYTE index,DWORD status);
};

#endif // QMYEVENT_H
