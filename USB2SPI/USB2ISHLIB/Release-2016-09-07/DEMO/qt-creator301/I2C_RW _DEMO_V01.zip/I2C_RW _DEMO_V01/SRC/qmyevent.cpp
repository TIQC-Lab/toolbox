#include "qmyevent.h"

QMyEvent::QMyEvent(Type type) :
    QEvent(type)
{
}


void QMyEvent::SetStatus(BYTE index,DWORD status)
{
    byIndex = index;
    dwStatus = status;
}
