#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <QListView>
#include <QStandardItem>
#include <QStandardItemModel>
#include <QModelIndex>
#include "common.h"
#include "usbio.h"


typedef struct
{
 BYTE byAddress;           //bit1~7 for slaver addrss
 BYTE byFreIndex;         //0~4 map 100k,200K,300K,400k,800K
 WORD wReadTimeout;
 WORD wWriteTimeout;
}I2C_PARA;


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
   void UpdateControl(void);
   void InitComboBox(void);
   void InitUSB(void);
   void InitSetting(void);
   bool GetReadPara(char* pCmd,BYTE* pbCmdSize,WORD* pwRWSizee);
   bool GetWritePara(char* pCmd,BYTE* pbCmdSize,WORD* pwRWSize);
private slots:

    void on_pushButton_2_clicked();
    void on_pushButton_11_clicked();
    void on_pushButton_12_clicked();
    void on_pushButton_15_clicked();
    void on_pushButton_5_clicked();   
    void on_pushButton_14_clicked();
    void on_pushButton_16_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_13_clicked();
    void on_pushButton_clicked();
    void on_pushButton_9_clicked();
     void on_pushButton_6_clicked();

private:
    Ui::MainWindow *ui;
    BYTE byDevIndex;
    DWORD dwIndex;
    char serialNo[12];
    I2C_PARA    myI2C;
    QVector<BYTE> ReadVector;
    QVector<BYTE>WriteVector;
    bool bAdvanced;
    void customEvent( QEvent *event );
};

#endif // MAINWINDOW_H
