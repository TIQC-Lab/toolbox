#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <pthread.h>
#include <qlistview.h>
 #include <QMessageBox>
#include <qfiledialog.h>
#include "usbio.h"
#include "about.h"
#include "qmyevent.h"

#define USB_MON_EVENT      1001
#define USB_TRIG_EVENT      1002

extern MainWindow *pMainwindow;
bool IsDigitString(QString&  str);
bool IsHexString(QString&  str);
void ExtractVer(char* pBuff, char type,char* pVerTime);
BYTE String2Hex(QString& str, char* pHex);
bool  USBIO_Status_Nofiy (BYTE index, DWORD	iStatus);
bool  USBIO_Trig_Nofiy (BYTE index, DWORD	iStatus);
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
     ui->setupUi(this);
    byDevIndex = 0xFF;
    QIntValidator* aIntValidator = new QIntValidator;
    aIntValidator->setRange(0, 1000);
    InitUSB();
    InitComboBox();
    InitSetting();
    UpdateControl();

}

MainWindow::~MainWindow()
{

     if(byDevIndex != 0xFF)
       USBIO_CloseDevice(byDevIndex);
  //  ExitUSB();
    delete ui;
}

void MainWindow::InitUSB(void)
{
  USBIO_SetUSBNotify(false,USBIO_Status_Nofiy);  //the first para unused at the platform of linux
}

bool  USBIO_Trig_Nofiy (BYTE index, DWORD	iStatus)
{
    QMyEvent *event = new QMyEvent(QEvent::Type(USB_TRIG_EVENT));
    event->byIndex = index;
    event->dwStatus = iStatus;
    qApp->postEvent( (QObject*)pMainwindow, event);
    return true;
}

bool USBIO_Status_Nofiy (BYTE index,DWORD iStatus)
{
    QMyEvent *event = new QMyEvent(QEvent::Type(USB_MON_EVENT));
    event->byIndex = index;
    event->dwStatus = iStatus;
    qApp->postEvent( (QObject*)pMainwindow, event);
   // delete event;
    return true;
}

void MainWindow::customEvent( QEvent *event )
{
    QMyEvent* pEvent = (QMyEvent*)event;
    int type = pEvent->type();
    if ( type == USB_MON_EVENT )
    {
     if(pEvent->byIndex == byDevIndex && pEvent->dwStatus == 0)   //remove event
     {
        byDevIndex = 0xFF;
        bAdvanced = false;
      }
     UpdateControl();
    }   
 //   delete event;
}

void MainWindow::InitSetting(void)
{
    myI2C.byAddress =0xA0;
    myI2C.byFreIndex = 0;
    myI2C.wReadTimeout = 200;
    myI2C.wWriteTimeout = 200;
    ReadVector.clear();
    WriteVector.clear();
}

void MainWindow::on_pushButton_2_clicked()
{
    BYTE cfg;
    DWORD timeout;
     bAdvanced = false;
    if(byDevIndex == 0xFF)
     {
       byDevIndex = USBIO_OpenDevice();
        if(byDevIndex == 0xFF)
        {
            QMessageBox message(QMessageBox::Warning," ","No find usb2uis device",QMessageBox::Ok,NULL);
            message.exec();
            return;
        }
        else
        {
            memset(serialNo,0,20);
            USBIO_GetSerialNo(byDevIndex,serialNo);
            if(strstr(serialNo,"AD"))
              bAdvanced = true;

            if(!USBIO_I2cGetConfig(byDevIndex,&myI2C.byAddress,&myI2C.byFreIndex,&timeout))
            {
                QMessageBox message(QMessageBox::Warning," ","Fail to read I2c PARA",QMessageBox::Ok,NULL);
                message.exec();
            }
            else
            {
               myI2C.wReadTimeout = timeout;
                myI2C.wWriteTimeout = timeout >> 16;
            }
     }
    }
    else
    {
        USBIO_CloseDevice(byDevIndex);
        byDevIndex = 0xFF;
    }
    UpdateControl();
}

void MainWindow::UpdateControl(void)
{
    QString str;
    ui->groupBox_1->setEnabled(byDevIndex != 0xFF);
    ui->groupBox_5->setEnabled(byDevIndex != 0xFF);
    ui->groupBox_6->setEnabled(byDevIndex != 0xFF);

    ui->pushButton_4->setEnabled(byDevIndex != 0xFF);

    if(byDevIndex == 0xFF)
    {
      setWindowTitle(QString("I2C_RW?"));
      ui->pushButton_2->setText("Open");
    }
    else
    {
     setWindowTitle(QString("I2C_RW::") + QString(serialNo));
     ui->pushButton_2->setText("Close");
    }


    if(byDevIndex == 0xFF)
        return;
       //update I2C
     str.sprintf("%d",myI2C.wReadTimeout);
     ui->textEdit_1->setText(str);
     str.sprintf("%d",myI2C.wWriteTimeout);
     ui->textEdit_2->setText(str);
     str.sprintf("%02X",myI2C.byAddress);
     ui->textEdit_3->setText(str);
     ui->comboBox_1->setCurrentIndex(myI2C.byFreIndex);
}

void MainWindow::InitComboBox(void)
{
  ui->comboBox_1->clear();
  ui->comboBox_1->addItem("100K");
  ui->comboBox_1->addItem("200K");
  ui->comboBox_1->addItem("300K");
  ui->comboBox_1->addItem("400K");
  ui->comboBox_1->addItem("800K");
  ui->comboBox_1->setCurrentIndex(0);
}

void MainWindow::on_pushButton_11_clicked()    //execute read
{
    char AddressString[256] ;
    BYTE byAddressLen;
    QString str1,str2,str;
    BYTE* pRxbuf;
    WORD rLength;
    if(!GetReadPara(AddressString,&byAddressLen,&rLength))
        return;
     pRxbuf = new BYTE[rLength];
     if(USBIO_I2cRead(byDevIndex,myI2C.byAddress,(BYTE*)AddressString,byAddressLen,pRxbuf, rLength)==false)
    {
        QMessageBox message(QMessageBox::Warning," ","Fail to read I2C",QMessageBox::Ok,NULL);
        message.exec();
        delete pRxbuf;
        return;
    } 
   for(int i = 0 ; i  < rLength; i++)
   {
      ReadVector.append(pRxbuf[i]);
   }
   char pTemp[4];
   str.clear();
   int len = ReadVector.length() ;
  for(int i = 0; i < len ; i++)
   {
      if(i % 16 == 0 && i % 32 != 0)
          str = str + QString(" ");
      sprintf(pTemp,"%02X ",ReadVector[i]);
      pTemp[3] = 0;
      str = str + QString(pTemp);
  }

   ui->textEdit_10->setText(str);
   str.sprintf("%08d",ReadVector.length());
   ui->label_14->setText(str);
}

void MainWindow::on_pushButton_14_clicked()    //execute write
{
    char AddressString[256] ;
    BYTE byAddressLen;
    WORD rLength;
    BYTE* pTxbuf;
    if(!GetWritePara(AddressString,&byAddressLen,&rLength))
        return;
     pTxbuf = new BYTE[rLength];
     for(int i = 0 ; i  < rLength; i++)
     {
       pTxbuf[i] = WriteVector[i];
     }
    if(USBIO_I2cWrite(byDevIndex,myI2C.byAddress,(BYTE*)AddressString,byAddressLen,pTxbuf,rLength)==false)
    {
        QMessageBox message(QMessageBox::Warning,"","USBIO_I2cWrite",QMessageBox::Ok,NULL);
        message.exec();
    }
   delete pTxbuf;
}

void MainWindow::on_pushButton_12_clicked() //clear read area
{
 ui->textEdit_10->clear();
 ReadVector.clear();
  ui->label_14->setText("00000000");
}

void MainWindow::on_pushButton_15_clicked()     //clear write area
{
    ui->textEdit_11->clear();
    WriteVector.clear();
     ui->label_18->setText("00000000");
}

void MainWindow::on_pushButton_5_clicked()    //set I2c
{
    DWORD timeout;
    BYTE fre,addr;
    QString str1,str2,str3;
    str1 = ui->textEdit_1->toPlainText();
    str2 = ui->textEdit_2->toPlainText();
    str3 = ui->textEdit_3->toPlainText();
    if(str1.isEmpty() || str2.isEmpty())
    {
        QMessageBox message(QMessageBox::Warning," ","No input for timeout",QMessageBox::Ok,NULL);
        message.exec();
        return;
    }
   if(!IsDigitString(str1) || !IsDigitString(str2) )
   {
       QMessageBox message(QMessageBox::Warning," ","Invalid format input for timeout",QMessageBox::Ok,NULL);
       message.exec();
       return;

   } 
   if(!IsHexString(str3) || str3.length() != 2)
   {
       QMessageBox message(QMessageBox::Warning," ","Invalid input format for Device address",QMessageBox::Ok,NULL);
       message.exec();
       return ;
   }
  String2Hex(str3,(char*)&addr);
  timeout = str2.toInt() * 65536 + str1.toInt();
  fre = ui->comboBox_1->currentIndex();
  if(USBIO_I2cSetConfig(byDevIndex,addr,fre,timeout))
  {
      myI2C.byAddress = addr;
      myI2C.byFreIndex = fre;
      myI2C.wReadTimeout = timeout;
      myI2C.wWriteTimeout = timeout >> 16;
      UpdateControl();
  }
}

bool IsDigitString(QString& str)
{
     char* p;
     QByteArray ba = str.toLatin1();
    p = ba.data();
    while(*p)
     {
       if(*p >= 0x30 && *p <= 0x39)
           p++;
      else
           return false;
    }
    return true;
}

bool IsHexString(QString& str)
{
    char* p;
    QByteArray ba = str.toLatin1();
   p = ba.data();
    while(*p)
     {
       if(*p >= 0x30 && *p <= 0x39 || *p >= 'a' && *p <= 'f' || *p >= 'A' && *p <= 'F')
           p++;
      else
           return false;
    }
    return true;
}

/* hex字符串转换成hex 数组
如 "123456"转换成pHex[] = {0x12,0x34,0x56};
正确返回pHex的长度，错误返回0
*/
BYTE String2Hex(QString& str,char* pHex)
{
  char* pString;
  QByteArray ba = str.toLatin1();
  pString = ba.data();
 BYTE uiStrLen;
 BYTE code = 0;
 BYTE i = 0;
 BYTE j = 0;
uiStrLen = strlen(pString);
 if(pString == NULL)
    return 0;
 for(i=0;i<uiStrLen;i++)
 {
  if(pString[i] <= '9' && pString[i] >= '0')
    code = code * 16 + (pString[i] - '0');
  else if(pString[i] <= 'F' && pString[i] >= 'A')
    code = code * 16 + (pString[i] - 'A' + 10);
  else if(pString[i] <= 'f' && pString[i] >= 'a')
   code = code * 16 + (pString[i] - 'a' + 10);
  else
   {
    if(j%2)
      {
       j--;
       code = 0;
      }
    continue;
   }
 j++;
 if(j%2==0)
 {
  pHex[j/2-1] = code;
  code = 0;
 }
 }
 return j/2;
}


void ExtractVer(char* pBuff,  char type,char* pVerTime)
{
int i,j;
char ver[30];
char time[30];
memset(ver,0,30);
memset(time,0,30);
for(i = 0 ; pBuff[i]!= ';'&&i<strlen(pBuff) ; i ++)
{
 ver[i] = pBuff[i];

}
if(i != strlen(pBuff))
{
i ++;
j = 0;
while(pBuff[i] && j < 30)
{
 time[j] = pBuff[i];
 i ++;
 j ++;
}
}
if(type == 0)
  memcpy(pVerTime,ver,30);
else
  memcpy(pVerTime,time,30);
 }


bool MainWindow::GetReadPara(char* pCmd,BYTE* pbCmdSize,WORD* pwRWSize)
{
    QString str1,str2;
    str1 = ui->textEdit_6->toPlainText();
    str2 = ui->textEdit_7->toPlainText();
    if(str2.isEmpty())
    {
        QMessageBox message(QMessageBox::Warning," ","No input for Length",QMessageBox::Ok,NULL);
        message.exec();
        return false;
    }
    if(!IsHexString(str1) || str1.length() % 2)
    {
        QMessageBox message(QMessageBox::Warning," ","Invalid input format for Commnad",QMessageBox::Ok,NULL);
        message.exec();
        return false;
    }
   *pbCmdSize =  String2Hex(str1,pCmd);
   *pwRWSize = str2.toInt();
    return true;
}

bool MainWindow::GetWritePara(char* pCmd,BYTE* pbCmdSize,WORD* pwRWSize)
{
    QString str1,str2;
    str1 = ui->textEdit_8->toPlainText();
    if(str1.isEmpty())
    {
      *pbCmdSize = 0;
    }
    else
     {
        if(!IsHexString(str1) || str1.length() % 2)
        {
            QMessageBox message(QMessageBox::Warning," ","Invalid input format for Commnad",QMessageBox::Ok,NULL);
            message.exec();
            return false;
        }
        *pbCmdSize =  String2Hex(str1,pCmd);
    }
     *pwRWSize  = WriteVector.length();
    if(*pbCmdSize == 0 &&  *pwRWSize == 0)
    {
        QMessageBox message(QMessageBox::Warning," ","No input write data",QMessageBox::Ok,NULL);
        message.exec();
        return false;
    }

    return true;
}



void MainWindow::on_pushButton_16_clicked()    //load file
{
    QString str;
    QStringList filters;
    filters<< "Bin files (*.bin)" << "Any files (*)";
     char a;
    char pTemp[4];
    QFileDialog *fileDialog = new QFileDialog(this);
    fileDialog->setWindowTitle(tr("Load file"));
    fileDialog->setDirectory(".");
    fileDialog->setAcceptMode(QFileDialog::AcceptOpen);
    fileDialog->setNameFilters(filters);
    if(fileDialog->exec() == QDialog::Accepted)
    {
        QString path = fileDialog->selectedFiles()[0];
  //      QMessageBox::information(NULL, tr("Path"), tr("You selected ") + path);
        QFile *file=new QFile(path);
         file->open(QIODevice::ReadOnly);
        QDataStream in(file);
        WriteVector.clear();

        while( in. readRawData(&a,1))
        {
            WriteVector.append(a);
        }
        int len = WriteVector.length();
        str.clear();
        for(int i = 0; i < len ; i++)
         {
            if(i % 16 == 0 && i % 32 != 0)
                str = str + QString(" ");
            sprintf(pTemp,"%02X ",WriteVector[i]);
            pTemp[3] = 0;
            str = str + QString(pTemp);
        }
       file->close();
       ui->textEdit_11->setText(str);
       str.sprintf("%08d",len);
       ui->label_18->setText(str);
     }

}

void MainWindow::on_pushButton_13_clicked()     //save file
{
    QStringList filters;
    char a;
    filters<< "Bin files (*.bin)" << "Any files (*)";
    QFileDialog *fileDialog = new QFileDialog(this);
    fileDialog->setWindowTitle(tr("Save file"));
    fileDialog->setDirectory(".");
    fileDialog->setAcceptMode(QFileDialog::AcceptSave);
    fileDialog->setNameFilters(filters);
    if(fileDialog->exec() == QDialog::Accepted)
   {
        QString path = fileDialog->selectedFiles()[0];
        if(path.indexOf(".bin") == -1)
        {
            path = path + QString(".bin");
        }

        QFile *file=new QFile(path);
        file->open(QIODevice::WriteOnly);
        QDataStream out(file);
        int len = ReadVector.length();
        for(int i = 0; i < len ; i++)
         {
           a = ReadVector[i];
          out.writeRawData(&a,1);
        }
       file->close();
    }
}

void MainWindow::on_pushButton_4_clicked()  //about
{
 About* pAbout = new About(this);
 char temp[50],time[30],ver[30];
 memset(temp,0,50);
 USBIO_GetVersion(byDevIndex,0,temp);
 ExtractVer(temp,0,ver);
 ExtractVer(temp,1,time);
 pAbout->SetVersionInfo(ver,time,0);
 memset(temp,0,50);
 USBIO_GetVersion(byDevIndex,1,temp);
 ExtractVer(temp,0,ver);
#ifdef LINUX
  pAbout->SetVersionInfo(ver,"----------",1);
#else
 ExtractVer(temp,1,time);
 pAbout->SetVersionInfo(ver,time,1);
#endif
 memset(temp,0,50);
 USBIO_GetVersion(byDevIndex,2,temp);
 ExtractVer(temp,0,ver);
 ExtractVer(temp,1,time);
 pAbout->SetVersionInfo(ver,time,2);
 pAbout->show();
}

void MainWindow::on_pushButton_clicked()  //exit
{

    close();
    #ifdef LINUX
      USBIO_ReleaseMem();
    #endif
}



void MainWindow::on_pushButton_9_clicked()    //I2c reset
{
  DWORD timeout;
  USBIO_ResetDevice(byDevIndex,DEV_I2C);
  USBIO_I2cGetConfig(byDevIndex,&myI2C.byAddress,&myI2C.byFreIndex,&timeout);
  myI2C.wReadTimeout = timeout;
  myI2C.wWriteTimeout = timeout >> 16;
   UpdateControl();
}

void MainWindow::on_pushButton_6_clicked()    //address
{
    BYTE addr;
    if(!USBIO_I2cAutoGetAddress(byDevIndex,&addr))
    {
        QMessageBox message(QMessageBox::Warning," ","USBIO_I2cAutoGetAddress fail",QMessageBox::Ok,NULL);
        message.exec();
        return;
    }
    if(addr == 0)
    {
        QMessageBox message(QMessageBox::Warning," ","No find I2c device",QMessageBox::Ok,NULL);
        message.exec();
        return;
    }
    myI2C.byAddress = addr;
    UpdateControl();
}
