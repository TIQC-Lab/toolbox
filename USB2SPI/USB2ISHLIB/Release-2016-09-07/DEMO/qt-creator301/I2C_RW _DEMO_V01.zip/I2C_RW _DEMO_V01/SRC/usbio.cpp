#include "usb2spi_global.h"

#define DllExport

typedef struct
{
 BYTE byDevType;
 BYTE byTrigOptions;       //low 4bit trig index,
                          //bit 4  = 1 trig read ,or write trig
                          //bit 7 = 1 trig running,or trig stop
 BYTE byIOTrigType;
 BYTE byCmdSize;          //must less than 16
 BYTE byCmd[16];
 WORD wTimerTrigInternal;
 WORD wRWSize;
 WORD wTrigSize;
}TRIG_CONFIG;

extern DEV_INFO* g_DevInfo;
extern FILE* pLogoFile;
extern bool bLogOn;
extern char BUILD_VERSION[];
extern char BUILD_DATE[] ;
extern char BUILD_TIME[] ;
extern GlobalInfo* pSharedMem;

extern void  TrigFunction(void* lpVoid);

//extern char* GetSerialNumber(BYTE i);

extern void LogPrintf(char* format,...);
extern BYTE FindDevIndex(char* SerialNo);
//extern USB_TRIG_CALLBACK pTrigUSB;
extern bool UIS_Rx(BYTE byIndex,BYTE* pbyRxBuf,DWORD wRxSize,WORD wTimeOut);
extern bool UIS_Tx(BYTE byIndex,BYTE* pbyTxBuf,DWORD wTxSize,WORD wTimeOut);

DllExport bool   USBIO_ResetDevice(BYTE byIndex,BYTE byDevId)
{
   LogPrintf( "USB2spi[%d] %s\n",byIndex,"USBIO_ResetDevice");
   bool bResult;
   BYTE buff[5];
   buff[0] = DEV_I2C+byDevId;// >> 8;
   buff[1] = OP_RESET & 0xFF;
  // bResult = DeviceControlWrite(byIndex,buff,2);
   if(buff[0]==DEV_I2C)
   {
    g_DevInfo[byIndex].wWriteI2cTimeout = 200;
    g_DevInfo[byIndex].wReadI2cTimeout  = 200;
   }
   else if(buff[0]==DEV_SPI)
   {
    g_DevInfo[byIndex].wWriteSpiTimeout = 200;
    g_DevInfo[byIndex].wReadSpiTimeout  = 200;
 }
   return bResult;
}

DllExport BYTE   USBIO_OpenDeviceByNumber(char* pSerialString)
       /*++
    Routine Description:
   open a usb2uis dev by pSerialString
Arguments:
   pSerialString - string contain the dev no
Return Value:
  a usb dev index
--*/
{

      int r;
      libusb_device_handle * pDevHand;
      BYTE index;
      index = FindDevIndex(pSerialString);
      LogPrintf( "%s\n","USBIO_OpenDeviceByNumber");
       if(index < MAX_DEV_NO )
       {
                    //LogPrintf( "%d status=%d \n",i,g_DevInfo[i].byStatus);
        if(g_DevInfo[index].byStatus == DEV_EXIST_UNOPENED)
        {
            LogPrintf( "%s %s\n","DEV_EXIST_UNOPENED",g_DevInfo[index].pDevPath);
            printf("%p\n",&g_DevInfo[index]);
            r = libusb_open(g_DevInfo[index].pDev,&pDevHand);
            if(r < 0)
            {
               LogPrintf("%s\n","failed to get open usb device "); //there was an error
               return 0xFF;
             }
            g_DevInfo[index].pDevHand = pDevHand;
            libusb_claim_interface(pDevHand,0);
            LogPrintf( "dev index = %d opened !\n",index);
            g_DevInfo[index].byStatus = DEV_OPENED;
       }
      else
       {
        LogPrintf( "%s has opened\n",pSerialString);
       }
      }
     return  index;
}

DllExport BYTE   USBIO_OpenDevice(void)
   /*++
Routine Description:
   open a usb2uis dev
Arguments:
   void
Return Value:
  a usb dev index
--*/
{
    int r;
    libusb_device_handle * pDevHand;
   LogPrintf( "%s\n","USBIO_OpenDevice");
   for(BYTE i = 0; i < MAX_DEV_NO; i++)
   {
       if(g_DevInfo[i].byStatus == DEV_EXIST_UNOPENED)
       {
           r = libusb_open(g_DevInfo[i].pDev,&pDevHand);
           if(r < 0)
           {
              LogPrintf("%s\n","failed to get open usb device "); //there was an error
              continue;
            }
        else
        {
           LogPrintf( "dev index = %d opened !\n",i);
           g_DevInfo[i].byStatus = DEV_OPENED;
           g_DevInfo[i].pDevHand = pDevHand;
           libusb_claim_interface(pDevHand,0);
          return i;
        }
      }
   }
 return 0xFF;
}

DllExport bool  USBIO_CloseDevice(BYTE byIndex)
   /*++
Routine Description:
   close a usb2uis dev
Arguments:
   byIndex - device No.
Return Value:
  none
--*/
{
   bool re ;
   LogPrintf( "USB2spi[%d] %s\n",byIndex,"USBIO_CloseDevice");
  libusb_release_interface(g_DevInfo[byIndex].pDevHand,0);
  libusb_close( g_DevInfo[byIndex].pDevHand );
  g_DevInfo[byIndex].byStatus = DEV_EXIST_UNOPENED;
  g_DevInfo[byIndex].pDevHand = NULL;
   return true;

}

DllExport void   USBIO_SetUSBNotify(bool bLoged,USB_DLL_CALLBACK pUSB_CallBack)
{

   LogPrintf( "%s\n","USBIO_SetUSBNotify");
   //pMonitorUSB = pUSB_CallBack;
   pSharedMem->thisLogoed = bLoged;
}

DllExport void   USBIO_SetTrigNotify(BYTE byIndex,USB_DLL_CALLBACK pTrig_CallBack)
{
   LogPrintf( "USB2spi[%d] %s++\n",byIndex,"USBIO_SetTrigNotify");
/*   g_DevInfo[byIndex].pTrigUSB = pTrig_CallBack;
   g_DevInfo[byIndex].byIndex = byIndex;
 g_DevInfo[byIndex].hTrigThread = (HANDLE) _beginthread(TrigFunction,0,(void*)&g_DevInfo[byIndex]);
   if(g_DevInfo[byIndex].hTrigThread == INVALID_HANDLE_VALUE)
   {
    LogPrintf( "%s \n","_beginthreadex fail");
   }
   SetThreadPriority(g_DevInfo[byIndex].hTrigThread,THREAD_PRIORITY_ABOVE_NORMAL);*/
   LogPrintf( "USB2spi[%d] %s--\n",byIndex,"USBIO_SetTrigNotify");
}

DllExport bool   USBIO_TrigSetConfig(BYTE byIndex,TRIG_CONFIG* pCfg)
/*++
Routine Description:
   init trigger
Arguments:
   byIndex       - device No.
   bySelect      - trigger type
--*/
{
   LogPrintf( "USB2spi[%d] %s\n",byIndex,"USBIO_TrigSetConfig");
   bool bResult;
   BYTE buff[64];
   buff[0] = IOCTL_SET_TRIG >> 8;
   buff[1] = IOCTL_SET_TRIG & 0xFF;

/*	buff[8] = pCfg->byTrigOptions;
   buff[9] = pCfg->byIOTrigType;
   buff[10] = pCfg->wTimerTrigInternal;
   buff[11] = pCfg->wTimerTrigInternal >> 8;

   buff[12] = pCfg->wRWSize;
   buff[13] = pCfg->wRWSize >> 8;
   buff[14] = pCfg->wTrigSize;
   buff[15] = pCfg->wTrigSize >> 8;
   buff[16] = pCfg->byCmdSize;*/

   memcpy(&buff[8],pCfg,sizeof(TRIG_CONFIG));
   bResult = UIS_Tx(byIndex,buff,64,10);
    return bResult;
}

DllExport bool   USBIO_TrigGetConfig(BYTE byIndex,TRIG_CONFIG* pCfg)
/*++
Routine Description:
   init trigger
Arguments:
   byIndex       - device No.
   pbySelect     - the pointer to read trigger type
--*/
{
   LogPrintf( "USB2spi[%d] %s\n",byIndex,"USBIO_TrigGetConfig");
   bool bResult;
   BYTE buff[64];
   buff[0] = IOCTL_GET_TRIG >> 8;
   buff[1] = IOCTL_GET_TRIG & 0xFF;
   bResult = UIS_Tx(byIndex,buff,64,10);
   if(!bResult)
   {
   LogPrintf( "%s fail\n","DeviceControlWrite");
    return false;
   }
   bResult = UIS_Rx(byIndex,buff,64,10);
   if(bResult && buff[0]==DEV_TRIG)
   {
        //*pbySelect         = buff[1];
        memcpy(pCfg,&buff[1],sizeof(TRIG_CONFIG));
   }
   else
   {
       bResult = false;
   }
   return bResult;
}

DllExport bool   USBIO_StartTrig(BYTE byIndex,BYTE byTrigType)
/*++
Routine Description:
   Enable trigger
Arguments:
   byIndex       - device No.
--*/
{
   LogPrintf( "USB2spi[%d] %s\n",byIndex,"USBIO_StartTrig");
   BYTE buff[64];
   buff[0] = IOCTL_START_TRIG >> 8;
   buff[1] = IOCTL_START_TRIG & 0xFF;
   buff[8] = byTrigType;
 LogPrintf( "byTrigType = %x \n",byTrigType);
   if(!UIS_Tx(byIndex,buff,64,10))
   {
    LogPrintf( "%s \n","UIS_Tx fail");
   return false;
   }
   return true;
}

DllExport bool   USBIO_StopTrig(BYTE byIndex,BYTE byTrigType)
{
   LogPrintf( "USB2spi[%d] %s\n",byIndex,"USBIO_StopTrig");
   BYTE buff[64];
   buff[0] = IOCTL_STOP_TRIG >> 8;
   buff[1] = IOCTL_STOP_TRIG & 0xFF;
   buff[8] = byTrigType;
   if(!UIS_Tx(byIndex,buff,64,10))
   {
       LogPrintf( "%s \n","UIS_Tx fail");
       return false;
   }
 return true;
}


DllExport bool    USBIO_SPISetConfig (BYTE byIndex,WORD wConfig,DWORD dwMilliseconds)
/*++
Routine Description:
   write data to i2c
Arguments:
   byIndex        - device No.
   wConfig        - SPI config;
   dwMilliseconds     - Specifies the timout for spi read or write, in ms.
Return Value:
  if opration successful . return true;
  else retutn false;
--*/
{
   LogPrintf( "USB2spi[%d] %s\n",byIndex,"USBIO_SPISetConfig");
   bool bResult;
   BYTE buff[64];
   memset(buff,0x55,64);
   buff[0] = IOCTL_SET_SPI >> 8;    //dev type
   buff[1] = IOCTL_SET_SPI & 0xFF;  //opt type
   buff[2] = 2;                     //com size
   buff[3] = 0;                     //data size
   buff[4] = 0;
   buff[5] = 0;
   buff[6] = 0;
   buff[7] = 0;
   buff[8] = wConfig >> 8 ;         //low data
   buff[9] = wConfig & 0xFF;        //high data
   g_DevInfo[byIndex].wWriteSpiTimeout = dwMilliseconds >>16;
   g_DevInfo[byIndex].wReadSpiTimeout  = dwMilliseconds & 0xFFFF;
//	memcpy(&buff[3],&wRate,2);
//	bResult = DeviceControlWrite(g_DevInfo[byIndex].hHandle,buff,3);
   if(!UIS_Tx(byIndex,buff,64,g_DevInfo[byIndex].wWriteSpiTimeout))
   {
    LogPrintf( "%s \n","UIS_Tx fail");
    return false;
   }
   return true;
}

DllExport bool    USBIO_SPIGetConfig(BYTE byIndex,WORD* pwConfig,DWORD* pdwMilliseconds)
/*++
Routine Description:
   read data from spi
Arguments:
   byIndex       - device No.
   pwConfig        - pointer to save spi clock .
   pdwMilliseconds     - pointer save the timout for spi read or write, in ms.
Return Value:
  if opration successful . return true;
  else retutn false;
--*/
{
   LogPrintf( "USB2spi[%d] %s\n",byIndex,"USBIO_SPIGetConfig");
   bool bResult;
   BYTE buff[64];
//	memset(buff,0x55,64);
   buff[0] = IOCTL_GET_SPI >> 8;    //dev type
   buff[1] = IOCTL_GET_SPI & 0xFF;  //opt type
   bResult = UIS_Tx(byIndex,buff,64,100);
   if(!bResult)
   {
       LogPrintf( "%s \n","UIS_Tx fail");
       return false;
   }
 bResult = UIS_Rx(byIndex,buff,64,100);
   if(!bResult||buff[0] != DEV_SPI )
   {
    LogPrintf( "%s \n","UIS_Rx fail");
    return false;
   }
   *pwConfig = buff[1] * 256 + buff[2];
   *pdwMilliseconds = ( g_DevInfo[byIndex].wWriteSpiTimeout << 16 ) + g_DevInfo[byIndex].wReadSpiTimeout;
   return bResult;

}

DllExport bool   USBIO_SPIRead(BYTE byIndex,LPVOID lpComBuffer,BYTE  byComSize,LPVOID lpBuffer,WORD wBuffSize)

/*Routine Description:
   transfer data from  spi
Arguments:
   byIndex       - device No.
   lpComBuffer  - Pointer to a buffer that contains the data required to perform the operation .
                   this para can be null if no need write data before reading
   byComSize    - Specifies the size, in bytes, of the buffer pointed to by lpInBuffer
   lpBuffer      - Pointer to a buffer that receives or sends the data
   wBuffSize     - request data size
Return Value:
  actual bytes to transfer from /to spi
--*/
{
   LogPrintf( "USB2spi[%d] %s\n",byIndex,"USBIO_SPIRead");

   BYTE buff[64];
   if(byComSize > 32)
       byComSize = 32;
   buff[0] = DEV_SPI;
   buff[1] = OP_READ;
   buff[2] = byComSize;
   buff[3] = 0;
   buff[4] = wBuffSize & 0xFF;
   buff[5] = wBuffSize >> 8;
   buff[6] = 0;
   buff[7] = 0;
   if(byComSize)
   {
    memcpy(&buff[8],lpComBuffer,byComSize);
   }
   if(!UIS_Tx(byIndex,buff,64,g_DevInfo[byIndex].wWriteSpiTimeout))
   {
        LogPrintf( "%s \n","UIS_Tx fail");
        return false;
   }
   if(!UIS_Rx(byIndex,(BYTE*)lpBuffer,wBuffSize,g_DevInfo[byIndex].wReadSpiTimeout))
   {
       LogPrintf( "%s \n","UIS_Rx fail");
       return false;
   }
   return true;
}

DllExport bool   USBIO_SPIWrite(BYTE byIndex,LPVOID lpComBuffer,BYTE  byComSize,LPVOID lpBuffer,WORD wBuffSize)

/*Routine Description:
   transfer data to spi
Arguments:
   byIndex       - device No.
   lpComBuffer  - Pointer to a buffer that contains the data required to perform the operation .
                   this para can be null if no need write data before reading
   byComSize    - Specifies the size, in bytes, of the buffer pointed to by lpInBuffer
   lpBuffer      - Pointer to a buffer that receives or sends the data
   wBuffSize     - request data size
Return Value:
  actual bytes to transfer from /to spi
--*/
{
   LogPrintf( "USB2spi[%d] %s\n",byIndex,"USBIO_SPIWrite");
   BYTE buff[64];
   int i;
   buff[0] = DEV_SPI;    //dev type
   buff[1] = OP_WRITE;   //opt type
   buff[2] = byComSize;  //comsize
   buff[3] = 0;          //unused
   buff[4] = wBuffSize & 0xFF;          //data size
   buff[5] = wBuffSize >> 8 ;
   buff[6] = 0;                     //data size
   buff[7] = 0;
   if(byComSize)
   {
       memcpy(&buff[8],lpComBuffer,byComSize);
   }
   if(!UIS_Tx(byIndex,buff,64,g_DevInfo[byIndex].wWriteSpiTimeout))
   {
    LogPrintf( "%s \n","UIS_Tx Head fail");
    return false;
   }
   if(wBuffSize && !UIS_Tx(byIndex,(BYTE*)lpBuffer,wBuffSize,g_DevInfo[byIndex].wWriteSpiTimeout))
   {
     LogPrintf( "%s \n","UIS_Tx data fail");
      return false;
   }
   return true;
}


DllExport bool    USBIO_SetBuffSize (BYTE byIndex,WORD wBuffsize)
/*++
Routine Description:
   set buff size
Arguments:
   byIndex        - device No.
   wBuffsize      - buff size max 8192;
Return Value:
  if opration successful . return true;
  else retutn false;
--*/
{
   LogPrintf( "USB2spi[%d] %s\n",byIndex,"USBIO_SetBuffSize");
   bool bResult;
   BYTE buff[64];
   if(wBuffsize > MAX_BUFF_SIZE)
       wBuffsize = MAX_BUFF_SIZE;
   buff[0] = IOCTL_SET_BUFF >> 8;    //dev type
   buff[1] = IOCTL_SET_BUFF & 0xFF;  //opt type
   buff[2] = 0;       //com size
   buff[3] = 0;                     //data size
   buff[4] = 0;
   buff[5] = 0;
   buff[6] = 0;
   buff[7] = 0;
   buff[8] = wBuffsize >> 8 ;         //high data
   buff[9] = wBuffsize & 0xFF;        //low data
   if(!UIS_Tx(byIndex,buff,64,10))
   {
    LogPrintf( "%s \n","UIS_Tx fail");
    return false;
   }
   return true;
}

DllExport bool    USBIO_GetBuffSize(BYTE byIndex,WORD* pwBuffsize)
/*++
Routine Description:
   get buff size
Arguments:
   byIndex       - device No.
   pwBuffsize        - pointer to save buffsize .

Return Value:
  if opration successful . return true;
  else retutn false;
--*/
{
   LogPrintf( "USB2spi[%d] %s\n",byIndex,"USBIO_GetBuffSize");
   bool bResult;
   BYTE buff[64];
   buff[0] = IOCTL_GET_BUFF >> 8;    //dev type
   buff[1] = IOCTL_GET_BUFF & 0xFF;  //opt type
   bResult = UIS_Tx(byIndex,buff,64,10);
   if(!bResult)
   {
       LogPrintf( "%s \n","UIS_Tx fail");
       return false;
   }
 bResult = UIS_Rx(byIndex,buff,64,10);
   if(!bResult||buff[0] != DEV_MEM )
   {
    LogPrintf( "%s \n","UIS_Rx fail");
    return false;
   }
   *pwBuffsize = buff[1] * 256 + buff[2];
   return true;
}
DllExport bool   USBIO_BuffRead(BYTE byIndex,WORD wAddr,LPVOID lpBuffer,WORD wBuffSize)

/*Routine Description:
   transfer data from  buff
Arguments:
   byIndex       - device No.
   lpBuffer      - Pointer to a buffer that receives or sends the data
   wBuffSize     - request data size
Return Value:
  true if success
--*/
{
   LogPrintf( "USB2spi[%d] %s\n",byIndex,"USBIO_BuffRead");
   BYTE buff[64];
   buff[0] = DEV_MEM;
   buff[1] = OP_READ;
   buff[2] = 2;
   buff[3] = 0;
   buff[4] = wBuffSize & 0xFF;
   buff[5] = wBuffSize >> 8;
   buff[6] = 0;
   buff[7] = 0;
   buff[8] = wAddr >> 8;
   buff[9] = wAddr & 0xFF;
   if(!UIS_Tx(byIndex,buff,64,10))
   {
        LogPrintf( "%s \n","UIS_Tx fail");
        return false;
   }
   if(!UIS_Rx(byIndex,(BYTE*)lpBuffer,wBuffSize,200))
   {
           LogPrintf( "%s \n","UIS_Rx fail");
           return false;
   }
   return true;
}

DllExport bool   USBIO_BuffWrite(BYTE byIndex,WORD wAddr,LPVOID lpBuffer,WORD wBuffSize)

/*Routine Description:
   transfer data to buff
Arguments:
   byIndex       - device No.
  lpBuffer      - Pointer to a buffer that sends the data
  wBuffSize     - request data size  maxsize 8096
Return Value:
  actual bytes to transfer from /to spi
--*/
{
   LogPrintf( "USB2spi[%d] %s\n",byIndex,"USBIO_BuffWrite");
   BYTE buff[64];
   int i;
   buff[0] = DEV_MEM;    //dev type
   buff[1] = OP_WRITE;   //opt type
   buff[2] = 2 ;  //comsize
   buff[3] = 0;          //unused
   buff[4] = wBuffSize & 0xFF;
   buff[5] = wBuffSize >> 8 ;                     //data size
   buff[6] = 0;          //data size
   buff[7] = 0;
   buff[8] = wAddr >> 8;
   buff[9] = wAddr & 0xFF;
   if(!UIS_Tx(byIndex,buff,64,10))
   {
    LogPrintf( "%s \n","UIS_Tx Head fail");
    return false;
   }
   if(wBuffSize && !UIS_Tx(byIndex,(BYTE*)lpBuffer,wBuffSize,200))
   {
     LogPrintf( "%s \n","UIS_Tx data fail");
     return false;
   }
   return true;
}

DllExport bool USBIO_GetVersion(BYTE byIndex,BYTE byType,LPVOID lpBuffer)
/*Routine Description:
   get version info
Arguments:
   byIndex       - device No.
   byType        - the type of version info
   lpBuffer      - a pointer to read the version info

Return Value:
  true if write successful
--*/
{
   LogPrintf( "USB2spi[%d] %s\n",byIndex,"USBIO_GetVersion");
   bool bResult;
   BYTE len;
   char* pBuff = (char*)lpBuffer;
   if(byType == 0 || byType == 1)   //get dll version
   {
    len = strlen(BUILD_VERSION);
    memcpy(pBuff,BUILD_VERSION,len);
    pBuff[len++]= ';';
    memcpy(&pBuff[len],BUILD_DATE,strlen(BUILD_DATE));
    len = len + strlen(BUILD_DATE);
    pBuff[len++]= ' ';
    memcpy(&pBuff[len],BUILD_TIME,strlen(BUILD_TIME));
    len = len + strlen(BUILD_TIME);
    pBuff[len++]= 0;
    bResult = true;
   }
   else if(byType == 2)   //ger firmware version
   {
     BYTE buff[64];
     buff[0] = DEV_ALL;
     buff[1] = OP_VERSION;
     bResult = UIS_Tx(byIndex,buff,64,10);
     if(!bResult)
     {
      LogPrintf( "%s\n","DeviceControlWrite fail");
      return false;
     }
     bResult = UIS_Rx(byIndex,buff,64,10);
     LogPrintf( "buff[0] = %x\n",buff[0]);
     if(bResult && buff[0]==DEV_ALL)
     {
        memcpy(pBuff,&buff[1],MAX_VER_STRING_LEN);
     }
     else
     {
         bResult = false;
         LogPrintf( "%s\n","UIS_Rx fail");
     }

 }
 else if(byType == 3)   //ger cpu_id
   {
     BYTE buff[64];
     buff[0] = DEV_ALL;
     buff[1] = OP_CPUID;
     bResult = UIS_Tx(byIndex,buff,64,10);
     if(!bResult)
     {
      LogPrintf( "%s\n","UIS_Tx fail");
       return false;
     }
     bResult = UIS_Rx(byIndex,buff,64,10);
     LogPrintf( "buff[0] = %x\n",buff[0]);
     if(bResult && buff[0]==DEV_ALL)
     {
        memcpy(pBuff,&buff[1],12);
     }
     else
     {
         bResult = false;
         LogPrintf( "%s\n","UIS_Rx fail");

     }

 }
 else if(byType == 4)   //ger user_data
   {
     BYTE buff[64];
     buff[0] = DEV_ALL;
     buff[1] = OP_USER_DATA;
     bResult = UIS_Tx(byIndex,buff,64,10);
     if(!bResult)
     {
      LogPrintf( "%s\n","UIS_Tx fail");
      return false;
     }
     bResult = UIS_Rx(byIndex,buff,64,10);
     if(bResult)
     {
        memcpy(pBuff,buff,64);
     }
     else
     {
         bResult = false;
         LogPrintf( "%s\n","UIS_Rx fail");
     }

 }
  return bResult;
}

DllExport BYTE USBIO_GetMaxNumofDev(void)
{
   LogPrintf( "%s++\n","USBIO_GetMaxNumofDev");
   LogPrintf( "%s--\n","USBIO_GetMaxNumofDev");
   return MAX_DEV_NO;

}

DllExport BYTE USBIO_GetSerialNo(BYTE byIndex,char* lpBuff)
/*Routine Description:
   get device serial no.
Arguments:
   byIndex     -  device No.
Return Value:
  the status of the device index
--*/
{
   BYTE status  = DEV_NO_EXIST;
   LogPrintf( "USB2spi[%d] %s\n",byIndex,"USBIO_GetSerialNo");
   if(byIndex >= MAX_DEV_NO)
   {
      return DEV_NO_EXIST;
   }   
   if(g_DevInfo[byIndex].byStatus != DEV_NO_EXIST)
   {
     memcpy(lpBuff,  g_DevInfo[byIndex].pDevPath,10);
    status = g_DevInfo[byIndex].byStatus;
   }
    return status;
}

DllExport bool USBIO_SetGPIOConfig(BYTE byIndex,DWORD dwValue)
/*++
Routine Description:
   config GPIO direction
Arguments:
   byIndex       - device No.
   dwValue       - IO in/out 1：in, 0: out
Return Value:
  if opration successful . return true;
  else retutn false;
--*/
{
   LogPrintf( "USB2spi[%d] %s++\n",byIndex,"USBIO_SetGPIOConfig");
   bool bResult;
   BYTE buff[64];
   buff[0] = IOCTL_SET_GPIO >> 8;
   buff[1] = IOCTL_SET_GPIO & 0xFF;
   buff[2] = 0 ;
   buff[8] = dwValue >> 24;
   buff[9] = dwValue >> 16;
   buff[10] = dwValue >> 8;
   buff[11] = dwValue;

   bResult = UIS_Tx(byIndex,buff,64,10);
   LogPrintf( "USB2spi[%d] %s--\n",byIndex,"USBIO_SetGPIOConfig");
   return bResult;
}

DllExport bool  USBIO_GetGPIOConfig(BYTE byIndex,DWORD* pdwValue)
/*++
Routine Description:
   read GPIO config
Arguments:
   byIndex       - device No.
   pdwValue      - a pointer that saved io direct value
Return Value:
  if opration successful . return true;
  else retutn false;
--*/
{
   LogPrintf( "USB2spi[%d] %s++\n",byIndex,"USBIO_GetGPIOConfig");
   bool bResult;
   BYTE buff[64];
   buff[0] = IOCTL_GET_GPIO >> 8;
   buff[1] = IOCTL_GET_GPIO & 0xFF;
   bResult = UIS_Tx(byIndex,buff,64,10);
   if(!bResult)
   {
     LogPrintf( "DeviceControlWrite fail\n");
     return false;
   }
   bResult = UIS_Rx(byIndex,buff,64,10);
   if(bResult && buff[0]==DEV_GPIO)
   {
        *pdwValue         = ( buff[1] << 24 ) + ( buff[2] << 16 ) + ( buff[3] << 8) + buff[4] ;
   }
   else
   {
       LogPrintf( "DeviceControlRead  fail\n");
       return false;
   }
   LogPrintf( "USB2spi[%d] %s--\n",byIndex,"USBIO_GetGPIOConfig");
   return bResult;
}

DllExport bool    USBIO_GPIOWrite(BYTE byIndex,BYTE byValue,BYTE byMask)
/*++
Routine Description:
   write data to gpio
Arguments:
   byIndex       - device No.
   byValue        - GPIO value;
   byMask         - Mask value;

Return Value:
  if opration successful . return true;
  else retutn false;
--*/
{
   LogPrintf( "USB2spi[%d] %s++\n",byIndex,"USBIO_GPIOWrite");
   bool bResult;
   BYTE buff[64];
   buff[0] = DEV_GPIO;
   buff[1] = OP_WRITE;
   buff[8] = byValue;
   buff[9] = byMask;
   bResult = UIS_Tx(byIndex,buff,64,10);
   LogPrintf( "USB2spi[%d] %s--\n",byIndex,"USBIO_GPIOWrite");
   return bResult;
}

DllExport bool USBIO_GPIORead(BYTE byIndex,BYTE* pbyValue)
/*++
Routine Description:
   read data from GPIO
Arguments:
   byIndex       - device No.
   pbyValue       - pointer save the data to read from gpio.
Return Value:
  if opration successful . return true;
  else retutn false;
--*/
{
   LogPrintf( "USB2spi[%d] %s++\n",byIndex,"USBIO_GPIORead");
//	bool bResult;
   BYTE buff[64];
   buff[0] = DEV_GPIO;
   buff[1] = OP_READ;
   if(!UIS_Tx(byIndex,buff,64,10))
   {
       LogPrintf( "UIS_Tx fail\n");
       return false;
   }
   if(!UIS_Rx(byIndex,buff,64,10))
       {
           LogPrintf( "UIS_Rx fail\n");
           return false;
       }
       if(buff[0]!=DEV_GPIO)
       {
           LogPrintf( "verify fail\n");
           return false;
       }

   *pbyValue         = buff[1];
   LogPrintf( "USB2spi[%d] %s--\n",byIndex,"USBIO_GPIORead");
   return true;
}
