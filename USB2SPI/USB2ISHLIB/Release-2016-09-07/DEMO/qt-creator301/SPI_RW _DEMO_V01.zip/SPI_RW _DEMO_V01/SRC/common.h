#ifndef COMMON_H
#define COMMON_H

#include <QtCore/qglobal.h>

#include <stdio.h>
#include <string.h>

typedef    unsigned char BYTE ;
typedef    unsigned  short WORD;
typedef    unsigned  int     DWORD;
typedef    void          VOID;
typedef    void*         LPVOID;



#define true            1
#define false           0
#define DEV_UART     0x80
#define DEV_I2C      0x81
#define DEV_SPI      0x82
#define DEV_TIMER    0x83
#define DEV_CAN      0x84
#define DEV_GPIO     0x85
#define DEV_ADC      0x86
#define DEV_PWM      0x87
#define DEV_PARALLEL 0x88
#define DEV_MEM      0x8D
#define DEV_TRIG     0x8E
#define DEV_ALL      0x8F



#define MAX_DEV_NO   10
//#define devItem {NULL,NULL,200,200,200,200,200,200,200,200,{0},0}
#define SHARE_MEM_SIZE    8192
typedef	bool (* USB_DLL_CALLBACK)(BYTE iDevIndex,DWORD iDevStatus);
enum
  {
    DEV_NO_EXIST = 0,
    DEV_EXIST_UNOPENED,
    DEV_OPENED
  };

#endif 
