#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <QListView>
#include <QStandardItem>
#include <QStandardItemModel>
#include <QModelIndex>
#include "common.h"
#include "usbio.h"

typedef struct
{
 BYTE bySPICfg;            /*bit0~3: frequency index,  0~8 map 200k,400k,600k,800k,1000k,2000k,4000k,6000k,12000K
                                          bit4~bit5: SPI  mode   0~3  00=>(POL=0,PHA=0);
                                                                                       01=>(POL=0,PHA=1);
                                                                                       10=>(POL=1,PHA=0);
                                                                                       11=>(POL=1,PHA=1)
                                           bit6:  unused
                                           bit7: SPI  M/S  0=>master; 1=>slaver
                                           */
 WORD wReadTimeout;
 WORD wWriteTimeout;
}SPI_PARA;

typedef struct
{
 BYTE byFreIndex;             /*bit0~3: frequency index,  0~10 map 1k,2k,4k,6k,8k,10k,20k,40k,50k,60k,100k
                                               bit4~bit6: unused
                                               bit7: 0=>stopped;1=>running
                                              */
BYTE byNum;                     //the channels of used

WORD wDuty[4];              //chan1 ~chan4 duty
}PWM_PARA;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
   void UpdateControl(void);
   void InitComboBox(void);
   void InitListView(void);
   void InitUSB(void);
   void InitSetting(void);
   void  USB_ReciData(WORD wLength);
   void  USB_SendData(WORD wLength);
   bool GetReadPara(char* pCmd,BYTE* pbCmdSize,WORD* pwRWSizee);
   bool GetWritePara(char* pCmd,BYTE* pbCmdSize,WORD* pwRWSize);
private slots:

    void on_pushButton_2_clicked();

    void on_pushButton_11_clicked();

    void on_pushButton_12_clicked();

    void on_pushButton_15_clicked();

    void on_pushButton_5_clicked();   

    void on_pushButton_7_clicked();

    void on_pushButton_10_clicked();

    void on_pushButton_8_clicked();

    void on_pushButton_14_clicked();

    void on_pushButton_16_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_13_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_clicked();

    void on_pushButton_17_clicked();

    void on_pushButton_9_clicked();

    void on_pushButton_18_clicked();

    void on_pushButton_19_clicked();

    void on_pushButton_20_clicked();

    void on_pushButton_21_clicked();

private:
    Ui::MainWindow *ui;
    BYTE byDevIndex;
    DWORD dwIndex;
    char serialNo[12];
    BYTE myTrig;
    SPI_PARA    mySPI;
    PWM_PARA myPWM;
    BYTE byGPIOConfig;
    BYTE byGPIOValue;
    QVector<BYTE> ReadVector;
    QVector<BYTE>WriteVector;
    bool bAdvanced;
    void customEvent( QEvent *event );
};

#endif // MAINWINDOW_H
