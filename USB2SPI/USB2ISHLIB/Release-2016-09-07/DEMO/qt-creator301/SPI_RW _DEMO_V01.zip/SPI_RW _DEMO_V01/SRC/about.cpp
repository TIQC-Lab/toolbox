#include "about.h"
#include "ui_about.h"

About::About(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::About)
{
    ui->setupUi(this);
    ui->label_17->setText(QString("SPI_RW_DEMO_V01"));
    ui->label_18 ->setText(QString((char*)__DATE__)  + QString(" ")  + QString((char*)__TIME__)) ;
}

About::~About()
{
    delete ui;
}

void About::SetVersionInfo(char* pVersion,char* pBuildTime,int type)
{
   if(type ==0)   //libuis.so or dll
   {
       ui->label_19->setText(pVersion);
      ui->label_20->setText(pBuildTime);
     }
   else if(type ==1)  //libusb.so or sys
      {
       ui->label_22->setText(pVersion);
      ui->label_26->setText(pBuildTime);
   }
   else if(type ==2)  //firmware
   {
    ui->label_24->setText(pVersion);
   ui->label_25->setText(pBuildTime);
}

}

void About::on_pushButton_clicked()
{
   close();
}
