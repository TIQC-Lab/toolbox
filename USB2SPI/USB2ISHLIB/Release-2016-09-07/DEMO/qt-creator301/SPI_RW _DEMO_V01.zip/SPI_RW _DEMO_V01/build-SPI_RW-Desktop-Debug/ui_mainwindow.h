/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.2.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGroupBox *groupBox_1;
    QLabel *label;
    QComboBox *comboBox_1;
    QComboBox *comboBox_2;
    QLabel *label_2;
    QLabel *label_3;
    QTextEdit *textEdit_1;
    QLabel *label_4;
    QTextEdit *textEdit_2;
    QLabel *label_5;
    QLabel *label_6;
    QCheckBox *checkBox_1;
    QPushButton *pushButton_5;
    QPushButton *pushButton_9;
    QGroupBox *groupBox_2;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QListWidget *listWidget;
    QGroupBox *groupBox_4;
    QComboBox *comboBox_3;
    QPushButton *pushButton_10;
    QPushButton *pushButton_6;
    QGroupBox *groupBox_5;
    QLabel *label_11;
    QTextEdit *textEdit_6;
    QLabel *label_12;
    QTextEdit *textEdit_7;
    QLabel *label_13;
    QLabel *label_14;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QPushButton *pushButton_13;
    QTextEdit *textEdit_10;
    QCheckBox *checkBox_2;
    QGroupBox *groupBox_6;
    QLabel *label_15;
    QTextEdit *textEdit_8;
    QLabel *label_17;
    QLabel *label_18;
    QPushButton *pushButton_14;
    QPushButton *pushButton_15;
    QPushButton *pushButton_16;
    QTextEdit *textEdit_11;
    QGroupBox *groupBox_3;
    QPushButton *pushButton_7;
    QCheckBox *checkBox_3;
    QCheckBox *checkBox_4;
    QCheckBox *checkBox_5;
    QCheckBox *checkBox_6;
    QCheckBox *checkBox_8;
    QCheckBox *checkBox_7;
    QCheckBox *checkBox_9;
    QCheckBox *checkBox_10;
    QPushButton *pushButton_8;
    QGroupBox *groupBox_7;
    QPushButton *pushButton_17;
    QCheckBox *checkBox_11;
    QCheckBox *checkBox_12;
    QCheckBox *checkBox_13;
    QCheckBox *checkBox_14;
    QCheckBox *checkBox_16;
    QCheckBox *checkBox_15;
    QCheckBox *checkBox_17;
    QCheckBox *checkBox_18;
    QPushButton *pushButton_18;
    QGroupBox *groupBox_8;
    QComboBox *comboBox_4;
    QLabel *label_7;
    QLabel *label_8;
    QComboBox *comboBox_5;
    QLineEdit *lineEdit_1;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_16;
    QLabel *label_19;
    QLabel *label_22;
    QLabel *label_23;
    QPushButton *pushButton_19;
    QPushButton *pushButton_20;
    QPushButton *pushButton_21;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(816, 662);
        MainWindow->setMouseTracking(false);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        groupBox_1 = new QGroupBox(centralWidget);
        groupBox_1->setObjectName(QStringLiteral("groupBox_1"));
        groupBox_1->setGeometry(QRect(10, 90, 281, 111));
        groupBox_1->setFlat(false);
        groupBox_1->setCheckable(false);
        label = new QLabel(groupBox_1);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 53, 31, 16));
        comboBox_1 = new QComboBox(groupBox_1);
        comboBox_1->setObjectName(QStringLiteral("comboBox_1"));
        comboBox_1->setGeometry(QRect(45, 53, 71, 23));
        comboBox_2 = new QComboBox(groupBox_1);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setGeometry(QRect(45, 26, 71, 23));
        label_2 = new QLabel(groupBox_1);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(10, 26, 35, 16));
        label_3 = new QLabel(groupBox_1);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(136, 30, 81, 16));
        textEdit_1 = new QTextEdit(groupBox_1);
        textEdit_1->setObjectName(QStringLiteral("textEdit_1"));
        textEdit_1->setGeometry(QRect(217, 27, 41, 21));
        textEdit_1->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        textEdit_1->setAcceptRichText(false);
        label_4 = new QLabel(groupBox_1);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(136, 53, 81, 16));
        textEdit_2 = new QTextEdit(groupBox_1);
        textEdit_2->setObjectName(QStringLiteral("textEdit_2"));
        textEdit_2->setGeometry(QRect(217, 51, 41, 21));
        textEdit_2->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        label_5 = new QLabel(groupBox_1);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(260, 32, 21, 16));
        label_6 = new QLabel(groupBox_1);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(260, 52, 21, 16));
        checkBox_1 = new QCheckBox(groupBox_1);
        checkBox_1->setObjectName(QStringLiteral("checkBox_1"));
        checkBox_1->setGeometry(QRect(50, 80, 68, 21));
        pushButton_5 = new QPushButton(groupBox_1);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(130, 80, 51, 21));
        pushButton_9 = new QPushButton(groupBox_1);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setGeometry(QRect(210, 80, 51, 21));
        groupBox_2 = new QGroupBox(centralWidget);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(10, 0, 361, 85));
        pushButton = new QPushButton(groupBox_2);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(294, 23, 61, 27));
        pushButton_2 = new QPushButton(groupBox_2);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(230, 23, 61, 27));
        pushButton_3 = new QPushButton(groupBox_2);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(230, 52, 61, 27));
        pushButton_4 = new QPushButton(groupBox_2);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(294, 52, 61, 27));
        listWidget = new QListWidget(groupBox_2);
        listWidget->setObjectName(QStringLiteral("listWidget"));
        listWidget->setGeometry(QRect(9, 24, 211, 55));
        groupBox_4 = new QGroupBox(centralWidget);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        groupBox_4->setEnabled(true);
        groupBox_4->setGeometry(QRect(295, 90, 81, 111));
        groupBox_4->setCheckable(false);
        groupBox_4->setChecked(false);
        comboBox_3 = new QComboBox(groupBox_4);
        comboBox_3->setObjectName(QStringLiteral("comboBox_3"));
        comboBox_3->setGeometry(QRect(10, 30, 61, 21));
        pushButton_10 = new QPushButton(groupBox_4);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setGeometry(QRect(10, 83, 61, 23));
        pushButton_6 = new QPushButton(groupBox_4);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(10, 56, 61, 22));
        groupBox_5 = new QGroupBox(centralWidget);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        groupBox_5->setGeometry(QRect(10, 210, 801, 211));
        label_11 = new QLabel(groupBox_5);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(10, 30, 61, 16));
        textEdit_6 = new QTextEdit(groupBox_5);
        textEdit_6->setObjectName(QStringLiteral("textEdit_6"));
        textEdit_6->setGeometry(QRect(68, 30, 61, 21));
        textEdit_6->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        label_12 = new QLabel(groupBox_5);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(10, 55, 61, 16));
        textEdit_7 = new QTextEdit(groupBox_5);
        textEdit_7->setObjectName(QStringLiteral("textEdit_7"));
        textEdit_7->setGeometry(QRect(68, 56, 61, 21));
        textEdit_7->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        label_13 = new QLabel(groupBox_5);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(79, 121, 51, 16));
        label_14 = new QLabel(groupBox_5);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(79, 140, 51, 16));
        pushButton_11 = new QPushButton(groupBox_5);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setGeometry(QRect(10, 119, 61, 27));
        pushButton_12 = new QPushButton(groupBox_5);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        pushButton_12->setGeometry(QRect(10, 149, 61, 27));
        pushButton_13 = new QPushButton(groupBox_5);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));
        pushButton_13->setGeometry(QRect(10, 179, 61, 27));
        textEdit_10 = new QTextEdit(groupBox_5);
        textEdit_10->setObjectName(QStringLiteral("textEdit_10"));
        textEdit_10->setGeometry(QRect(138, 30, 660, 171));
        QFont font;
        font.setFamily(QStringLiteral("Courier 10 Pitch"));
        textEdit_10->setFont(font);
        textEdit_10->setReadOnly(true);
        checkBox_2 = new QCheckBox(groupBox_5);
        checkBox_2->setObjectName(QStringLiteral("checkBox_2"));
        checkBox_2->setGeometry(QRect(13, 85, 91, 21));
        groupBox_6 = new QGroupBox(centralWidget);
        groupBox_6->setObjectName(QStringLiteral("groupBox_6"));
        groupBox_6->setGeometry(QRect(10, 420, 801, 201));
        label_15 = new QLabel(groupBox_6);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(10, 30, 61, 16));
        textEdit_8 = new QTextEdit(groupBox_6);
        textEdit_8->setObjectName(QStringLiteral("textEdit_8"));
        textEdit_8->setGeometry(QRect(70, 30, 61, 21));
        textEdit_8->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        label_17 = new QLabel(groupBox_6);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(11, 61, 61, 16));
        label_18 = new QLabel(groupBox_6);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(73, 62, 61, 16));
        pushButton_14 = new QPushButton(groupBox_6);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));
        pushButton_14->setGeometry(QRect(10, 100, 61, 27));
        pushButton_15 = new QPushButton(groupBox_6);
        pushButton_15->setObjectName(QStringLiteral("pushButton_15"));
        pushButton_15->setGeometry(QRect(10, 130, 61, 27));
        pushButton_16 = new QPushButton(groupBox_6);
        pushButton_16->setObjectName(QStringLiteral("pushButton_16"));
        pushButton_16->setGeometry(QRect(10, 160, 61, 27));
        textEdit_11 = new QTextEdit(groupBox_6);
        textEdit_11->setObjectName(QStringLiteral("textEdit_11"));
        textEdit_11->setGeometry(QRect(138, 30, 660, 171));
        textEdit_11->setFont(font);
        textEdit_11->setReadOnly(true);
        pushButton_16->raise();
        label_15->raise();
        textEdit_8->raise();
        label_17->raise();
        label_18->raise();
        pushButton_14->raise();
        pushButton_15->raise();
        textEdit_11->raise();
        groupBox_3 = new QGroupBox(centralWidget);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(380, 0, 211, 101));
        groupBox_3->setAlignment(Qt::AlignBottom|Qt::AlignLeading|Qt::AlignLeft);
        pushButton_7 = new QPushButton(groupBox_3);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(162, 38, 41, 21));
        checkBox_3 = new QCheckBox(groupBox_3);
        checkBox_3->setObjectName(QStringLiteral("checkBox_3"));
        checkBox_3->setGeometry(QRect(10, 20, 61, 21));
        checkBox_3->setLayoutDirection(Qt::LeftToRight);
        checkBox_4 = new QCheckBox(groupBox_3);
        checkBox_4->setObjectName(QStringLiteral("checkBox_4"));
        checkBox_4->setGeometry(QRect(10, 37, 61, 21));
        checkBox_5 = new QCheckBox(groupBox_3);
        checkBox_5->setObjectName(QStringLiteral("checkBox_5"));
        checkBox_5->setGeometry(QRect(10, 55, 61, 21));
        checkBox_6 = new QCheckBox(groupBox_3);
        checkBox_6->setObjectName(QStringLiteral("checkBox_6"));
        checkBox_6->setGeometry(QRect(10, 73, 61, 21));
        checkBox_8 = new QCheckBox(groupBox_3);
        checkBox_8->setObjectName(QStringLiteral("checkBox_8"));
        checkBox_8->setGeometry(QRect(96, 37, 61, 21));
        checkBox_7 = new QCheckBox(groupBox_3);
        checkBox_7->setObjectName(QStringLiteral("checkBox_7"));
        checkBox_7->setGeometry(QRect(96, 20, 61, 21));
        checkBox_7->setLayoutDirection(Qt::LeftToRight);
        checkBox_9 = new QCheckBox(groupBox_3);
        checkBox_9->setObjectName(QStringLiteral("checkBox_9"));
        checkBox_9->setGeometry(QRect(96, 55, 61, 21));
        checkBox_10 = new QCheckBox(groupBox_3);
        checkBox_10->setObjectName(QStringLiteral("checkBox_10"));
        checkBox_10->setGeometry(QRect(96, 73, 61, 21));
        pushButton_8 = new QPushButton(groupBox_3);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setGeometry(QRect(163, 65, 41, 21));
        groupBox_7 = new QGroupBox(centralWidget);
        groupBox_7->setObjectName(QStringLiteral("groupBox_7"));
        groupBox_7->setGeometry(QRect(380, 100, 211, 101));
        groupBox_7->setAlignment(Qt::AlignBottom|Qt::AlignLeading|Qt::AlignLeft);
        pushButton_17 = new QPushButton(groupBox_7);
        pushButton_17->setObjectName(QStringLiteral("pushButton_17"));
        pushButton_17->setGeometry(QRect(162, 38, 41, 21));
        checkBox_11 = new QCheckBox(groupBox_7);
        checkBox_11->setObjectName(QStringLiteral("checkBox_11"));
        checkBox_11->setGeometry(QRect(10, 20, 61, 21));
        checkBox_11->setLayoutDirection(Qt::LeftToRight);
        checkBox_12 = new QCheckBox(groupBox_7);
        checkBox_12->setObjectName(QStringLiteral("checkBox_12"));
        checkBox_12->setGeometry(QRect(10, 37, 61, 21));
        checkBox_13 = new QCheckBox(groupBox_7);
        checkBox_13->setObjectName(QStringLiteral("checkBox_13"));
        checkBox_13->setGeometry(QRect(10, 55, 61, 21));
        checkBox_14 = new QCheckBox(groupBox_7);
        checkBox_14->setObjectName(QStringLiteral("checkBox_14"));
        checkBox_14->setGeometry(QRect(10, 73, 61, 21));
        checkBox_16 = new QCheckBox(groupBox_7);
        checkBox_16->setObjectName(QStringLiteral("checkBox_16"));
        checkBox_16->setGeometry(QRect(96, 37, 61, 21));
        checkBox_15 = new QCheckBox(groupBox_7);
        checkBox_15->setObjectName(QStringLiteral("checkBox_15"));
        checkBox_15->setGeometry(QRect(96, 20, 61, 21));
        checkBox_15->setLayoutDirection(Qt::LeftToRight);
        checkBox_17 = new QCheckBox(groupBox_7);
        checkBox_17->setObjectName(QStringLiteral("checkBox_17"));
        checkBox_17->setGeometry(QRect(96, 55, 61, 21));
        checkBox_18 = new QCheckBox(groupBox_7);
        checkBox_18->setObjectName(QStringLiteral("checkBox_18"));
        checkBox_18->setGeometry(QRect(96, 73, 61, 21));
        pushButton_18 = new QPushButton(groupBox_7);
        pushButton_18->setObjectName(QStringLiteral("pushButton_18"));
        pushButton_18->setGeometry(QRect(163, 65, 41, 21));
        groupBox_8 = new QGroupBox(centralWidget);
        groupBox_8->setObjectName(QStringLiteral("groupBox_8"));
        groupBox_8->setGeometry(QRect(600, 0, 211, 201));
        groupBox_8->setAlignment(Qt::AlignBottom|Qt::AlignLeading|Qt::AlignLeft);
        comboBox_4 = new QComboBox(groupBox_8);
        comboBox_4->setObjectName(QStringLiteral("comboBox_4"));
        comboBox_4->setGeometry(QRect(61, 27, 41, 23));
        label_7 = new QLabel(groupBox_8);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(10, 30, 61, 16));
        label_8 = new QLabel(groupBox_8);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(113, 30, 31, 16));
        comboBox_5 = new QComboBox(groupBox_8);
        comboBox_5->setObjectName(QStringLiteral("comboBox_5"));
        comboBox_5->setGeometry(QRect(135, 26, 61, 23));
        lineEdit_1 = new QLineEdit(groupBox_8);
        lineEdit_1->setObjectName(QStringLiteral("lineEdit_1"));
        lineEdit_1->setGeometry(QRect(79, 80, 41, 23));
        lineEdit_1->setMaxLength(12);
        lineEdit_2 = new QLineEdit(groupBox_8);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(139, 80, 41, 23));
        lineEdit_2->setMaxLength(3);
        lineEdit_3 = new QLineEdit(groupBox_8);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(81, 131, 41, 23));
        lineEdit_3->setMaxLength(3);
        lineEdit_4 = new QLineEdit(groupBox_8);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(140, 130, 41, 23));
        lineEdit_4->setMaxLength(3);
        label_9 = new QLabel(groupBox_8);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(89, 60, 31, 16));
        label_10 = new QLabel(groupBox_8);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(145, 60, 31, 16));
        label_16 = new QLabel(groupBox_8);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(88, 110, 31, 16));
        label_19 = new QLabel(groupBox_8);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setGeometry(QRect(145, 110, 31, 16));
        label_22 = new QLabel(groupBox_8);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setGeometry(QRect(10, 83, 61, 16));
        label_23 = new QLabel(groupBox_8);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setGeometry(QRect(14, 133, 61, 16));
        pushButton_19 = new QPushButton(groupBox_8);
        pushButton_19->setObjectName(QStringLiteral("pushButton_19"));
        pushButton_19->setGeometry(QRect(20, 170, 41, 21));
        pushButton_20 = new QPushButton(groupBox_8);
        pushButton_20->setObjectName(QStringLiteral("pushButton_20"));
        pushButton_20->setGeometry(QRect(80, 170, 41, 21));
        pushButton_21 = new QPushButton(groupBox_8);
        pushButton_21->setObjectName(QStringLiteral("pushButton_21"));
        pushButton_21->setGeometry(QRect(140, 170, 41, 21));
        MainWindow->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        comboBox_1->setCurrentIndex(-1);
        comboBox_4->setCurrentIndex(-1);
        comboBox_5->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "USB2SPI", 0));
        groupBox_1->setTitle(QApplication::translate("MainWindow", "SPI configuration", 0));
        label->setText(QApplication::translate("MainWindow", "Fre:", 0));
        label_2->setText(QApplication::translate("MainWindow", "Mode:", 0));
        label_3->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Read Timeout:</p></body></html>", 0));
        textEdit_1->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">200</p></body></html>", 0));
        label_4->setText(QApplication::translate("MainWindow", "Write Timeout:", 0));
        textEdit_2->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">200</p></body></html>", 0));
        label_5->setText(QApplication::translate("MainWindow", "MS", 0));
        label_6->setText(QApplication::translate("MainWindow", "MS", 0));
        checkBox_1->setText(QApplication::translate("MainWindow", "As slaver", 0));
        pushButton_5->setText(QApplication::translate("MainWindow", "Set", 0));
        pushButton_9->setText(QApplication::translate("MainWindow", "Reset", 0));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "Devices", 0));
        pushButton->setText(QApplication::translate("MainWindow", "Exit", 0));
        pushButton_2->setText(QApplication::translate("MainWindow", "Open", 0));
        pushButton_3->setText(QApplication::translate("MainWindow", "Fresh", 0));
        pushButton_4->setText(QApplication::translate("MainWindow", "About", 0));
        groupBox_4->setTitle(QApplication::translate("MainWindow", "IO Trigger", 0));
        pushButton_10->setText(QApplication::translate("MainWindow", "Start", 0));
        pushButton_6->setText(QApplication::translate("MainWindow", "Set", 0));
        groupBox_5->setTitle(QApplication::translate("MainWindow", "Read", 0));
        label_11->setText(QApplication::translate("MainWindow", "Command:", 0));
        textEdit_6->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">00</p></body></html>", 0));
        label_12->setText(QApplication::translate("MainWindow", "Length:", 0));
        textEdit_7->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">256</p></body></html>", 0));
        label_13->setText(QApplication::translate("MainWindow", "Counter:", 0));
        label_14->setText(QApplication::translate("MainWindow", "00000000", 0));
        pushButton_11->setText(QApplication::translate("MainWindow", "Execute", 0));
        pushButton_12->setText(QApplication::translate("MainWindow", "Clear", 0));
        pushButton_13->setText(QApplication::translate("MainWindow", "Save", 0));
        checkBox_2->setText(QApplication::translate("MainWindow", "Self Check", 0));
        groupBox_6->setTitle(QApplication::translate("MainWindow", "Write", 0));
        label_15->setText(QApplication::translate("MainWindow", "Command:", 0));
        textEdit_8->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">00</p></body></html>", 0));
        label_17->setText(QApplication::translate("MainWindow", "Counter:", 0));
        label_18->setText(QApplication::translate("MainWindow", "00000000", 0));
        pushButton_14->setText(QApplication::translate("MainWindow", "Execute", 0));
        pushButton_15->setText(QApplication::translate("MainWindow", "Clear", 0));
        pushButton_16->setText(QApplication::translate("MainWindow", "Load", 0));
        groupBox_3->setTitle(QApplication::translate("MainWindow", "GPIO_Configuration", 0));
        pushButton_7->setText(QApplication::translate("MainWindow", "Reset", 0));
        checkBox_3->setText(QApplication::translate("MainWindow", "    IO1", 0));
        checkBox_4->setText(QApplication::translate("MainWindow", "    IO2", 0));
        checkBox_5->setText(QApplication::translate("MainWindow", "    IO3", 0));
        checkBox_6->setText(QApplication::translate("MainWindow", "    IO4", 0));
        checkBox_8->setText(QApplication::translate("MainWindow", "    IO6", 0));
        checkBox_7->setText(QApplication::translate("MainWindow", "    IO5", 0));
        checkBox_9->setText(QApplication::translate("MainWindow", "    IO7", 0));
        checkBox_10->setText(QApplication::translate("MainWindow", "    IO8", 0));
        pushButton_8->setText(QApplication::translate("MainWindow", "Set", 0));
        groupBox_7->setTitle(QApplication::translate("MainWindow", "GPIO_Value", 0));
        pushButton_17->setText(QApplication::translate("MainWindow", "Read", 0));
        checkBox_11->setText(QApplication::translate("MainWindow", "    IO1", 0));
        checkBox_12->setText(QApplication::translate("MainWindow", "    IO2", 0));
        checkBox_13->setText(QApplication::translate("MainWindow", "    IO3", 0));
        checkBox_14->setText(QApplication::translate("MainWindow", "    IO4", 0));
        checkBox_16->setText(QApplication::translate("MainWindow", "    IO6", 0));
        checkBox_15->setText(QApplication::translate("MainWindow", "    IO5", 0));
        checkBox_17->setText(QApplication::translate("MainWindow", "    IO7", 0));
        checkBox_18->setText(QApplication::translate("MainWindow", "    IO8", 0));
        pushButton_18->setText(QApplication::translate("MainWindow", "Write", 0));
        groupBox_8->setTitle(QApplication::translate("MainWindow", "PWM", 0));
        label_7->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Channels:</p><p><br/></p></body></html>", 0));
        label_8->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Fre:</p></body></html>", 0));
        lineEdit_1->setText(QString());
        label_9->setText(QApplication::translate("MainWindow", "<html><head/><body><p>CH1</p></body></html>", 0));
        label_10->setText(QApplication::translate("MainWindow", "<html><head/><body><p>CH2</p></body></html>", 0));
        label_16->setText(QApplication::translate("MainWindow", "<html><head/><body><p>CH3</p></body></html>", 0));
        label_19->setText(QApplication::translate("MainWindow", "<html><head/><body><p>CH4</p></body></html>", 0));
        label_22->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Duty (1\342\200\260)</p></body></html>", 0));
        label_23->setText(QApplication::translate("MainWindow", "<html><head/><body><p>Duty (1\342\200\260)</p></body></html>", 0));
        pushButton_19->setText(QApplication::translate("MainWindow", "Set", 0));
        pushButton_20->setText(QApplication::translate("MainWindow", "Reset", 0));
        pushButton_21->setText(QApplication::translate("MainWindow", "Start", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
